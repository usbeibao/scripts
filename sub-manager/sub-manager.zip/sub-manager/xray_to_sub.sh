#!/usr/bin/env bash
#
# xray_to_sub.sh — 从现有 Xray config.json 提取对外节点, 推送到 sub-manager
#
# 用法:
#   NODE_REGION=us \
#   SUB_API="https://sub-manager.202205.xyz" \
#   PUSH_TOKEN="xxxx" \
#   [NODE_DOMAIN="us.202205.xyz"] \
#   [NODE_NAME="tff-hk-1"] \
#   [SNI_DOMAIN=""] \
#   [CF_API_TOKEN=""] [CF_ZONE_ID=""] \
#   [XRAY_CONFIG="/usr/local/etc/xray/config.json"] \
#   bash xray_to_sub.sh
#
# SNI 说明 (reality 的 sni 是"伪装域名", 与 vmess 业务域名无关):
#   不传 SNI_DOMAIN:
#     保留 xray config 里 reality.serverNames[0] 的原值
#     (如 gateway.icloud.com, 不需要真实可达, 是 TLS 指纹伪装用的)
#
#   传 SNI_DOMAIN=xxx:
#     用指定的域名覆盖 sni, 先做 DNS 检查
#     若 DNS 不可达 + 配了 CF_API_TOKEN/CF_ZONE_ID → 自动建 CF DNS A 记录
#
# ⚠️  SNI_DOMAIN ≠ vmess 业务域名: vmess 的 host 字段由 xray config 直接读取,
#     不受 SNI_DOMAIN 影响
#
# 规则:
#   - 只提取对外 inbound: 跳过所有 listen=127.0.0.1 的 (内部中转)
#   - 跳过 shadowsocks (通常是中转链路)
#   - 提取直连 reality (vless+reality, 非 127.0.0.1), publicKey 取自 config
#   - 提取 nginx 前置节点 (正向追链: stream map 域名 -> upstream -> conf.d -> xray inbound)
#     协议从 xray inbound 实际读取(不信 map 标签名), 支持前置 vmess / vless
#     对外端口取 stream 所有非443端口(各生成节点, 同名靠序号区分)
#   - 节点地址: NODE_DOMAIN 优先, 否则探测公网 IP
#   - region: NODE_REGION 参数 (必填)
#
set -euo pipefail

GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
info(){ echo -e "${BLUE}$*${NC}"; }
ok(){ echo -e "${GREEN}$*${NC}"; }
warn(){ echo -e "${YELLOW}$*${NC}"; }
err(){ echo -e "${RED}$*${NC}"; }

XRAY_CONFIG="${XRAY_CONFIG:-/usr/local/etc/xray/config.json}"
SUB_API="${SUB_API:-}"
PUSH_TOKEN="${PUSH_TOKEN:-}"
NODE_REGION="${NODE_REGION:-}"
NODE_DOMAIN="${NODE_DOMAIN:-}"
# NODE_NAME: 节点来源标识(面板区分哪台机器, 默认主机名), 跟 sing-box push_to_sub.sh 一致
NODE_NAME="${NODE_NAME:-$(hostname)}"
SNI_DOMAIN="${SNI_DOMAIN:-}"
# CF 相关 (用于自动创建新子域名, 可选)
CF_API_TOKEN="${CF_API_TOKEN:-}"
CF_ZONE_ID="${CF_ZONE_ID:-}"

# 公共函数库 (地区探测)
_libdir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
[[ -f "${_libdir}/common_lib.sh" ]] && source "${_libdir}/common_lib.sh"

# ---------- 校验 ----------
# NODE_REGION 不填则自动探测 IP 归属
if [[ -z "$NODE_REGION" ]]; then
  if declare -F detect_region >/dev/null; then
    NODE_REGION=$(detect_region)
    info "NODE_REGION 未传, 自动探测: $NODE_REGION"
  else
    NODE_REGION="other"
    warn "NODE_REGION 未传且无法探测, 用 other"
  fi
fi
[[ ! -f "$XRAY_CONFIG" ]] && { err "找不到 Xray 配置: $XRAY_CONFIG"; exit 1; }
command -v jq >/dev/null 2>&1 || { err "需要 jq, 请先安装: apt install jq / yum install jq"; exit 1; }

# ---------- 工具函数 ----------
# 检查域名 DNS 是否可解析 (dig/nslookup 任一可用即可)
domain_resolvable(){
  local domain="$1"
  if command -v dig >/dev/null 2>&1; then
    dig +short +time=3 +tries=1 "$domain" 2>/dev/null | grep -qE '^[0-9]+\.' && return 0
  elif command -v nslookup >/dev/null 2>&1; then
    nslookup "$domain" >/dev/null 2>&1 && return 0
  else
    # 没有 dig/nslookup, 用 curl 头测试
    curl -fsS --max-time 4 --resolve "${domain}:443:1.1.1.1" "https://1.1.1.1" -o /dev/null 2>/dev/null && return 0
  fi
  return 1
}

# 通过 CF API 为域名创建 A 记录 (指向本机 IP)
cf_create_subdomain(){
  local domain="$1" ip="$2"
  [[ -z "$CF_API_TOKEN" || -z "$CF_ZONE_ID" ]] && {
    warn "未配置 CF_API_TOKEN/CF_ZONE_ID, 无法自动创建 DNS 记录"
    return 1
  }
  # 先查是否已存在
  EXISTING=$(curl -fsS -X GET "https://api.cloudflare.com/client/v4/zones/${CF_ZONE_ID}/dns_records?type=A&name=${domain}" \
    -H "Authorization: Bearer $CF_API_TOKEN" -H "Content-Type: application/json" 2>/dev/null || echo "{}")
  EXIST_ID=$(echo "$EXISTING" | jq -r '.result[0].id // ""')
  if [[ -n "$EXIST_ID" ]]; then
    info "CF 已有 $domain 的 A 记录, 更新指向 $ip"
    curl -fsS -X PUT "https://api.cloudflare.com/client/v4/zones/${CF_ZONE_ID}/dns_records/${EXIST_ID}" \
      -H "Authorization: Bearer $CF_API_TOKEN" -H "Content-Type: application/json" \
      -d "{\"type\":\"A\",\"name\":\"$domain\",\"content\":\"$ip\",\"proxied\":false,\"ttl\":60}" >/dev/null
  else
    info "CF 创建 $domain → $ip"
    curl -fsS -X POST "https://api.cloudflare.com/client/v4/zones/${CF_ZONE_ID}/dns_records" \
      -H "Authorization: Bearer $CF_API_TOKEN" -H "Content-Type: application/json" \
      -d "{\"type\":\"A\",\"name\":\"$domain\",\"content\":\"$ip\",\"proxied\":false,\"ttl\":60}" >/dev/null
  fi
}

# ---------- 确定节点地址 ----------
if [[ -n "$NODE_DOMAIN" ]]; then
  SERVER_ADDR="$NODE_DOMAIN"
  info "节点地址使用域名: $SERVER_ADDR"
else
  info "未传 NODE_DOMAIN, 探测公网 IP..."
  SERVER_ADDR=""
  for svc in "https://api.ipify.org" "https://ifconfig.me/ip" "https://ipinfo.io/ip"; do
    SERVER_ADDR=$(curl -fsS --max-time 5 "$svc" 2>/dev/null | tr -d '[:space:]') || true
    [[ -n "$SERVER_ADDR" ]] && break
  done
  [[ -z "$SERVER_ADDR" ]] && { err "无法探测公网 IP, 请用 NODE_DOMAIN 指定地址"; exit 1; }
  info "探测到公网 IP: $SERVER_ADDR"
fi

# ---------- 提取对外 reality 节点 ----------
info "解析 $XRAY_CONFIG ..."

# ---------- Reality SNI 处理 ----------
# reality 的 sni 是"伪装域名"(如 gateway.icloud.com), 供 TLS 指纹伪装用
# 它不需要真实可达, 也不应该和 vmess 的业务域名混淆
#
# 优先级:
#   1. 明确传入 SNI_DOMAIN=xxx → 用指定值 (此时可选配 CF_API_TOKEN/CF_ZONE_ID 自动建 DNS)
#   2. 未传 SNI_DOMAIN         → 保留 config 里 reality 原有的 serverNames[0]
#
# ⚠️  SNI_DOMAIN 不会自动复用 vmess 的 Host 域名——两者用途不同:
#      vmess Host = 业务域名 (反代入口, 必须真实可达)
#      reality sni = 伪装域名 (不需要真实可达, 但 TLS 握手要能过)
RESOLVED_SNI=""

if [[ -z "$SNI_DOMAIN" ]]; then
  # 模式1: 保留 config 里 reality 原有的 serverNames[0]
  RESOLVED_SNI=$(jq -r '
    [ .inbounds[]
      | select(.protocol == "vless")
      | select(.streamSettings.security == "reality")
      | (.streamSettings.realitySettings.serverNames[0] // "")
    ] | map(select(. != "" and . != "null")) | first // ""
  ' "$XRAY_CONFIG" 2>/dev/null || true)
  if [[ -n "$RESOLVED_SNI" && "$RESOLVED_SNI" != "null" ]]; then
    ok "Reality SNI 使用 config 原值: $RESOLVED_SNI"
  else
    warn "config 里未找到 reality serverNames, SNI 将为空 (可用 SNI_DOMAIN= 手动指定)"
    RESOLVED_SNI=""
  fi
else
  # 模式2: 用户明确指定了 SNI_DOMAIN
  info "检查指定 SNI 域名 $SNI_DOMAIN ..."
  if domain_resolvable "$SNI_DOMAIN"; then
    ok "SNI 域名 $SNI_DOMAIN DNS 可解析, 使用"
    RESOLVED_SNI="$SNI_DOMAIN"
  else
    warn "SNI 域名 $SNI_DOMAIN DNS 暂不可解析"
    if [[ -n "$CF_API_TOKEN" && -n "$CF_ZONE_ID" ]]; then
      info "尝试通过 CF API 创建 $SNI_DOMAIN → $SERVER_ADDR ..."
      if cf_create_subdomain "$SNI_DOMAIN" "$SERVER_ADDR"; then
        ok "CF DNS 记录已创建: $SNI_DOMAIN → $SERVER_ADDR (生效需1-2分钟)"
        RESOLVED_SNI="$SNI_DOMAIN"
      else
        warn "CF 创建失败, 仍使用 $SNI_DOMAIN (请手动添加 DNS 记录)"
        RESOLVED_SNI="$SNI_DOMAIN"
      fi
    else
      warn "未配置 CF_API_TOKEN/CF_ZONE_ID, 直接使用 $SNI_DOMAIN (请确认 DNS 已配置)"
      RESOLVED_SNI="$SNI_DOMAIN"
    fi
  fi
fi

ok "Reality SNI: ${RESOLVED_SNI:-<空>}"

REALITY_JSON=$(jq -c --arg server "$SERVER_ADDR" --arg region "$NODE_REGION" --arg sni_override "$RESOLVED_SNI" --arg nodename "$NODE_NAME" '
  [ .inbounds[]
    | select(.protocol == "vless")
    | select((.listen // "0.0.0.0") != "127.0.0.1")
    | select(.streamSettings.security == "reality")
  ]
  | to_entries
  | map(
      .key as $i | .value as $v
    | {
        name: ($nodename + "-Reality" + (if $i > 0 then ($i+1|tostring) else "" end)),
        type: "reality",
        server: $server,
        port: $v.port,
        region: $region,
        params: {
          uuid: $v.settings.clients[0].id,
          flow: ($v.settings.clients[0].flow // "xtls-rprx-vision"),
          pbk: $v.streamSettings.realitySettings.publicKey,
          sid: ($v.streamSettings.realitySettings.shortIds[0] // ""),
          sni: (if $sni_override != "" then $sni_override else ($v.streamSettings.realitySettings.serverNames[0] // "") end),
          fp: "chrome",
          network: ($v.streamSettings.network // "tcp")
        }
      }
  )
' "$XRAY_CONFIG")

RCOUNT=$(echo "$REALITY_JSON" | jq 'length')
ok "提取到 $RCOUNT 个对外 reality 节点:"
echo "$REALITY_JSON" | jq -r '.[] | "  \(.name)  端口=\(.port)  sni=\(.params.sni)"'

# ---------- 提取 nginx 前置节点 (正向追链: 从 stream map 出发) ----------
# 思路 (从 nginx 出发, 因为对外信息的源头在 nginx):
#   1. stream map: 业务域名 -> upstream标签 (标签名仅是别名, 不代表协议!)
#   2. upstream标签 -> upstream{} -> 本地端口 (如 21395/21093)
#   3. 本地端口 -> conf.d 找 listen <端口> ssl 的 server -> location path + proxy_pass 到 xray 端口
#   4. xray 端口 -> config.json inbound -> 看【实际协议】(vmess/vless-reality/...) 取 uuid 等
#   5. 对外端口: stream 所有【非443】listen 端口, 每个都生成一个节点 (同名靠序号区分)
#   6. server/sni: map 的业务域名
NGINX_JSON="[]"
NGINX_MAIN="/etc/nginx/nginx.conf"
NGINX_CONFD="/etc/nginx/conf.d"

if [[ -f "$NGINX_MAIN" ]]; then
  # 提取 stream 段
  STREAM_BLOCK=$(awk '/stream[[:space:]]*\{/{f=1} f{print} f&&/^\}/{exit}' "$NGINX_MAIN" 2>/dev/null || true)

  if [[ -n "$STREAM_BLOCK" ]]; then
    # 对外端口: stream 里所有 listen 端口, 取非443 (你的前置节点不用443; 443留给伪装站)
    EXT_PORTS=$(echo "$STREAM_BLOCK" | grep -oE 'listen[[:space:]]+(\[::\]:)?[0-9]+' \
                | grep -oE '[0-9]+' | sort -un | grep -v '^443$' || true)
    [[ -z "$EXT_PORTS" ]] && EXT_PORTS=$(echo "$STREAM_BLOCK" | grep -oE 'listen[[:space:]]+[0-9]+' | grep -oE '[0-9]+' | sort -un | head -1)

    info "stream 对外端口(非443): $(echo $EXT_PORTS | tr '\n' ' ')"

    # 解析 map: 业务域名 -> upstream标签
    # map 块内形如 "  域名  标签;" 的行
    MAP_LINES=$(echo "$STREAM_BLOCK" | awk '/map[[:space:]]+\$ssl_preread_server_name/{f=1;next} f&&/\}/{f=0} f{print}')

    NGINX_NODES="[]"
    VMESS_SEQ=0; VLESS_SEQ=0  # 同协议多个时加序号
    while IFS= read -r mapline; do
      DOMAIN=$(echo "$mapline" | awk '{print $1}' | tr -d ' ')
      LABEL=$(echo "$mapline" | awk '{print $2}' | tr -d ' ;')
      [[ -z "$DOMAIN" || -z "$LABEL" || "$DOMAIN" == "default" ]] && continue
      # 跳过 map 里的注释/默认/通配
      echo "$DOMAIN" | grep -qE '^[a-zA-Z0-9.-]+$' || continue

      # upstream标签 -> 本地端口 (用 awk 取 upstream 块, grep 抽端口, 兼容 mawk)
      UP_BLOCK=$(echo "$STREAM_BLOCK" | awk -v u="$LABEL" '$1=="upstream" && $2==u {f=1} f{print} f&&/\}/{exit}')
      UP_PORT=$(echo "$UP_BLOCK" | grep -oE '127\.0\.0\.1:[0-9]+' | grep -oE '[0-9]+$' | head -1)
      [[ -z "$UP_PORT" ]] && { warn "  $DOMAIN -> upstream $LABEL: 找不到本地端口, 跳过"; continue; }

      # 本地端口 -> conf.d 找 listen <UP_PORT> ssl 的 server, 拿 location path + proxy_pass 到的 xray 端口
      XRAY_PORT=""; WSPATH="/"
      if [[ -d "$NGINX_CONFD" ]]; then
        CONF_FILE=$(grep -rlE "listen[[:space:]]+${UP_PORT}[[:space:]]+ssl" "$NGINX_CONFD" 2>/dev/null | head -1 || true)
        if [[ -n "$CONF_FILE" ]]; then
          XRAY_PORT=$(grep -oE 'proxy_pass[[:space:]]+http://127\.0\.0\.1:[0-9]+' "$CONF_FILE" | grep -oE '[0-9]+$' | head -1 || true)
          WSPATH=$(grep -oE 'location[[:space:]]+[^ ]+' "$CONF_FILE" | awk '{print $2}' | head -1 || echo "/")
          [[ -z "$WSPATH" ]] && WSPATH="/"
        fi
      fi
      [[ -z "$XRAY_PORT" ]] && { warn "  $DOMAIN (本地$UP_PORT): conf.d 找不到对应 xray 端口, 跳过"; continue; }

      # xray 端口 -> config inbound 实际协议 (不信 map 标签!)
      INBOUND=$(jq -c --arg p "$XRAY_PORT" '.inbounds[] | select((.port|tostring)==$p)' "$XRAY_CONFIG" 2>/dev/null | head -1)
      [[ -z "$INBOUND" ]] && { warn "  $DOMAIN -> xray端口$XRAY_PORT: config 无此 inbound, 跳过"; continue; }
      PROTO=$(echo "$INBOUND" | jq -r '.protocol')
      UUID=$(echo "$INBOUND" | jq -r '.settings.clients[0].id // ""')
      # path 优先用 nginx location, 其次 xray wsSettings
      XPATH=$(echo "$INBOUND" | jq -r '.streamSettings.wsSettings.path // ""')
      [[ -n "$WSPATH" && "$WSPATH" != "/" ]] && FINAL_PATH="$WSPATH" || FINAL_PATH="${XPATH:-/}"

      # 对每个非443对外端口生成一个节点
      for OUT_PORT in $EXT_PORTS; do
        if [[ "$PROTO" == "vmess" ]]; then
          VMESS_SEQ=$((VMESS_SEQ+1))
          VM_SUFFIX=$([[ $VMESS_SEQ -gt 1 ]] && echo "$VMESS_SEQ" || echo "")
          AID=$(echo "$INBOUND" | jq -r '.settings.clients[0].alterId // 0')
          node=$(jq -n --arg host "$DOMAIN" --arg port "$OUT_PORT" --arg uuid "$UUID" \
            --arg path "$FINAL_PATH" --arg aid "$AID" --arg region "$NODE_REGION" \
            --arg nm "$NODE_NAME" --arg sfx "$VM_SUFFIX" '
            {name:($nm+"-VMess"+$sfx), type:"vmess", server:$host, port:($port|tonumber), region:$region,
             params:{uuid:$uuid, alterId:($aid|tonumber), network:"ws", path:$path, host:$host, tls:true, sni:$host}}')
          ok "  vmess: $DOMAIN:$OUT_PORT path=$FINAL_PATH (xray$XRAY_PORT)"
        elif [[ "$PROTO" == "vless" ]]; then
          # nginx前置的 vless (可能 reality 或普通 tls+ws)
          VLESS_SEQ=$((VLESS_SEQ+1))
          VL_SUFFIX=$([[ $VLESS_SEQ -gt 1 ]] && echo "$VLESS_SEQ" || echo "")
          SEC=$(echo "$INBOUND" | jq -r '.streamSettings.security // ""')
          NET=$(echo "$INBOUND" | jq -r '.streamSettings.network // "tcp"')
          FLOW=$(echo "$INBOUND" | jq -r '.settings.clients[0].flow // ""')
          node=$(jq -n --arg host "$DOMAIN" --arg port "$OUT_PORT" --arg uuid "$UUID" \
            --arg path "$FINAL_PATH" --arg net "$NET" --arg flow "$FLOW" --arg region "$NODE_REGION" \
            --arg nm "$NODE_NAME" --arg sfx "$VL_SUFFIX" '
            {name:($nm+"-VLESS"+$sfx), type:"vless", server:$host, port:($port|tonumber), region:$region,
             params:{uuid:$uuid, network:$net, path:$path, host:$host, tls:true, sni:$host}
                     + (if $flow!="" then {flow:$flow} else {} end)}')
          ok "  vless: $DOMAIN:$OUT_PORT path=$FINAL_PATH net=$NET (xray$XRAY_PORT)"
        else
          warn "  $DOMAIN -> xray端口$XRAY_PORT 协议=$PROTO 暂不支持前置提取, 跳过"
          continue
        fi
        NGINX_NODES=$(echo "$NGINX_NODES" | jq -c ". + [$node]")
      done
    done <<< "$MAP_LINES"
    NGINX_JSON="$NGINX_NODES"
  else
    info "nginx.conf 无 stream 段, 跳过 nginx 前置节点提取"
  fi
else
  info "未找到 nginx.conf, 跳过 nginx 前置节点提取"
fi

VMCOUNT=$(echo "$NGINX_JSON" | jq 'length')
VMESS_JSON="$NGINX_JSON"

# ---------- 合并 reality + vmess ----------
NODES_JSON=$(jq -c -n --argjson r "$REALITY_JSON" --argjson v "$VMESS_JSON" '$r + $v')
TOTAL=$(echo "$NODES_JSON" | jq 'length')

if [[ "$TOTAL" -eq 0 ]]; then
  warn "未提取到任何对外节点"
  exit 0
fi
ok "共 $TOTAL 个节点 (reality $RCOUNT + vmess $VMCOUNT)"

# ---------- 推送到 sub-manager ----------
if [[ -z "$SUB_API" || -z "$PUSH_TOKEN" ]]; then
  warn "未设置 SUB_API/PUSH_TOKEN, 跳过推送。节点 JSON 如下 (可手动粘贴导入):"
  echo "$NODES_JSON" | jq .
  exit 0
fi

info "推送到 $SUB_API ..."
# 幂等: 推送前清理同机器(NODE_NAME前缀)旧节点
if [[ "${CLEANUP_OLD:-1}" == "1" ]]; then
  CL=$(curl -s --max-time 10 -X POST "$SUB_API/api/nodes/cleanup" \
    -H "Content-Type: application/json" -H "Authorization: Bearer $PUSH_TOKEN" \
    -d "{\"name_prefix\": \"${NODE_NAME}-\"}" 2>/dev/null)
  info "清理旧节点: $CL"
fi
RESP=$(curl -fsS -X POST "$SUB_API/api/nodes/push" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $PUSH_TOKEN" \
  -d "$NODES_JSON" 2>&1) || { err "推送失败: $RESP"; exit 1; }

ok "推送成功:"
echo "$RESP" | jq -r '.results[]? | "  \(.name)  created=\(.created)  id=\(.id)"' 2>/dev/null || echo "$RESP"

ok "完成! 去 sub-manager 面板确认节点 (地区已设为 $NODE_REGION, 命名会按 地区-协议 规范化)"
