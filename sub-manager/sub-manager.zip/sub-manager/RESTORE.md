# sub-manager 面板重建手册 (RESTORE.md)

> 场景: oracle-osaka-1 挂了/换机/迁移, 需在新机器从零重建 sub-manager 面板。
> 核心: 代码(zip) + 配置(.env) + 数据(DB备份) + 外围(nginx/CF/cron/告警)。
> 数据是关键 —— 节点/token 全在 `data/sub.db`, 靠 GDrive 异地备份恢复。

---

## 快速恢复 (用 restore.sh)

```bash
# 1. 新机器装 docker
curl -fsSL https://get.docker.com | sh

# 2. 传 sub-manager.zip 到新机器 (放 /opt 或当前目录)
scp sub-manager.zip 新机器:/opt/

# 3. (可选) 先挂好 GDrive, 让脚本能自动找到最新备份
#    rclone mount siftminsk_gdrive: /opt/siftminsk_gdrive --daemon ...

# 4. 跑恢复脚本
cd /opt && unzip -o sub-manager.zip "sub-manager/restore.sh" && bash sub-manager/restore.sh
```

脚本自动: 检查docker → 解压代码 → 创建/沿用.env → 找最新DB备份恢复 → 起容器 → 健康检查。

指定特定备份恢复:
```bash
RESTORE_DB=/path/to/sub-manager-20260623.db.gz bash restore.sh
```

---

## 手动恢复 (理解每步, 或脚本不可用时)

### 1. 装 docker
```bash
curl -fsSL https://get.docker.com | sh
```

### 2. 部署代码
```bash
cd /opt && unzip -o sub-manager.zip
cd sub-manager
```

### 3. 配置 .env (关键凭据)
```bash
cp .env.example .env
vim .env
```
必填:
```ini
ADMIN_PASSWORD=面板登录密码
PUSH_TOKEN=节点推送token (要和各节点机 .node-env 里的一致, 否则节点推不上来)
REPORT_TOKEN=状态报告token (daily.py /sub 和告警用)
CF_API_TOKEN=cfut_用户令牌 (CF DNS自动化)
CF_ZONE_ID=71e749cbdbcba45da7ba9a3a8f661c61
```
> ⚠ docker-compose.yml 的 environment 段确认有 `REPORT_TOKEN: "${REPORT_TOKEN:-}"` (历史坑: 不透传则容器读不到, 自己生成另一个)

### 4. 恢复数据库 (节点/token 数据)
**这步最关键 —— 不恢复 DB 就是空面板, 所有节点/token 都没了。**
```bash
mkdir -p data
# 从 GDrive 找最新备份 (或本地 backups/)
ls -1t /opt/siftminsk_gdrive/sub-manager-backups/sub-manager-*.db.gz | head -1
# 解压恢复
gunzip -c /opt/siftminsk_gdrive/sub-manager-backups/sub-manager-最新.db.gz > data/sub.db
```

### 5. 起容器
```bash
docker compose up -d --build
curl -s http://127.0.0.1:8090/api/health   # 应返回 status:ok + 节点/token数
```

### 6. 恢复外围 (容器外的东西)

**a. nginx 反代 + CF 域名**
```nginx
location / {
    proxy_pass http://127.0.0.1:8090;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $remote_addr;   # token访问记录靠这个拿真实IP
    proxy_set_header X-Forwarded-Proto $scheme;
}
```
CF 加 A 记录: `sub-manager.202205.xyz → 新机IP` (橙云代理)

**b. cron 自动备份**
```bash
crontab -e
# 加:
0 3 * * * /opt/sub-manager/backup_db.sh >> /var/log/sub-manager-backup.log 2>&1
```
> 确认 GDrive 挂载 (`/opt/siftminsk_gdrive`), 否则异地备份会跳过。

**c. daily.py 告警 (在 daily-report 容器, 另一套)**
确认 daily-report 的 .env 有:
```
SUBMGR_API=https://sub-manager.202205.xyz
SUBMGR_REPORT_TOKEN=<与上面REPORT_TOKEN一致>
```

**d. 验证**
- 浏览器开 https://sub-manager.202205.xyz, 用 ADMIN_PASSWORD 登录
- 确认节点/token 都在 (DB恢复成功的标志)
- TG 发 /sub 确认告警链路通
- 各节点机若 PUSH_TOKEN 变了, 需重新推送 (menu.sh 选2/3)

---

## 数据安全说明

- **DB 备份**: 每天 03:00 cron 跑 backup_db.sh, 本地 `backups/` + GDrive `siftminsk_gdrive/sub-manager-backups/` 各留 14 份
- **恢复粒度**: 最坏丢失「上次备份到故障」之间的改动 (最多24h, 且节点可重推、token可重建, 损失小)
- **定期演练**: 建议偶尔拉个备份解压看看 `sqlite3 sub.db "SELECT count(*) FROM nodes"`, 确认备份真的可用 (备份最怕"以为有其实坏了")

---

## 凭据备忘 (重建时要用)

| 项 | 值/位置 |
|------|---------|
| 面板地址 | https://sub-manager.202205.xyz |
| CF Zone ID | 71e749cbdbcba45da7ba9a3a8f661c61 |
| ADMIN_PASSWORD / PUSH_TOKEN / REPORT_TOKEN / CF_API_TOKEN | 旧机 .env (妥善另存!) |
| GDrive 备份位置 | /opt/siftminsk_gdrive/sub-manager-backups/ |

> ⚠ **最重要**: .env 里的凭据要**另存一份在安全的地方** (密码管理器/Vaultwarden)。
> 机器全挂时, sub-manager.zip 能重下、DB 能从 GDrive 拉, 但 .env 凭据若没另存就得全部重设
> (PUSH_TOKEN 重设意味着所有节点机的 .node-env 都要跟着改)。
