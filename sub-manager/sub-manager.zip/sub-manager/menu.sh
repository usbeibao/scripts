#!/usr/bin/env bash
#
# menu.sh — 节点机总控
#   模块化调用同目录脚本: init.sh / reality.sh / xray_to_sub.sh
#   配置(SUB_API/PUSH_TOKEN/NODE_*)从同目录 .node-env 读取, 没有则交互询问并保存
#
# 用法:
#   bash menu.sh           # 进入菜单
#   也可先写好 .node-env 免交互

set -uo pipefail

RED="\033[31m"; GREEN="\033[32m"; YELLOW="\033[33m"; BLUE="\033[36m"; PLAIN='\033[0m'
c() { echo -e "${1}${@:2}${PLAIN}"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="${SCRIPT_DIR}/.node-env"

# ---------- 配置加载 ----------
load_env() {
  [[ -f "$ENV_FILE" ]] && source "$ENV_FILE"
  SUB_API="${SUB_API:-}"
  PUSH_TOKEN="${PUSH_TOKEN:-}"
  NODE_NAME="${NODE_NAME:-$(hostname)}"
  NODE_REGION="${NODE_REGION:-}"
  CF_API_TOKEN="${CF_API_TOKEN:-}"
  NODE_DOMAIN="${NODE_DOMAIN:-}"
}

save_env() {
  cat > "$ENV_FILE" <<EOF
# 节点机配置(menu.sh 自动生成, 含敏感信息勿外泄)
SUB_API="${SUB_API}"
PUSH_TOKEN="${PUSH_TOKEN}"
NODE_NAME="${NODE_NAME}"
NODE_REGION="${NODE_REGION}"
CF_API_TOKEN="${CF_API_TOKEN}"
NODE_DOMAIN="${NODE_DOMAIN}"
EOF
  chmod 600 "$ENV_FILE"
  c $GREEN " 配置已保存到 ${ENV_FILE} (权限600)"
}

# 确保推送配置就绪(没有则问), 用于需要推送的菜单项
ensure_push_cfg() {
  local changed=0
  if [[ -z "$SUB_API" ]]; then
    read -rp " sub-manager 地址 (如 https://sub-manager.202205.xyz): " SUB_API; changed=1
  fi
  if [[ -z "$PUSH_TOKEN" ]]; then
    read -rp " 推送 Token (面板部署token): " PUSH_TOKEN; changed=1
  fi
  if [[ -z "$NODE_NAME" || "$NODE_NAME" == "$(hostname)" ]]; then
    read -rp " 节点标识 NODE_NAME [回车用主机名 $(hostname)]: " _nn
    [[ -n "$_nn" ]] && { NODE_NAME="$_nn"; changed=1; }
  fi
  if [[ -z "$NODE_REGION" ]]; then
    read -rp " 地区码 NODE_REGION (jp/hk/us..., 回车=自动探测IP归属): " _nr
    [[ -n "$_nr" ]] && { NODE_REGION="$_nr"; changed=1; }
  fi
  # NODE_DOMAIN 可选: 填了才给 Hy2/TUIC 配真证书(需配套 CF_API_TOKEN)
  if [[ -z "$NODE_DOMAIN" ]]; then
    read -rp " 节点域名 NODE_DOMAIN (可空; 填了配真证书, 如 us.202205.xyz): " _nd
    if [[ -n "$_nd" ]]; then
      NODE_DOMAIN="$_nd"; changed=1
      if [[ -z "$CF_API_TOKEN" ]]; then
        read -rp " CF API Token (cfut_用户令牌, 配真证书+解析用): " CF_API_TOKEN
        [[ -n "$CF_API_TOKEN" ]] && changed=1
      fi
    fi
  fi
  [[ "$changed" == "1" ]] && save_env
}

check_script() {
  if [[ ! -f "${SCRIPT_DIR}/$1" ]]; then
    c $RED " 缺少脚本: $1 (应和 menu.sh 放同目录)"
    return 1
  fi
  return 0
}

# ---------- 菜单项 ----------

# 1) 一键梭哈: init(不重启) + reality(装sing-box+推送)
all_in_one() {
  c $BLUE "\n===== 一键梭哈: 系统初始化 + sing-box + 推送 =====\n"
  ensure_push_cfg
  check_script init.sh || return
  check_script reality.sh || return

  c $YELLOW "\n[1/2] 系统初始化 (init.sh, 不自动重启)..."
  read -rp " GitHub 用户名(SSH key, 可空跳过): " gh
  read -rp " 新用户名(可空跳过): " nu
  NO_REBOOT=1 bash "${SCRIPT_DIR}/init.sh" "$gh" "$nu"

  c $YELLOW "\n[2/2] 装 sing-box + 推送 (reality.sh)..."
  SUB_API="$SUB_API" PUSH_TOKEN="$PUSH_TOKEN" \
  NODE_NAME="$NODE_NAME" NODE_REGION="$NODE_REGION" \
  CF_API_TOKEN="$CF_API_TOKEN" NODE_DOMAIN="$NODE_DOMAIN" \
    bash "${SCRIPT_DIR}/reality.sh"

  c $GREEN "\n===== 梭哈完成 ====="
  ask_reboot
}

# 2) 重装/更新 sing-box 配置并推送
redo_singbox() {
  c $BLUE "\n===== 重装/更新 sing-box =====\n"
  ensure_push_cfg
  check_script reality.sh || return
  SUB_API="$SUB_API" PUSH_TOKEN="$PUSH_TOKEN" \
  NODE_NAME="$NODE_NAME" NODE_REGION="$NODE_REGION" \
  CF_API_TOKEN="$CF_API_TOKEN" NODE_DOMAIN="$NODE_DOMAIN" \
    bash "${SCRIPT_DIR}/reality.sh"
}

# 3) 提取并推送 Xray 配置
push_xray() {
  c $BLUE "\n===== 提取并推送 Xray 配置 =====\n"
  ensure_push_cfg
  check_script xray_to_sub.sh || return
  SUB_API="$SUB_API" PUSH_TOKEN="$PUSH_TOKEN" \
  NODE_NAME="$NODE_NAME" NODE_REGION="$NODE_REGION" \
  CF_API_TOKEN="$CF_API_TOKEN" NODE_DOMAIN="$NODE_DOMAIN" \
    bash "${SCRIPT_DIR}/xray_to_sub.sh"
}

# 4) 系统初始化(单独跑, 会询问重启)
run_init() {
  c $BLUE "\n===== 系统初始化 =====\n"
  check_script init.sh || return
  read -rp " GitHub 用户名(可空): " gh
  read -rp " 新用户名(可空): " nu
  bash "${SCRIPT_DIR}/init.sh" "$gh" "$nu"
}

# 6) 节点状态查看
node_status() {
  c $BLUE "\n===== 节点状态 =====\n"
  if systemctl is-active --quiet sing-box 2>/dev/null; then
    c $GREEN " sing-box: 运行中"
  else
    c $YELLOW " sing-box: 未运行/未安装"
  fi
  if systemctl is-active --quiet xray 2>/dev/null; then
    c $GREEN " xray: 运行中"
  fi
  c $BLUE "\n 监听端口:"
  ss -tunlp 2>/dev/null | grep -E "sing-box|xray" || c $YELLOW " (无 sing-box/xray 监听)"
  c $BLUE "\n BBR:"
  sysctl -n net.ipv4.tcp_congestion_control 2>/dev/null
}

ask_reboot() {
  read -rp $'\n 是否现在重启? [y/N] : ' yn
  if [[ "${yn:-N}" == [Yy] ]]; then
    c $BLUE " 重启中..."; reboot
  fi
}

# ---------- 主循环 ----------
load_env

if [[ "$(id -u)" != "0" ]]; then
  c $RED " 请以 root 运行: sudo bash menu.sh"; exit 1
fi

while true; do
  echo ""
  c $GREEN "╔══════════ 节点机总控 ══════════╗"
  echo -e "  当前: NODE_NAME=${NODE_NAME}  REGION=${NODE_REGION:-(自动探测)}"
  echo -e "  域名: ${NODE_DOMAIN:-(无, Hy2/TUIC自签)}  推送: ${SUB_API:-(未配置)}"
  c $GREEN "╠════════════════════════════════╣"
  echo "  1) 一键梭哈 (init + sing-box + 推送)"
  echo "  2) 重装/更新 sing-box 配置并推送"
  echo "  3) 提取并推送 Xray 配置"
  echo "  4) 系统初始化 (init.sh)"
  echo "  5) 节点状态查看"
  echo "  9) 重新配置 (SUB_API/Token/地区)"
  echo "  0) 退出"
  c $GREEN "╚════════════════════════════════╝"
  read -rp " 选择: " choice
  case "$choice" in
    1) all_in_one ;;
    2) redo_singbox ;;
    3) push_xray ;;
    4) run_init ;;
    5) node_status ;;
    9) SUB_API=""; PUSH_TOKEN=""; NODE_NAME="$(hostname)"
       NODE_REGION=""; NODE_DOMAIN=""; CF_API_TOKEN=""
       ensure_push_cfg ;;
    0) exit 0 ;;
    *) c $RED " 无效选择" ;;
  esac
done
