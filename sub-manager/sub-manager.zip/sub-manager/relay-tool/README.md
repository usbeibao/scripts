# 服务端 tag 转发工具 (relay-tool)

把"手动改 xray config.json 加 outbound + routing 转发到落地机"的过程做成声明式、可维护。
**独立于订阅系统**——这是在入口节点服务器上运行的工具,订阅系统不感知。

## 适用场景 (路径B: 服务端中转)

- 某地区只有 Oracle 没 DMIT (如想要 Milan 出口, 但 DMIT 没意大利)
- 某落地 IP 太脏, 不想直接当入站暴露, 藏在入口机后面
- 想让客户端只连一个入口, 由入口内部分流到多个落地

客户端只连入口节点 → 入口按规则转发到对应落地 → 落地出网。

## 工作原理

利用 xray 的 `confdir` 机制: `xray run -confdir /usr/local/etc/xray` 会合并目录下
所有 .json 文件。主 config.json (reality.sh 生成的入站) 和 relay.json (本工具生成的
转发出站+路由) 各管一块, 互不干扰。改转发不碰主配置。

## 用法

1. 在入口机上准备 relay.yaml (见示例), 填好落地机连接信息
2. 生成并热重载:
```bash
python3 relay_gen.py --config relay.yaml \
    --out /usr/local/etc/xray/relay.json --reload
```
3. `--reload` 会先 `xray -test` 校验整个 confdir, 通过才 `systemctl restart xray`,
   校验失败不重启(保护现网)

仅生成不重载 (检查输出):
```bash
python3 relay_gen.py --config relay.yaml --out /tmp/relay.json --test
```

## relay.yaml 结构

```yaml
landings:           # 落地机, key=tag名
  us-oracle:
    type: vless-reality   # 支持 vless-reality/vless/trojan/shadowsocks/hysteria2
    server: ...
    port: 443
    uuid/pbk/sid/sni...   # 按类型填对应字段
routing:            # 转发规则
  - rules: [geosite:netflix]   # geosite:/geoip:/域名
    via: us-oracle             # 指向某个落地tag, 或 direct
default_via: direct # 兜底出站
```

## 与主 config 的关系

- reality.sh 生成 `/usr/local/etc/xray/config.json` (入站: 客户端连入口)
- 本工具生成 `/usr/local/etc/xray/relay.json` (出站+路由: 入口转发到落地)
- xray 用 confdir 合并两者
- **注意**: 主 config.json 里不要再写 routing (会和 relay.json 的 routing 冲突),
  把路由统一交给 relay.json 管。reality.sh 默认的 routing 较简单,
  如同时用本工具, 建议把分流逻辑都挪到 relay.yaml。

## 落地机那一侧

落地机需要跑一个 inbound 接收入口的转发流量 (就是个普通的 reality/trojan 节点)。
可以用 reality.sh 在落地机上部署, 把它的连接参数填进入口机的 relay.yaml landings 里。
