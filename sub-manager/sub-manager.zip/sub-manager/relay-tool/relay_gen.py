#!/usr/bin/env python3
"""
relay_gen.py —— 服务端 tag 转发配置生成器
在入口机(如日本DMIT)本地运行: 读 relay.yaml 声明 → 生成 xray 的
outbounds(每落地一个tag) + routing.rules(geosite→outboundTag),
用 xray confdir 机制写成独立文件(不动 reality.sh 生成的主 config), 然后 reload。

用法:
  python3 relay_gen.py --config relay.yaml --out /usr/local/etc/xray/relay.json
  python3 relay_gen.py --config relay.yaml --out /usr/local/etc/xray/relay.json --reload

confdir 说明: xray run -confdir /usr/local/etc/xray 会合并目录下所有 .json。
主 config.json (入站等) + relay.json (转发出站+路由) 各管一块, 互不干扰。
"""
import argparse
import json
import sys

try:
    import yaml
except ImportError:
    sys.exit("需要 pyyaml: pip install pyyaml")


def landing_to_outbound(tag, l):
    """把一个落地定义转成 xray outbound"""
    t = l["type"]
    server, port = l["server"], int(l["port"])

    if t in ("vless-reality", "reality"):
        ob = {
            "tag": tag, "protocol": "vless",
            "settings": {"vnext": [{"address": server, "port": port,
                "users": [{"id": l["uuid"], "encryption": "none",
                           "flow": l.get("flow", "xtls-rprx-vision")}]}]},
            "streamSettings": {"network": l.get("network", "tcp"), "security": "reality",
                "realitySettings": {"fingerprint": l.get("fp", "chrome"),
                    "serverName": l.get("sni", ""), "publicKey": l.get("pbk", ""),
                    "shortId": l.get("sid", "")}},
        }
        if l.get("network") == "grpc":
            ob["streamSettings"]["grpcSettings"] = {"serviceName": l.get("serviceName", "grpc")}
        return ob

    if t == "vless":
        ob = {"tag": tag, "protocol": "vless",
              "settings": {"vnext": [{"address": server, "port": port,
                  "users": [{"id": l["uuid"], "encryption": "none"}]}]},
              "streamSettings": {"network": l.get("network", "tcp")}}
        if l.get("tls"):
            ob["streamSettings"]["security"] = "tls"
            ob["streamSettings"]["tlsSettings"] = {"serverName": l.get("sni", "")}
        return ob

    if t == "trojan":
        ob = {"tag": tag, "protocol": "trojan",
              "settings": {"servers": [{"address": server, "port": port, "password": l["password"]}]},
              "streamSettings": {"network": l.get("network", "tcp"), "security": "tls",
                  "tlsSettings": {"serverName": l.get("sni", "")}}}
        return ob

    if t in ("shadowsocks", "ss"):
        return {"tag": tag, "protocol": "shadowsocks",
                "settings": {"servers": [{"address": server, "port": port,
                    "method": l["method"], "password": l["password"]}]}}

    if t in ("hysteria2", "hy2"):
        # 注意: xray 出站对 hy2 支持有限, 一般落地用 vless/trojan; 这里保留
        return {"tag": tag, "protocol": "hysteria2",
                "settings": {"servers": [{"address": server, "port": port,
                    "password": l.get("password", "")}]},
                "streamSettings": {"security": "tls",
                    "tlsSettings": {"serverName": l.get("sni", ""),
                                    "allowInsecure": bool(l.get("insecure", False))}}}

    raise ValueError(f"不支持的落地类型: {t}")


def generate(cfg):
    landings = cfg.get("landings", {})
    routing = cfg.get("routing", [])

    outbounds = []
    # 内置 direct/block
    outbounds.append({"tag": "direct", "protocol": "freedom", "settings": {}})
    outbounds.append({"tag": "block", "protocol": "blackhole", "settings": {}})

    # 每个落地一个 outbound
    valid_tags = {"direct", "block"}
    for tag, l in landings.items():
        outbounds.append(landing_to_outbound(tag, l))
        valid_tags.add(tag)

    # routing rules
    rules = []
    for item in routing:
        via = item.get("via", "direct")
        if via == "direct":
            via = "direct"
        elif via not in valid_tags:
            print(f"[警告] routing 指向未定义的落地 '{via}', 跳过", file=sys.stderr)
            continue
        domains = [r for r in item.get("rules", []) if r]
        if not domains:
            continue
        # 区分 geosite/geoip/domain
        rule = {"type": "field", "outboundTag": via}
        domain_list, ip_list = [], []
        for d in domains:
            if d.startswith("geoip:") or d.startswith("ext-ip:"):
                ip_list.append(d)
            else:
                domain_list.append(d)
        if domain_list:
            r2 = dict(rule); r2["domain"] = domain_list; rules.append(r2)
        if ip_list:
            r3 = dict(rule); r3["ip"] = ip_list; rules.append(r3)

    # 默认出站 (兜底): 声明里的 default_via, 否则 direct
    default_via = cfg.get("default_via", "direct")
    rules.append({"type": "field", "outboundTag": default_via,
                  "network": "tcp,udp"})

    return {"outbounds": outbounds,
            "routing": {"domainStrategy": cfg.get("domain_strategy", "IPIfNonMatch"),
                        "rules": rules}}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True, help="relay.yaml 路径")
    ap.add_argument("--out", required=True, help="输出 json 路径 (xray confdir 内)")
    ap.add_argument("--reload", action="store_true", help="生成后重启 xray")
    ap.add_argument("--test", action="store_true", help="只校验不写入")
    args = ap.parse_args()

    with open(args.config, encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    result = generate(cfg)
    out_json = json.dumps(result, ensure_ascii=False, indent=2)

    if args.test:
        print(out_json)
        print("\n[校验] 配置生成成功", file=sys.stderr)
        return

    with open(args.out, "w", encoding="utf-8") as f:
        f.write(out_json)
    print(f"已写入 {args.out}")

    if args.reload:
        import subprocess
        # 先用 xray 测试整个 confdir
        confdir = args.out.rsplit("/", 1)[0]
        test = subprocess.run(["xray", "run", "-test", "-confdir", confdir],
                              capture_output=True, text=True)
        if test.returncode != 0:
            print(f"[错误] xray 配置校验失败, 不重启:\n{test.stderr}", file=sys.stderr)
            sys.exit(1)
        subprocess.run(["systemctl", "restart", "xray"])
        print("xray 已重载")


if __name__ == "__main__":
    main()
