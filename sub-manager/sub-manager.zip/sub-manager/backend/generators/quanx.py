"""
Quantumult X 生成器 (模板占位符模式)
只生成 [server_local] 段节点行, 注入模板 {{NODES}}。
字段严格对齐用户真实配置:
  vless=server:port, method=none, password=uuid, obfs=over-tls, obfs-host=sni,
        reality-base64-pubkey=pbk, reality-hex-shortid=sid,
        vless-flow=xtls-rprx-vision, tag=日本1
命名: 纯中文地区名+序号
"""
from .common import region_label, sort_regions

PLACEHOLDER = "{{NODES}}"


def _node_line(tag, n):
    p = n["params"]
    t = n["type"]
    addr = f"{n['server']}:{n['port']}"

    if t == "reality":
        parts = [f"vless={addr}", "method=none", f"password={p['uuid']}"]
        net = p.get("network", "tcp")
        if net == "grpc":
            parts.append("obfs=grpc")
            parts.append(f"obfs-uri={p.get('serviceName','grpc')}")
        else:
            parts.append("obfs=over-tls")
        parts.append(f"obfs-host={p.get('sni','')}")
        parts.append(f"reality-base64-pubkey={p.get('pbk','')}")
        if p.get("sid"):
            parts.append(f"reality-hex-shortid={p['sid']}")
        if p.get("flow"):
            parts.append(f"vless-flow={p['flow']}")
        parts.append("udp-relay=true")
        parts.append(f"tag={tag}")
        return ",".join(parts)

    if t == "vless":
        parts = [f"vless={addr}", "method=none", f"password={p['uuid']}"]
        net = p.get("network", "tcp")
        if net == "ws":
            parts.append("obfs=wss" if p.get("tls") else "obfs=ws")
            parts.append(f"obfs-uri={p.get('path','/')}")
            parts.append(f"obfs-host={p.get('host','')}")
        elif p.get("tls"):
            parts.append("obfs=over-tls")
            parts.append(f"obfs-host={p.get('sni','')}")
        parts.append("udp-relay=true")
        parts.append(f"tag={tag}")
        return ",".join(parts)

    if t == "vmess":
        parts = [f"vmess={addr}", "method=aes-128-gcm", f"password={p['uuid']}"]
        net = p.get("network", "tcp")
        if net == "ws":
            parts.append("obfs=wss" if p.get("tls") else "obfs=ws")
            parts.append(f"obfs-uri={p.get('path','/')}")
            parts.append(f"obfs-host={p.get('host','')}")
        elif p.get("tls"):
            parts.append("obfs=over-tls")
            parts.append(f"obfs-host={p.get('sni','')}")
        parts.append("udp-relay=true")
        parts.append(f"tag={tag}")
        return ",".join(parts)

    if t in ("shadowsocks", "ss"):
        return f"shadowsocks={addr},method={p['method']},password={p['password']},udp-relay=true,tag={tag}"

    if t == "trojan":
        parts = [f"trojan={addr}", f"password={p['password']}", "over-tls=true",
                 f"tls-host={p.get('sni','')}", "tls-verification=true", "udp-relay=true", f"tag={tag}"]
        return ",".join(parts)

    return None


def _build_nodes_with_tags(nodes):
    from .common import node_display_name
    counter = {}
    lines = []
    groups = {}
    for n in nodes:
        tag = node_display_name(n, counter)
        line = _node_line(tag, n)
        if line:
            lines.append(line)
            groups.setdefault(n.get("region", "other"), []).append(tag)
    return "\n".join(lines), groups


def build_nodes(nodes):
    return _build_nodes_with_tags(nodes)[0]


def generate(nodes, template=None):
    node_text, groups_by_region = _build_nodes_with_tags(nodes)
    if template and PLACEHOLDER in template:
        return template.replace(PLACEHOLDER, node_text)
    policy_lines = []
    region_group_names = []
    for r in sort_regions(groups_by_region.keys()):
        tags = groups_by_region[r]
        gname = f"{region_label(r)}节点"
        region_group_names.append(gname)
        policy_lines.append(f"url-latency-benchmark={gname}, {', '.join(tags)}, check-interval=300, tolerance=0")
    choices = ", ".join(region_group_names + ["direct"]) if region_group_names else "direct"
    return f"""[general]
server_check_url=http://cp.cloudflare.com/generate_204

[server_local]
{node_text}

[policy]
static=节点选择, {choices}
{chr(10).join(policy_lines)}

[filter_local]
final, 节点选择
"""
