"""
Shadowrocket 生成器
- 节点版 (target=shadowrocket): base64 的节点 URI 列表, 小火箭自动解析 (reality/hy2/tuic 全支持)
- 配置版 (target=shadowrocket-conf): 纯规则 .conf
  小火箭 .conf 的 reality 节点字段不被识别, 所以节点与配置分开:
  用户先加节点订阅(shadowrocket), 再加配置(conf), conf 的 select 组会并入订阅节点。
_surge_line 保留备用(若将来小火箭支持 reality 键值可启用), 当前 conf 不放节点。
"""
from . import base64_uri
from .common import node_display_name

PLACEHOLDER = "{{NODES}}"

# 节点版: 直接复用 base64 URI 列表
generate_nodes = base64_uri.generate


def _surge_line(name, n):
    """小火箭 .conf [Proxy] 段的 Surge 键值格式节点行"""
    t = n["type"]
    p = n["params"]
    server = n["server"]
    port = n["port"]

    if t == "shadowsocks" or t == "ss":
        return f"{name} = ss,{server},{port},encrypt-method={p['method']},password={p['password']},udp=1"

    if t == "reality":
        # 小火箭 vless+reality: 社区常见写法
        parts = [f"{name} = vless", server, str(port),
                 f"password={p['uuid']}", "tls=true",
                 f"sni={p.get('sni','')}",
                 f"public-key={p.get('pbk','')}",
                 f"short-id={p.get('sid','')}"]
        if p.get("flow"):
            parts.append(f"flow={p['flow']}")
        if p.get("fp"):
            parts.append(f"fingerprint={p['fp']}")
        parts.append("udp=1")
        return ",".join(parts)

    if t == "vless":
        parts = [f"{name} = vless", server, str(port), f"password={p['uuid']}"]
        if p.get("tls"):
            parts.append("tls=true")
            if p.get("sni"):
                parts.append(f"sni={p['sni']}")
        if p.get("network") == "ws":
            parts.append("obfs=websocket")
            parts.append(f"obfs-uri={p.get('path','/')}")
            if p.get("host"):
                parts.append(f"obfs-host={p['host']}")
        parts.append("udp=1")
        return ",".join(parts)

    if t in ("hysteria2", "hy2"):
        parts = [f"{name} = hysteria2", server, str(port), f"auth={p.get('password','')}", "udp=1"]
        if p.get("sni"):
            parts.append(f"peer={p['sni']}")
        parts.append("alpn=h3")
        if p.get("insecure"):
            parts.append("skip-cert-verify=true")
        return ",".join(parts)

    if t == "tuic":
        parts = [f"{name} = tuic", server, str(port), f"password={p.get('password','')}",
                 f"user={p.get('uuid','')}", "udp=1"]
        if p.get("sni"):
            parts.append(f"peer={p['sni']}")
        parts.append(f"alpn={p.get('alpn','h3')}")
        if p.get("insecure"):
            parts.append("skip-cert-verify=true")
        return ",".join(parts)

    if t == "vmess":
        parts = [f"{name} = vmess", server, str(port), f"username={p['uuid']}"]
        if p.get("tls"):
            parts.append("tls=true")
            if p.get("sni"):
                parts.append(f"sni={p['sni']}")
        if p.get("network") == "ws":
            parts.append("obfs=websocket")
            parts.append(f"obfs-uri={p.get('path','/')}")
            if p.get("host"):
                parts.append(f"obfs-host={p['host']}")
        parts.append("udp=1")
        return ",".join(parts)

    if t == "trojan":
        parts = [f"{name} = trojan", server, str(port), f"password={p.get('password','')}"]
        if p.get("sni"):
            parts.append(f"sni={p['sni']}")
        parts.append("udp=1")
        return ",".join(parts)

    return None


def build_nodes(nodes):
    counter = {}
    lines = []
    names = []
    for n in nodes:
        name = node_display_name(n, counter)
        line = _surge_line(name, n)
        if line:
            lines.append(line)
            names.append(name)
    return "\n".join(lines), names


def generate_conf(nodes, template=None):
    """配置版 .conf: 纯规则模式
    小火箭 .conf 的 reality 节点字段不被识别, 所以拆分:
      - 节点走 shadowrocket 节点订阅 (target=shadowrocket, 小火箭自动解析 URI)
      - 配置(本函数)只提供规则, [Proxy] 段留空让小火箭并入订阅节点
    模板里 {{NODES}} 留空, {{NODE_NAMES}} 用占位策略(小火箭会把已导入节点并入 select 组)
    """
    if template and (PLACEHOLDER in template or "{{NODE_NAMES}}" in template):
        # [Proxy] 段留空(不放节点, 避免 reality 字段不识别问题)
        result = template.replace(PLACEHOLDER, "")
        # 节点选择组: 只放内置策略, 小火箭会自动把订阅节点并入此 select 组
        result = result.replace("{{NODE_NAMES}}", "PROXY, DIRECT")
        return result
    # 无模板兜底: 最小纯规则配置
    return """[General]
bypass-system = true
dns-server = system
[Proxy Group]
节点选择 = select, PROXY, DIRECT
[Rule]
GEOIP,CN,DIRECT
FINAL,节点选择
"""
