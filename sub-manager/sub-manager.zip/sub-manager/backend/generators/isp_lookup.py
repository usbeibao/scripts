"""
ISP 查询: 查节点 server 的 IP 归属(ASN/ISP), 映射成统一短名。
用于节点命名 地区-运营商-协议 (如 香港-HGC-VLESS)。
sub-manager 在墙外, 查询通畅。查不到则返回空(命名降级为 地区-协议)。
"""
import json
import re
import socket
import urllib.request

# 通用 ISP 映射: 关键词(小写) -> 短名(大写显示)
# 匹配 ip-api 返回的 isp/org/as 字段里的关键词。常见全球+亚太线路。
ISP_KEYWORDS = [
    # 香港
    ("hgc", "HGC"), ("hutchison", "HGC"),
    ("hkt", "HKT"), ("pccw", "HKT"),
    ("china mobile", "CMI"), ("cmi", "CMI"), ("cmhk", "CMI"),
    ("china telecom", "CTG"), ("ctg", "CTG"), ("chinanet", "CTG"),
    ("china unicom", "CUG"), ("unicom", "CUG"),
    ("cn2", "CN2"),
    ("hkbn", "HKBN"), ("wtt", "WTT"),
    # 日本
    ("iij", "IIJ"), ("ntt", "NTT"), ("kddi", "KDDI"), ("softbank", "SoftBank"),
    ("sakura", "Sakura"), ("vultr", "Vultr"), ("linode", "Linode"),
    # 美国/通用云
    ("amazon", "AWS"), ("aws", "AWS"), ("google", "GCP"),
    ("microsoft", "Azure"), ("azure", "Azure"),
    ("digitalocean", "DO"), ("oracle", "Oracle"),
    ("cloudflare", "CF"), ("hetzner", "Hetzner"),
    ("ovh", "OVH"), ("leaseweb", "LeaseWeb"),
    ("cogent", "Cogent"), ("gtt", "GTT"), ("telia", "Telia"),
    # 新加坡
    ("singtel", "Singtel"), ("starhub", "StarHub"),
    # 韩国
    ("kt corp", "KT"), ("sk broadband", "SKB"), ("lg uplus", "LGU"),
    # 通用 IDC
    ("dmit", "DMIT"), ("bandwagon", "BWG"), ("racknerd", "RackNerd"),
    ("gcore", "Gcore"), ("akamai", "Akamai"),
]


def resolve_ip(server):
    """域名或IP -> IP。已是IP直接返回; 域名解析(取第一个A记录)"""
    if re.match(r"^\d{1,3}(\.\d{1,3}){3}$", server):
        return server
    try:
        return socket.gethostbyname(server)
    except Exception:
        return None


def _query_ipapi(ip):
    """ip-api.com 查归属, 返回 (isp_raw, org_raw, as_raw) 或 None"""
    try:
        url = f"http://ip-api.com/json/{ip}?fields=status,isp,org,as"
        req = urllib.request.Request(url, headers={"User-Agent": "sub-manager"})
        with urllib.request.urlopen(req, timeout=6) as r:
            data = json.loads(r.read().decode())
        if data.get("status") == "success":
            return (data.get("isp", ""), data.get("org", ""), data.get("as", ""))
    except Exception:
        pass
    return None


def isp_short(server):
    """
    查 server(域名/IP) 的运营商短名。
    查不到返回 "" (命名降级为 地区-协议)。
    """
    ip = resolve_ip(server)
    if not ip:
        return ""
    res = _query_ipapi(ip)
    if not res:
        return ""
    # 合并 isp/org/as 文本做关键词匹配
    haystack = " ".join(res).lower()
    for kw, short in ISP_KEYWORDS:
        if kw in haystack:
            return short
    return ""  # 认不出运营商, 降级


def isp_short_cached(server, cache):
    """带缓存的查询(同 server 不重复查; cache 是调用方传入的 dict)"""
    if server in cache:
        return cache[server]
    v = isp_short(server)
    cache[server] = v
    return v
