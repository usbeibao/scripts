"""
Clash / Mihomo YAML 生成器 (Clash Verge)
固定分组模式: 按 region 字段自动归地区组, 手动列节点。
流媒体走全地区兜底(fallback), 对齐用户 Loon 现状。
港台流媒体候选 = 香港+台湾。规则用 GEOSITE 内置。
"""
import yaml
from .common import region_label, node_display_name, REGION_FILTER_REGEX, sort_regions


def _name(node, counter=None):
    return node_display_name(node, counter)


def node_to_clash(n, counter=None):
    p = n["params"]
    t = n["type"]
    name = _name(n, counter)
    base = {"name": name, "server": n["server"], "port": int(n["port"])}

    if t == "reality":
        d = {**base, "type": "vless", "uuid": p["uuid"], "network": p.get("network", "tcp"),
             "tls": True, "udp": True, "servername": p.get("sni", ""),
             "reality-opts": {"public-key": p.get("pbk", ""), "short-id": p.get("sid", "")},
             "client-fingerprint": p.get("fp", "chrome")}
        if p.get("flow"):
            d["flow"] = p["flow"]
        if p.get("network") == "grpc":
            d["grpc-opts"] = {"grpc-service-name": p.get("serviceName", "grpc")}
        return d
    if t == "vless":
        d = {**base, "type": "vless", "uuid": p["uuid"], "network": p.get("network", "tcp"), "udp": True}
        if p.get("tls"):
            d["tls"] = True; d["servername"] = p.get("sni", "")
        if p.get("network") == "ws":
            d["ws-opts"] = {"path": p.get("path", "/"), "headers": {"Host": p.get("host", "")}}
        if p.get("flow"):
            d["flow"] = p["flow"]
        return d
    if t == "vmess":
        d = {**base, "type": "vmess", "uuid": p["uuid"], "alterId": int(p.get("alterId", 0)),
             "cipher": p.get("security", "auto"), "network": p.get("network", "tcp"), "udp": True}
        if p.get("tls"):
            d["tls"] = True; d["servername"] = p.get("sni", "")
        if p.get("network") == "ws":
            d["ws-opts"] = {"path": p.get("path", "/"), "headers": {"Host": p.get("host", "")}}
        return d
    if t in ("shadowsocks", "ss"):
        return {**base, "type": "ss", "cipher": p["method"], "password": p["password"], "udp": True}
    if t == "trojan":
        d = {**base, "type": "trojan", "password": p["password"], "udp": True, "sni": p.get("sni", "")}
        if p.get("network") == "ws":
            d["network"] = "ws"
            d["ws-opts"] = {"path": p.get("path", "/"), "headers": {"Host": p.get("host", "")}}
        return d
    if t in ("hysteria2", "hy2"):
        d = {**base, "type": "hysteria2", "password": p.get("password", ""),
             "sni": p.get("sni", ""), "skip-cert-verify": bool(p.get("insecure", False))}
        if p.get("obfs"):
            d["obfs"] = p["obfs"]; d["obfs-password"] = p.get("obfs_pass", "")
        return d
    if t == "tuic":
        return {**base, "type": "tuic", "uuid": p.get("uuid", ""), "password": p.get("password", ""),
                "sni": p.get("sni", ""), "alpn": [p.get("alpn", "h3")],
                "congestion-controller": p.get("congestion", "bbr"),
                "skip-cert-verify": bool(p.get("insecure", False)), "udp-relay-mode": "native"}
    return None


# target 特殊值映射 (地区码→组名 在 generate 里动态处理; 特殊词如下)
SPECIAL_TARGETS = {
    "兜底": "🔄 兜底后备",
    "节点选择": "🚀 节点选择",
    "流媒体": "流媒体",
    "港台流媒体": "港台流媒体",
    "直连": "DIRECT",
    "拒绝": "REJECT",
}

CHECK_URL = "http://www.gstatic.com/generate_204"


def generate_from_template(nodes, template, classic=False):
    """
    模板模式: 用户提供完整 Clash 配置模板。
      {{PROXIES}} -> 所有节点完整 YAML 定义
    地区组用 mihomo 的 include-all:true + filter:正则 (动态匹配, 零维护)。
    classic=True: 把 include-all+filter 组展开成显式 proxies 列表(老核兼容)。
    """
    import re as _re
    proxies = []
    _counter = {}
    for n in nodes:
        c = node_to_clash(n, _counter)
        if c:
            proxies.append(c)

    out = []
    for line in template.split("\n"):
        stripped = line.strip()
        indent = line[:len(line) - len(line.lstrip())]
        if "{{PROXIES}}" in stripped:
            if proxies:
                block = yaml.dump(proxies, allow_unicode=True, sort_keys=False,
                                  default_flow_style=False)
                for bl in block.rstrip("\n").split("\n"):
                    out.append(indent + bl)
            else:
                out.append(indent + "- {name: DIRECT, type: direct}")
            continue
        out.append(line)
    result = "\n".join(out)

    if not classic:
        return result  # mihomo: include-all/filter 原样保留

    # classic: include-all+filter 组展开成显式节点列表(老核不支持include-all)
    # 并做 subconverter 式动态: 空地区组删除 + 清理所有引用
    try:
        cfg = yaml.safe_load(result)
    except yaml.YAMLError:
        return result
    if not isinstance(cfg, dict) or "proxy-groups" not in cfg:
        return result
    valid = {p["name"] for p in cfg.get("proxies", []) if isinstance(p, dict)}

    removed = set()  # 被删除的空组名
    kept_groups = []
    for g in cfg["proxy-groups"]:
        if g.get("include-all"):
            pat = g.pop("filter", None)
            g.pop("include-all", None)
            if pat:
                try:
                    matched = [nm for nm in valid if _re.search(pat, nm)]
                except _re.error:
                    matched = []
            else:
                matched = list(valid)
            existing = g.get("proxies", [])
            g["proxies"] = existing + matched
            # 空组(无任何成员): 标记删除
            if not g["proxies"]:
                removed.add(g["name"])
                continue
        kept_groups.append(g)

    # 迭代清理引用: 删除组后, 某组可能因引用全是被删组而再次变空, 循环到稳定
    changed = True
    while changed:
        changed = False
        survivors = []
        for g in kept_groups:
            if g["name"] in removed:
                continue
            new_proxies = [p for p in g.get("proxies", []) if p not in removed]
            if new_proxies != g.get("proxies", []):
                g["proxies"] = new_proxies
            # select/url-test 组清空后无意义: 删除并标记(下轮清理引用)
            if not new_proxies:
                removed.add(g["name"])
                changed = True
                continue
            survivors.append(g)
        kept_groups = survivors

    cfg["proxy-groups"] = kept_groups

    # rules 里引用了被删组的, 重定向到 DIRECT (避免规则指向不存在的组)
    if "rules" in cfg and removed:
        new_rules = []
        for r in cfg["rules"]:
            parts = [x.strip() for x in str(r).split(",")]
            # 规则目标通常是最后一段(或no-resolve前一段)
            if len(parts) >= 2:
                tgt_idx = -2 if parts[-1] == "no-resolve" else -1
                if parts[tgt_idx] in removed:
                    parts[tgt_idx] = "DIRECT"
                    r = ",".join(parts)
            new_rules.append(r)
        cfg["rules"] = new_rules

    return yaml.dump(cfg, allow_unicode=True, sort_keys=False, default_flow_style=False)


def generate(nodes, extra_subconverter_yaml=None, clash_rules=None, template=None, classic=False):
    # 有模板则走模板模式 (用户完整配置 + 占位符填节点)
    if template and "{{" in template:
        return generate_from_template(nodes, template, classic=classic)

    proxies = []
    node_region = {}  # name -> region
    _counter = {}
    for n in nodes:
        c = node_to_clash(n, _counter)
        if c:
            proxies.append(c)
            node_region[c["name"]] = n.get("region", "other")

    if extra_subconverter_yaml:
        try:
            extra = yaml.safe_load(extra_subconverter_yaml)
            if isinstance(extra, dict) and extra.get("proxies"):
                for ep in extra["proxies"]:
                    proxies.append(ep)
                    node_region[ep["name"]] = "other"
        except yaml.YAMLError:
            pass

    names = [p["name"] for p in proxies]

    # 按 region 归地区组
    region_members = {}
    for name, r in node_region.items():
        region_members.setdefault(r, []).append(name)

    groups = []
    region_group_names = []
    region_group_map = {}  # region -> 组名
    for r in sort_regions(region_members.keys()):
        gname = f"{region_label(r)}节点"
        region_group_map[r] = gname
        region_group_names.append(gname)

    # 主选择组只放自动/兜底/地区组，不再直接塞所有单节点，节点多时界面更干净
    groups.append({"name": "🚀 节点选择", "type": "select",
                   "proxies": ["♻️ 自动选择", "🔄 兜底后备"] + region_group_names})
    groups.append({"name": "♻️ 自动选择", "type": "url-test",
                   "proxies": names or ["DIRECT"], "url": CHECK_URL, "interval": 300})
    groups.append({"name": "🔄 兜底后备", "type": "fallback",
                   "proxies": region_group_names or names or ["DIRECT"],
                   "url": CHECK_URL, "interval": 60})
    for r, members in region_members.items():
        groups.append({"name": region_group_map[r], "type": "url-test",
                       "proxies": members, "url": CHECK_URL, "interval": 300})

    stream_choices = ["🔄 兜底后备", "🚀 节点选择"] + region_group_names
    groups.append({"name": "流媒体", "type": "select", "proxies": stream_choices})

    ht_groups = []
    for r in ("hk", "tw"):
        if r in region_group_map:
            ht_groups.append(region_group_map[r])
    ht_choices = ht_groups + ["🔄 兜底后备", "🚀 节点选择"]
    groups.append({"name": "港台流媒体", "type": "select", "proxies": ht_choices})

    groups.append({"name": "🐟 漏网之鱼", "type": "select",
                   "proxies": ["🚀 节点选择", "🔄 兜底后备", "DIRECT"]})

    # 解析规则目标: 地区码→该地区组名(不存在则兜底); 特殊词→映射; 其它原样(需是已存在组)
    def resolve_target(t):
        if t in region_group_map:        # 地区码如 us/hk
            return region_group_map[t]
        if t in SPECIAL_TARGETS:         # 特殊词
            return SPECIAL_TARGETS[t]
        # 已是组名(如"美国节点"/"流媒体")且存在
        existing = {g["name"] for g in groups}
        if t in existing or t in ("DIRECT", "REJECT"):
            return t
        return "🔄 兜底后备"              # 兜底: 指向不存在的目标时回退

    rules_def = clash_rules if clash_rules is not None else []
    rules = []
    for item in rules_def:
        rule_kw = item.get("rule", "")
        target = resolve_target(item.get("target", "兜底"))
        if rule_kw:
            rules.append(f"GEOSITE,{rule_kw},{target}")
    rules += [
        "GEOSITE,geolocation-!cn,🚀 节点选择",
        "GEOSITE,cn,DIRECT",
        "GEOIP,CN,DIRECT,no-resolve",
        "MATCH,🐟 漏网之鱼",
    ]

    config = {
        "mixed-port": 7890,
        "allow-lan": False,
        "mode": "rule",
        "log-level": "info",
        "proxies": proxies,
        "proxy-groups": groups,
        "rules": rules,
    }
    return yaml.dump(config, allow_unicode=True, sort_keys=False, default_flow_style=False)


def generate_nodes(nodes):
    """Clash 节点订阅：最小可导入配置，只含节点和地区分组。"""
    return generate(nodes, template=None, classic=True)
