"""
base64 URI 生成器 (Shadowrocket / v2rayN)
把每个节点转成标准分享链接, 每行一个, 整体 base64 编码。

节点 params 字段约定 (JSON):
  reality:  {uuid, flow, pbk, sid, sni, fp, network(tcp/grpc), serviceName(grpc用)}
  hysteria2:{password, sni, insecure(bool), obfs?, obfs_pass?}
  tuic:     {uuid, password, sni, alpn, congestion, insecure(bool)}
  vmess:    {uuid, alterId, network, path, host, tls(bool), sni}
  shadowsocks:{method, password}
  trojan:   {password, sni, network, path, host}
"""
import base64
import json
from urllib.parse import quote, urlencode

from .common import region_label


def _tag(node):
    """节点备注: [地区]名称; 占位节点用原名"""
    if node.get("id") == -1:
        return node["name"]
    return f"{region_label(node.get('region','other'))}-{node['name']}"


def reality_uri(n):
    p = n["params"]
    q = {
        "encryption": "none",
        "security": "reality",
        "sni": p.get("sni", ""),
        "fp": p.get("fp", "chrome"),
        "pbk": p.get("pbk", ""),
        "sid": p.get("sid", ""),
        "type": p.get("network", "tcp"),
        "headerType": "none",
    }
    if p.get("network", "tcp") == "tcp":
        q["spx"] = p.get("spx", "/")
    if p.get("flow"):
        q["flow"] = p["flow"]
    if p.get("network") == "grpc":
        q["serviceName"] = p.get("serviceName", "grpc")
        q["mode"] = p.get("mode", "multi")
    qs = urlencode({k: v for k, v in q.items() if v != ""})
    return f"vless://{p['uuid']}@{n['server']}:{n['port']}?{qs}#{quote(_tag(n))}"


def vless_uri(n):
    """普通 VLESS (非 reality, 走 tls/ws 等)"""
    p = n["params"]
    q = {
        "encryption": "none",
        "type": p.get("network", "tcp"),
        "security": "tls" if p.get("tls") else "none",
        "headerType": "none",
    }
    if p.get("tls"):
        if p.get("sni"):
            q["sni"] = p["sni"]
    if p.get("network") == "ws":
        q["path"] = p.get("path", "/")
        if p.get("host"):
            q["host"] = p["host"]
    if p.get("flow"):
        q["flow"] = p["flow"]
    qs = urlencode({k: v for k, v in q.items() if v != ""})
    return f"vless://{p['uuid']}@{n['server']}:{n['port']}?{qs}#{quote(_tag(n))}"


def hysteria2_uri(n):
    p = n["params"]
    q = {}
    if p.get("sni"):
        q["sni"] = p["sni"]
    if p.get("insecure"):
        q["insecure"] = "1"
    if p.get("obfs"):
        q["obfs"] = p["obfs"]
        q["obfs-password"] = p.get("obfs_pass", "")
    qs = urlencode({k: v for k, v in q.items() if v != ""})
    pw = p.get("password", "")
    return f"hysteria2://{quote(pw)}@{n['server']}:{n['port']}?{qs}#{quote(_tag(n))}"


def tuic_uri(n):
    p = n["params"]
    q = {
        "congestion_control": p.get("congestion", "bbr"),
        "alpn": p.get("alpn", "h3"),
    }
    if p.get("sni"):
        q["sni"] = p["sni"]
    if p.get("insecure"):
        q["allow_insecure"] = "1"
    qs = urlencode({k: v for k, v in q.items() if v != ""})
    uuid = p.get("uuid", "")
    pw = p.get("password", "")
    return f"tuic://{uuid}:{quote(pw)}@{n['server']}:{n['port']}?{qs}#{quote(_tag(n))}"


def vmess_uri(n):
    """vmess:// 是 base64(JSON) 格式"""
    p = n["params"]
    obj = {
        "v": "2",
        "ps": _tag(n),
        "add": n["server"],
        "port": str(n["port"]),
        "id": p["uuid"],
        "aid": str(p.get("alterId", 0)),
        "scy": p.get("security", "auto"),
        "net": p.get("network", "tcp"),
        "type": "none",
        "host": p.get("host", ""),
        "path": p.get("path", ""),
        "tls": "tls" if p.get("tls") else "",
        "sni": p.get("sni", ""),
    }
    raw = json.dumps(obj, ensure_ascii=False)
    return "vmess://" + base64.b64encode(raw.encode()).decode()


def shadowsocks_uri(n):
    p = n["params"]
    # v2rayN 兼容性更好的 legacy 写法：ss://base64(method:password@host:port)#tag
    # 密码中可能自带 =，整体再做一次 URL-safe base64，避免客户端把 @/: 拆错。
    raw = f"{p['method']}:{p['password']}@{n['server']}:{n['port']}"
    b64 = base64.urlsafe_b64encode(raw.encode()).decode().rstrip("=")
    return f"ss://{b64}#{quote(_tag(n))}"


def trojan_uri(n):
    p = n["params"]
    q = {
        "security": "tls",
        "type": p.get("network", "tcp"),
        "headerType": "none",
    }
    if p.get("sni"):
        q["sni"] = p["sni"]
    if p.get("network") == "ws":
        q["path"] = p.get("path", "/")
        if p.get("host"):
            q["host"] = p["host"]
    qs = urlencode({k: v for k, v in q.items() if v != ""})
    suffix = f"?{qs}" if qs else ""
    return f"trojan://{quote(p['password'])}@{n['server']}:{n['port']}{suffix}#{quote(_tag(n))}"


_DISPATCH = {
    "reality": reality_uri,
    "vless": vless_uri,
    "vmess": vmess_uri,
    "shadowsocks": shadowsocks_uri,
    "ss": shadowsocks_uri,
    "trojan": trojan_uri,
    "hysteria2": hysteria2_uri,
    "hy2": hysteria2_uri,
    "tuic": tuic_uri,
}


def node_to_uri(n):
    fn = _DISPATCH.get(n["type"])
    if not fn:
        return None
    try:
        return fn(n)
    except (KeyError, TypeError):
        return None  # 参数不全的节点跳过


def generate(nodes):
    """返回 base64 编码后的订阅内容"""
    lines = []
    for n in nodes:
        uri = node_to_uri(n)
        if uri:
            lines.append(uri)
    # v2rayN/v2rayNG 订阅格式是「每行一个分享链接，然后整体 base64」。
    # 保留末尾换行，兼容部分客户端对最后一行解析较严格的情况。
    raw = "\n".join(lines)
    if raw:
        raw += "\n"
    return base64.b64encode(raw.encode()).decode()


def generate_plain_subscription(nodes):
    """返回未 base64 的节点链接列表；用于客户端扫码/调试，不作为 v2rayN 订阅默认输出。"""
    raw = "\n".join(filter(None, (node_to_uri(n) for n in nodes)))
    return raw + ("\n" if raw else "")


def generate_plain(nodes):
    """不编码的纯链接列表 (调试用)"""
    return "\n".join(filter(None, (node_to_uri(n) for n in nodes)))
