"""
Loon 生成器 (模板占位符模式)
只生成 [Proxy] 段的节点行, 注入用户模板的 {{NODES}} 占位符。
节点行字段严格对齐用户真实配置:
  reality: 名称 = VLESS,server,port,"uuid",transport=tcp,flow=xtls-rprx-vision,
           public-key="pbk",udp=true,block-quic=true,over-tls=true,sni=<伪装域名>
  vmess:   名称 = vmess,server,port,auto,"uuid",transport=ws,path=/xxx,host=xxx,
           over-tls=true,sni=xxx,udp=true
命名: 纯中文地区名+序号 (配合用户的 server-tag-regex 正则分组)
"""
from .common import region_label, sort_regions

PLACEHOLDER = "{{NODES}}"


def _node_line(name, n):
    p = n["params"]
    t = n["type"]
    s, port = n["server"], n["port"]

    if t == "reality":
        # Reality: VLESS + public-key + block-quic + over-tls + sni(伪装域名)
        # sni 是伪装域名(如 gateway.icloud.com), 不是自己的服务器域名
        parts = [f'{name} = VLESS', s, str(port), f'"{p["uuid"]}"',
                 "transport=" + p.get("network", "tcp")]
        if p.get("flow"):
            parts.append(f'flow={p["flow"]}')
        parts.append(f'public-key="{p.get("pbk", "")}"')
        if p.get("sid"):
            parts.append(f'short-id={p["sid"]}')
        if p.get("network") == "grpc":
            parts.append(f'grpc-service-name={p.get("serviceName", "grpc")}')
        parts += ["udp=true", "block-quic=true", "over-tls=true",
                  f'sni={p.get("sni", "")}']
        return ",".join(parts)

    if t == "vless":
        parts = [f'{name} = VLESS', s, str(port), f'"{p["uuid"]}"',
                 "transport=" + p.get("network", "tcp")]
        if p.get("network") == "ws":
            parts.append(f'path={p.get("path", "/")}')
            parts.append(f'host={p.get("host", "")}')
        if p.get("tls"):
            parts += ["over-tls=true", f'sni={p.get("sni", "")}']
        parts.append("udp=true")
        return ",".join(parts)

    if t == "vmess":
        # vmess: 无 block-quic (那是 reality 专属)
        parts = [f'{name} = vmess', s, str(port), "auto", f'"{p["uuid"]}"',
                 "transport=" + p.get("network", "tcp")]
        if p.get("network") == "ws":
            parts.append(f'path={p.get("path", "/")}')
            parts.append(f'host={p.get("host", "")}')
        if p.get("tls"):
            parts += ["over-tls=true", f'sni={p.get("sni", "")}']
        parts.append("udp=true")
        return ",".join(parts)

    if t in ("shadowsocks", "ss"):
        return f'{name} = shadowsocks,{s},{port},{p["method"]},"{p["password"]}",udp=true'

    if t == "trojan":
        parts = [f'{name} = trojan', s, str(port), f'"{p["password"]}"',
                 f'sni={p.get("sni", "")}']
        if p.get("network") == "ws":
            parts += ["transport=ws", f'path={p.get("path", "/")}',
                      f'host={p.get("host", "")}']
        parts.append("udp=true")
        return ",".join(parts)

    if t in ("hysteria2", "hy2"):
        parts = [f'{name} = Hysteria2', s, str(port), f'"{p.get("password", "")}"',
                 f'sni={p.get("sni", "")}']
        if p.get("insecure"):
            parts.append("skip-cert-verify=true")
        parts.append("udp=true")
        return ",".join(parts)

    return None


def _build_nodes_with_names(nodes):
    """生成节点行，同时保留 name->region，方便配置按地区分组。"""
    from .common import node_display_name
    counter = {}
    lines = []
    groups = {}
    for n in nodes:
        name = node_display_name(n, counter)
        line = _node_line(name, n)
        if line:
            lines.append(line)
            groups.setdefault(n.get("region", "other"), []).append(name)
    return "\n".join(lines), groups


def build_nodes(nodes):
    """生成节点行文本 (统一命名 地区-协议; 占位节点用原名)"""
    return _build_nodes_with_names(nodes)[0]


def generate(nodes, template=None):
    node_text, groups_by_region = _build_nodes_with_names(nodes)
    if template and PLACEHOLDER in template:
        return template.replace(PLACEHOLDER, node_text)
    # 无模板兜底: 最小可用配置，按地区组承接节点，避免主选择组塞满单节点
    group_lines = []
    region_group_names = []
    for r in sort_regions(groups_by_region.keys()):
        names = groups_by_region[r]
        gname = f"{region_label(r)}节点"
        region_group_names.append(gname)
        group_lines.append(f"{gname} = url-test, {', '.join(names)}, interval=300")
    choices = ", ".join(region_group_names + ["DIRECT"]) if region_group_names else "DIRECT"
    return f"""[General]
ip-mode = v4-only
dns-server = system

[Proxy]
{node_text}

[Proxy Group]
节点选择 = select, {choices}
{chr(10).join(group_lines)}

[Rule]
GEOIP,CN,DIRECT
FINAL,节点选择
"""
