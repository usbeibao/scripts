"""
生成器公共: 客户端协议支持矩阵 + 节点过滤
不同客户端支持的协议不同, 生成订阅时要剔除该客户端不支持的节点。
(基于 2026 年各客户端实际支持情况, 偏保守)
"""

# 各 target 支持的协议集合
# clash(mihomo)/shadowrocket 全支持; v2ray(给v2rayN等)对 hy2/tuic 订阅解析有问题, 排除
# loon/quanx 对 hy2/tuic 支持不稳, 保守只给 reality 系
CLIENT_SUPPORT = {
    "clash":       {"reality", "vless", "vmess", "shadowsocks", "trojan", "hysteria2", "tuic"},
    "clash-classic": {"reality", "vless", "vmess", "shadowsocks", "trojan", "hysteria2", "tuic"},
    "stash":       {"reality", "vless", "vmess", "shadowsocks", "trojan", "hysteria2", "tuic"},
    "clash-nodes": {"reality", "vless", "vmess", "shadowsocks", "trojan", "hysteria2", "tuic"},
    "v2ray":       {"reality", "vless", "vmess", "shadowsocks", "trojan"},  # v2rayN 订阅解析 hy2/tuic 会失败(整个列表空), 排除
    "shadowrocket":{"reality", "vless", "vmess", "shadowsocks", "trojan", "hysteria2", "tuic"},
    "shadowrocket-conf": {"reality", "vless", "vmess", "shadowsocks", "trojan", "hysteria2", "tuic"},
    "loon":        {"reality", "vless", "vmess", "shadowsocks", "trojan", "hysteria2"},  # tuic 不稳, 排除
    "quanx":       {"reality", "vless", "vmess", "shadowsocks", "trojan"},               # hy2/tuic 不支持
}

# 协议类型归一 (数据库 type -> 能力标签)
TYPE_TO_CAP = {
    "reality": "reality",
    "vless": "vless",
    "vmess": "vmess",
    "shadowsocks": "shadowsocks",
    "ss": "shadowsocks",
    "trojan": "trojan",
    "hysteria2": "hysteria2",
    "hy2": "hysteria2",
    "tuic": "tuic",
}


def filter_nodes_for_client(nodes, target):
    """剔除目标客户端不支持的协议节点"""
    supported = CLIENT_SUPPORT.get(target, set())
    out = []
    for n in nodes:
        cap = TYPE_TO_CAP.get(n["type"], n["type"])
        if cap in supported:
            out.append(n)
    return out


def filter_nodes_for_token(nodes, tok):
    """按 token 的 node_filter / region_filter 限制可见节点"""
    nf = set(tok.get("node_filter") or [])
    rf = set(tok.get("region_filter") or [])
    out = []
    for n in nodes:
        if nf and n["id"] not in nf:
            continue
        if rf and n.get("region") not in rf:
            continue
        out.append(n)
    return out


def _match_string(n):
    """正则匹配用的字符串: 原始name + 地区中文名 (最大灵活度)"""
    return f"{n.get('name','')} {region_label(n.get('region','other'))}"


def filter_nodes_by_regex(nodes, include=None, exclude=None):
    """
    include: 只保留名称匹配的 (空=全部保留)
    exclude: 剔除名称匹配的 (空=不剔除)
    正则匹配 原始name + 地区中文名。无效正则忽略该条件。
    """
    import re
    inc_re = exc_re = None
    if include:
        try:
            inc_re = re.compile(include)
        except re.error:
            inc_re = None
    if exclude:
        try:
            exc_re = re.compile(exclude)
        except re.error:
            exc_re = None

    out = []
    for n in nodes:
        s = _match_string(n)
        if inc_re and not inc_re.search(s):
            continue
        if exc_re and exc_re.search(s):
            continue
        out.append(n)
    return out


# 地区显示名 (用于节点备注前缀和分组)
REGION_NAMES = {
    "jp": "日本", "hk": "香港", "us": "美国", "sg": "新加坡",
    "kr": "韩国", "au": "澳大利亚", "nz": "新西兰", "tw": "台湾",
    "uk": "英国", "de": "德国", "other": "其他",
}


def region_label(region):
    return REGION_NAMES.get(region, region)


# 协议显示名 (用于节点命名)
PROTO_LABELS = {
    "reality": "Reality", "vless": "VLESS", "vmess": "VMess",
    "hysteria2": "Hy2", "hy2": "Hy2", "tuic": "TUIC",
    "shadowsocks": "SS", "ss": "SS", "trojan": "Trojan",
}


def proto_label(t):
    return PROTO_LABELS.get(t, t)


def node_display_name(node, region_proto_count=None):
    """
    统一节点命名: 地区-[运营商-]协议 (如 香港-HGC-VLESS; 无运营商则 香港-VLESS)。
    同组合多个时加序号 (香港-HGC-VLESS2)。
    占位节点(id=-1)用原名。
    region_proto_count: 传入 dict 跨节点累计 (区分同组合的多个节点)
    """
    if node.get("id") == -1:
        return node["name"]
    region = region_label(node.get("region", "other"))
    proto = proto_label(node.get("type", "other"))
    isp = (node.get("isp") or "").strip()
    if isp:
        base = f"{region}-{isp}-{proto}"
    else:
        base = f"{region}-{proto}"
    if region_proto_count is not None:
        region_proto_count[base] = region_proto_count.get(base, 0) + 1
        n = region_proto_count[base]
        if n > 1:
            return f"{base}{n}"
    return base


# 各地区的 filter 正则 (用于 mihomo include-all + filter 动态分组)
REGION_FILTER_REGEX = {
    "jp": "(?i)(日本|jp|japan)",
    "hk": "(?i)(香港|hk|hong\\s?kong)",
    "us": "(?i)(美国|us|united\\s?states|america)",
    "sg": "(?i)(新加坡|sg|singapore|狮城)",
    "kr": "(?i)(韩国|kr|korea)",
    "au": "(?i)(澳大利亚|澳洲|au|australia)",
    "tw": "(?i)(台湾|tw|taiwan)",
    "uk": "(?i)(英国|uk|united\\s?kingdom)",
    "de": "(?i)(德国|de|germany)",
}



# 订阅地区排序：用于配置里的地区组展示，避免节点多时主选择组堆满单节点
REGION_ORDER = ["hk", "jp", "us", "sg", "tw", "kr", "au", "nz", "uk", "de", "other"]

def sort_regions(regions):
    order = {r: i for i, r in enumerate(REGION_ORDER)}
    return sorted(regions, key=lambda r: (order.get(r, 999), region_label(r)))

# 空订阅时的占位提示节点: 让客户端列表显示一行提示文字, 而非空配置报错
# 用一个连不上的地址 (127.0.0.1:1), 协议用各客户端都支持的 shadowsocks
PLACEHOLDER_NODE = {
    "id": -1,
    "name": "无可用节点-请联系管理员",
    "type": "shadowsocks",
    "server": "127.0.0.1",
    "port": 1,
    "region": "other",
    "params": {"method": "aes-128-gcm", "password": "placeholder"},
}


def placeholder_if_empty(nodes):
    """节点为空时返回占位提示节点, 否则原样返回"""
    if not nodes:
        return [dict(PLACEHOLDER_NODE)]
    return nodes


def is_placeholder(n):
    return n.get("id") == -1
