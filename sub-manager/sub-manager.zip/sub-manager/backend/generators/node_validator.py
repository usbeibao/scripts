"""
节点参数完整性校验: 按协议检查每个节点的必需字段是否齐全/合法。
纯 Python 无依赖, 用于抓 "节点参数缺失/非法" 这类配置错 (入库前或面板检测)。
返回问题列表, 空=无问题。
"""

# 各协议必需的 params 字段
REQUIRED_PARAMS = {
    "reality":     ["uuid", "pbk", "sni"],          # sid 可为空(空shortId合法), flow 可选
    "vless":       ["uuid"],
    "vmess":       ["uuid"],
    "hysteria2":   ["password"],
    "tuic":        ["uuid", "password"],
    "shadowsocks": ["method", "password"],
    "trojan":      ["password"],
}


def check_node(node):
    """检查单个节点, 返回问题列表(字符串)。空列表=无问题。"""
    problems = []
    name = node.get("name", "?")
    t = node.get("type", "")
    server = node.get("server", "")
    port = node.get("port")
    params = node.get("params", {}) or {}

    # 通用: server / port
    if not server:
        problems.append(f"[{name}] 缺 server")
    if not port:
        problems.append(f"[{name}] 缺 port")
    else:
        try:
            p = int(port)
            if not (1 <= p <= 65535):
                problems.append(f"[{name}] 端口非法: {port}")
        except (ValueError, TypeError):
            problems.append(f"[{name}] 端口不是数字: {port}")

    # 协议特定必需字段
    if t not in REQUIRED_PARAMS:
        problems.append(f"[{name}] 未知协议类型: {t}")
    else:
        for f in REQUIRED_PARAMS[t]:
            if not params.get(f):
                problems.append(f"[{name}] {t} 缺字段: {f}")

    # reality 特有: pbk 应是 43 字符的 base64(x25519 公钥)
    if t == "reality":
        pbk = params.get("pbk", "")
        if pbk and len(pbk) != 43:
            problems.append(f"[{name}] reality public-key 长度异常({len(pbk)}, 应为43): 可能填错")

    # vmess/vless ws: 应有 path
    if t in ("vmess", "vless") and params.get("network") == "ws":
        if not params.get("path"):
            problems.append(f"[{name}] {t} ws 缺 path")

    return problems


def check_nodes(nodes):
    """检查一批节点, 返回 {总数, 有问题节点数, 问题列表}"""
    all_problems = []
    bad = 0
    for n in nodes:
        probs = check_node(n)
        if probs:
            bad += 1
            all_problems.extend(probs)
    return {
        "total": len(nodes),
        "bad_count": bad,
        "ok_count": len(nodes) - bad,
        "problems": all_problems,
    }


def check_clash_config(yaml_text):
    """
    校验生成的 Clash 配置: YAML 能否解析 + 关键结构 + 无悬空组引用。
    抓 "生成器拼出非法/结构错的配置"。返回问题列表。
    """
    import yaml
    problems = []
    try:
        cfg = yaml.safe_load(yaml_text)
    except yaml.YAMLError as e:
        return [f"YAML 解析失败: {str(e)[:120]}"]
    if not isinstance(cfg, dict):
        return ["配置不是合法的 YAML 字典"]

    proxies = cfg.get("proxies", [])
    groups = cfg.get("proxy-groups", [])
    rules = cfg.get("rules", [])

    if not proxies:
        problems.append("proxies 为空(无节点)")
    if not groups:
        problems.append("proxy-groups 为空")

    # 收集所有合法引用目标: 节点名 + 组名 + 内置策略
    proxy_names = {p.get("name") for p in proxies if isinstance(p, dict)}
    group_names = {g.get("name") for g in groups if isinstance(g, dict)}
    builtin = {"DIRECT", "REJECT", "PASS", "GLOBAL", "COMPATIBLE"}
    valid_refs = proxy_names | group_names | builtin

    # 组内引用悬空检查
    for g in groups:
        if not isinstance(g, dict):
            continue
        gname = g.get("name", "?")
        # include-all 的组不列具体 proxies(mihomo 动态), 跳过引用检查
        if g.get("include-all") or g.get("filter"):
            continue
        for ref in g.get("proxies", []):
            if ref not in valid_refs:
                problems.append(f"组[{gname}] 引用不存在的目标: {ref}")

    # rules 引用的策略组是否存在
    for r in rules:
        parts = [x.strip() for x in str(r).split(",")]
        if len(parts) >= 2:
            tgt = parts[-2] if parts[-1] == "no-resolve" else parts[-1]
            if tgt not in valid_refs and not tgt.startswith("RULE-SET"):
                problems.append(f"规则引用不存在的目标: {tgt} (规则: {str(r)[:40]})")

    return problems
