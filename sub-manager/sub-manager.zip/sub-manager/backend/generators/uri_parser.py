"""
URI 解析: 把分享链接 (vless:// reality, hysteria2:// tuic:// ss:// vmess:// trojan://)
反向解析成节点 dict (server/port/type/params/region/name)。
base64_uri.py 的逆操作。用于粘贴导入。
"""
import base64
import json
import re
from urllib.parse import urlparse, parse_qs, unquote


# 地区猜测: 节点名含这些关键词 -> region
REGION_HINTS = [
    ("jp", ["日本", "东京", "大阪", "jp", "japan", "tokyo", "osaka", "🇯🇵"]),
    ("hk", ["香港", "hk", "hong kong", "hongkong", "🇭🇰"]),
    ("us", ["美国", "美西", "美东", "us", "united states", "america", "los angeles", "🇺🇸"]),
    ("sg", ["新加坡", "狮城", "sg", "singapore", "🇸🇬"]),
    ("kr", ["韩国", "首尔", "kr", "korea", "seoul", "🇰🇷"]),
    ("au", ["澳大利亚", "澳洲", "悉尼", "au", "australia", "sydney", "🇦🇺"]),
    ("tw", ["台湾", "台北", "tw", "taiwan", "taipei", "🇹🇼"]),
    ("uk", ["英国", "伦敦", "uk", "united kingdom", "london", "🇬🇧"]),
    ("de", ["德国", "法兰克福", "de", "germany", "frankfurt", "🇩🇪"]),
]


def guess_region(name):
    low = (name or "").lower()
    for region, kws in REGION_HINTS:
        for kw in kws:
            if kw.lower() in low:
                return region
    return "other"


def _b64decode(s):
    """容错 base64 解码 (补 padding, 兼容 urlsafe)"""
    s = s.strip()
    s = s.replace("-", "+").replace("_", "/")
    s += "=" * (-len(s) % 4)
    return base64.b64decode(s).decode("utf-8", "replace")


def _name_from_fragment(u):
    if "#" in u:
        return unquote(u.split("#", 1)[1])
    return ""


def _q1(qs, key, default=""):
    v = qs.get(key)
    return v[0] if v else default


def parse_vless(uri):
    """vless:// (含 reality 和普通 tls)"""
    name = _name_from_fragment(uri)
    body = uri.split("#", 1)[0]
    p = urlparse(body)
    qs = parse_qs(p.query)
    uuid = unquote(p.username or "")
    server = p.hostname
    port = p.port
    security = _q1(qs, "security")
    params = {
        "uuid": uuid,
        "network": _q1(qs, "type", "tcp"),
    }
    flow = _q1(qs, "flow")
    if flow:
        params["flow"] = flow
    sni = _q1(qs, "sni") or _q1(qs, "peer")
    if sni:
        params["sni"] = sni
    fp = _q1(qs, "fp")
    if fp:
        params["fp"] = fp

    if security == "reality":
        params["pbk"] = _q1(qs, "pbk")
        params["sid"] = _q1(qs, "sid")
        if not params.get("fp"):
            params["fp"] = "chrome"
        ntype = "reality"
    else:
        ntype = "vless"
        if security == "tls":
            params["tls"] = True
        if params["network"] == "ws":
            params["path"] = _q1(qs, "path", "/")
            host = _q1(qs, "host")
            if host:
                params["host"] = host
    return {"type": ntype, "server": server, "port": port, "params": params,
            "name": name, "region": guess_region(name)}


def parse_hysteria2(uri):
    name = _name_from_fragment(uri)
    body = uri.split("#", 1)[0]
    p = urlparse(body)
    qs = parse_qs(p.query)
    params = {"password": unquote(p.username or "")}
    sni = _q1(qs, "sni") or _q1(qs, "peer")
    if sni:
        params["sni"] = sni
    if _q1(qs, "insecure") in ("1", "true"):
        params["insecure"] = True
    obfs = _q1(qs, "obfs")
    if obfs:
        params["obfs"] = obfs
        params["obfs_pass"] = _q1(qs, "obfs-password")
    return {"type": "hysteria2", "server": p.hostname, "port": p.port, "params": params,
            "name": name, "region": guess_region(name)}


def parse_tuic(uri):
    name = _name_from_fragment(uri)
    body = uri.split("#", 1)[0]
    p = urlparse(body)
    qs = parse_qs(p.query)
    # tuic://uuid:password@host:port
    params = {
        "uuid": unquote(p.username or ""),
        "password": unquote(p.password or ""),
        "congestion": _q1(qs, "congestion_control", "bbr"),
        "alpn": _q1(qs, "alpn", "h3"),
    }
    sni = _q1(qs, "sni") or _q1(qs, "peer")
    if sni:
        params["sni"] = sni
    if _q1(qs, "allow_insecure") in ("1", "true"):
        params["insecure"] = True
    return {"type": "tuic", "server": p.hostname, "port": p.port, "params": params,
            "name": name, "region": guess_region(name)}


def parse_ss(uri):
    """ss://  两种格式: base64(method:pass)@host:port  或  base64(method:pass@host:port)"""
    name = _name_from_fragment(uri)
    body = uri.split("#", 1)[0][len("ss://"):]
    if "@" in body:
        cred, hostport = body.rsplit("@", 1)
        try:
            cred = _b64decode(cred)
        except Exception:
            pass
        host, port = hostport.rsplit(":", 1)
    else:
        dec = _b64decode(body)
        cred, hostport = dec.rsplit("@", 1)
        host, port = hostport.rsplit(":", 1)
    method, password = cred.split(":", 1)
    return {"type": "shadowsocks", "server": host, "port": int(port),
            "params": {"method": method, "password": password},
            "name": name, "region": guess_region(name)}


def parse_vmess(uri):
    """vmess:// 是 base64(JSON)"""
    raw = uri[len("vmess://"):]
    # 去掉可能的换行和空格
    raw = raw.strip()
    try:
        obj = json.loads(_b64decode(raw))
    except Exception:
        return None
    name = obj.get("ps", "")
    # port 可能是字符串 "443" 或整数 443
    try:
        port = int(str(obj.get("port", 0)).strip())
    except (ValueError, TypeError):
        port = 0
    params = {
        "uuid": obj.get("id", ""),
        "alterId": int(str(obj.get("aid", 0) or "0").strip() or "0"),
        "network": obj.get("net", "tcp"),
    }
    if obj.get("path"):
        params["path"] = obj["path"]
    if obj.get("host"):
        params["host"] = obj["host"]
    # tls 字段: "tls"、"1"、1、true 都算启用
    tls_val = obj.get("tls", "")
    if tls_val in ("tls", "1", 1, True, "true"):
        params["tls"] = True
    if obj.get("sni"):
        params["sni"] = obj["sni"]
    # add 字段可能带空格
    server = (obj.get("add") or "").strip()
    return {"type": "vmess", "server": server, "port": port,
            "params": params, "name": name, "region": guess_region(name)}


def parse_trojan(uri):
    name = _name_from_fragment(uri)
    body = uri.split("#", 1)[0]
    p = urlparse(body)
    qs = parse_qs(p.query)
    params = {
        "password": unquote(p.username or ""),
        "network": _q1(qs, "type", "tcp"),
    }
    sni = _q1(qs, "sni") or _q1(qs, "peer")
    if sni:
        params["sni"] = sni
    return {"type": "trojan", "server": p.hostname, "port": p.port, "params": params,
            "name": name, "region": guess_region(name)}


PARSERS = {
    "vless://": parse_vless,
    "hysteria2://": parse_hysteria2,
    "hy2://": parse_hysteria2,
    "tuic://": parse_tuic,
    "ss://": parse_ss,
    "vmess://": parse_vmess,
    "trojan://": parse_trojan,
}


def parse_one(line):
    """解析单条链接, 失败返回 None"""
    line = line.strip()
    if not line:
        return None
    for scheme, fn in PARSERS.items():
        if line.startswith(scheme):
            try:
                node = fn(line)
                if node is None:
                    return None
                if node.get("server") and node.get("port"):
                    return node
            except Exception:
                return None
    return None


def parse_text(text):
    """
    解析粘贴的文本: 支持
      - 单条链接
      - 多行链接
      - 整个 base64 订阅 (整段 base64, 解码后多行)
    返回 (nodes, errors): 成功节点列表 + 失败行
    """
    text = (text or "").strip()
    if not text:
        return [], []

    # 尝试整段 base64 订阅 (没有 :// 但能 base64 解码出 :// )
    if "://" not in text:
        try:
            decoded = _b64decode(text)
            if "://" in decoded:
                text = decoded
        except Exception:
            pass

    nodes, errors = [], []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        node = parse_one(line)
        if node:
            nodes.append(node)
        else:
            errors.append(line[:60])
    return nodes, errors
