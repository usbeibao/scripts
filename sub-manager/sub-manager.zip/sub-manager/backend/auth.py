"""
鉴权:
  - 管理员: 密码 (argon2/werkzeug hash) + session cookie, 保护管理面板和 /api/admin/*
  - 部署推送: 单独的 push token (环境变量或 settings), 保护 /api/nodes/push
  - 订阅: URL 里的 token, 保护 /sub/<token>
"""
import os
import time
import functools
from flask import session, request, jsonify
from werkzeug.security import generate_password_hash, check_password_hash

import models

# 部署脚本推送用的 token (优先环境变量, 否则首次启动生成并存 settings)
PUSH_TOKEN_ENV = "PUSH_TOKEN"
_cached_push_token = None

# 登录失败限速：单进程内存版，轻量、无额外依赖。
# 同一 IP 失败 LOGIN_MAX_FAILS 次后，LOGIN_LOCK_SECONDS 秒内拒绝继续尝试。
LOGIN_MAX_FAILS = int(os.environ.get("LOGIN_MAX_FAILS", "5"))
LOGIN_LOCK_SECONDS = int(os.environ.get("LOGIN_LOCK_SECONDS", "60"))
_login_failures = {}


def _client_ip():
    # 如果部署在可信反代后，可以在 app.py 里启用 ProxyFix 后读取 access_route。
    return (request.access_route[0] if request.access_route else request.remote_addr) or "unknown"


def check_login_rate_limit():
    ip = _client_ip()
    now = time.time()
    info = _login_failures.get(ip)
    if not info:
        return None
    count, first_ts = info
    if now - first_ts > LOGIN_LOCK_SECONDS:
        _login_failures.pop(ip, None)
        return None
    if count >= LOGIN_MAX_FAILS:
        retry_after = max(1, int(LOGIN_LOCK_SECONDS - (now - first_ts)))
        return retry_after
    return None


def record_login_failure():
    ip = _client_ip()
    now = time.time()
    count, first_ts = _login_failures.get(ip, (0, now))
    if now - first_ts > LOGIN_LOCK_SECONDS:
        count, first_ts = 0, now
    _login_failures[ip] = (count + 1, first_ts)


def clear_login_failure():
    _login_failures.pop(_client_ip(), None)


def init_admin():
    """首次启动: 若无管理员密码, 用环境变量 ADMIN_PASSWORD 初始化"""
    if models.get_setting("admin_pw_hash"):
        return
    pw = os.environ.get("ADMIN_PASSWORD")
    if not pw:
        # 没给就生成一个随机密码并打印到日志, 强制用户改
        import secrets
        pw = secrets.token_urlsafe(12)
        print(f"[init] 未设置 ADMIN_PASSWORD, 生成临时管理员密码: {pw}", flush=True)
    models.set_setting("admin_pw_hash", generate_password_hash(pw))


def get_push_token():
    global _cached_push_token
    if _cached_push_token:
        return _cached_push_token
    tok = os.environ.get(PUSH_TOKEN_ENV)
    if tok:
        _cached_push_token = tok
        return tok
    tok = models.get_setting("push_token")
    if not tok:
        import secrets
        tok = secrets.token_urlsafe(24)
        models.set_setting("push_token", tok)
        print(f"[init] 生成部署推送 token: {tok}", flush=True)
    _cached_push_token = tok
    return tok


def verify_admin_password(password):
    h = models.get_setting("admin_pw_hash")
    return bool(h) and check_password_hash(h, password)


def change_admin_password(new_password):
    models.set_setting("admin_pw_hash", generate_password_hash(new_password))


def login_admin():
    session.permanent = True
    session["is_admin"] = True


def logout_admin():
    session.pop("is_admin", None)


def admin_required(fn):
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("is_admin"):
            return jsonify({"error": "unauthorized"}), 401
        return fn(*args, **kwargs)
    return wrapper


def push_token_required(fn):
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        # 支持 Authorization: Bearer xxx 或 ?push_token=xxx
        auth = request.headers.get("Authorization", "")
        tok = ""
        if auth.startswith("Bearer "):
            tok = auth[7:].strip()
        if not tok:
            tok = request.args.get("push_token", "")
        if not tok or tok != get_push_token():
            return jsonify({"error": "invalid push token"}), 401
        return fn(*args, **kwargs)
    return wrapper


_cached_report_token = None


def get_report_token():
    """只读状态接口(/api/report)的专用 token。供 daily.py 等外部定时器调用。"""
    global _cached_report_token
    if _cached_report_token:
        return _cached_report_token
    tok = os.environ.get("REPORT_TOKEN")
    if not tok:
        tok = models.get_setting("report_token")
        if not tok:
            import secrets
            tok = secrets.token_urlsafe(24)
            models.set_setting("report_token", tok)
            print(f"[init] 生成状态报告 token: {tok}", flush=True)
    _cached_report_token = tok
    return tok


def report_token_required(fn):
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        auth = request.headers.get("Authorization", "")
        tok = ""
        if auth.startswith("Bearer "):
            tok = auth[7:].strip()
        if not tok:
            tok = request.args.get("report_token", "")
        # admin 登录态也放行(方便面板内调试)
        if session.get("is_admin"):
            return fn(*args, **kwargs)
        if not tok or tok != get_report_token():
            return jsonify({"error": "invalid report token"}), 401
        return fn(*args, **kwargs)
    return wrapper
