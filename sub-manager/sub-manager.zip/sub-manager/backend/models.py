"""
数据库模型 (SQLite)
表:
  nodes    节点
  tokens   订阅令牌 (per-user, 可吊销)
  settings 全局设置 (管理员密码 hash 等)
"""
import sqlite3
import json
import os
import secrets
from datetime import datetime
from contextlib import contextmanager

DB_PATH = os.environ.get("DB_PATH", "/data/sub.db")


@contextmanager
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 5000")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    with get_db() as conn:
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute("PRAGMA synchronous = NORMAL")
        conn.execute("PRAGMA cache_size = -8000")
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS nodes (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                name        TEXT NOT NULL,
                type        TEXT NOT NULL,          -- reality / hysteria2 / tuic / vmess / shadowsocks
                server      TEXT NOT NULL,          -- 客户端连的地址(域名或IP)
                domain      TEXT DEFAULT '',        -- 若用域名, 存域名(同server); 用于CF解析管理
                real_ip     TEXT DEFAULT '',        -- 真实IP(域名模式下备查/CF解析目标)
                port        INTEGER NOT NULL,
                region      TEXT DEFAULT 'other',   -- jp/hk/us/sg/kr/au/nz/other
                -- 协议专属字段统一塞进 params (JSON), 不同协议字段不同
                params      TEXT DEFAULT '{}',
                enabled     INTEGER DEFAULT 1,
                sort_order  INTEGER DEFAULT 0,
                created_at  TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at  TEXT DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS tokens (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                token       TEXT UNIQUE NOT NULL,
                label       TEXT DEFAULT '',        -- 备注: "我-主力" / "朋友A"
                enabled     INTEGER DEFAULT 1,
                -- 可选: 限定该 token 能看到哪些节点 (JSON 数组存 node id; 空=全部)
                node_filter TEXT DEFAULT '[]',
                -- 可选: 限定能看到哪些地区 (JSON 数组; 空=全部)
                region_filter TEXT DEFAULT '[]',
                include_regex TEXT DEFAULT '',
                exclude_regex TEXT DEFAULT '',
                expire_at   TEXT DEFAULT NULL,      -- ISO 时间; NULL=永不过期
                last_access TEXT DEFAULT NULL,
                access_count INTEGER DEFAULT 0,
                created_at  TEXT DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS settings (
                key   TEXT PRIMARY KEY,
                value TEXT
            );

            -- token 访问过的不同 IP (用于 IP 数限制/异常检测)
            CREATE TABLE IF NOT EXISTS token_ips (
                token_id   INTEGER NOT NULL,
                ip         TEXT NOT NULL,
                first_seen TEXT DEFAULT CURRENT_TIMESTAMP,
                last_seen  TEXT DEFAULT CURRENT_TIMESTAMP,
                hits       INTEGER DEFAULT 1,
                PRIMARY KEY (token_id, ip)
            );
            """
        )
        # 轻量迁移: 已存在的 tokens 表补列 (老库升级)
        cols = {r["name"] for r in conn.execute("PRAGMA table_info(tokens)").fetchall()}
        if "ip_limit" not in cols:
            # 允许的不同 IP 数上限, 0=不限; 超过仅告警不阻断(防误伤)
            conn.execute("ALTER TABLE tokens ADD COLUMN ip_limit INTEGER DEFAULT 0")
        if "include_regex" not in cols:
            conn.execute("ALTER TABLE tokens ADD COLUMN include_regex TEXT DEFAULT ''")
        if "exclude_regex" not in cols:
            conn.execute("ALTER TABLE tokens ADD COLUMN exclude_regex TEXT DEFAULT ''")
        if "traffic_limit_gb" not in cols:
            # 流量额度(GB), 0/NULL=不限; 仅用于客户端显示(Subscription-Userinfo)
            conn.execute("ALTER TABLE tokens ADD COLUMN traffic_limit_gb REAL DEFAULT 0")
        if "last_access" not in cols:
            conn.execute("ALTER TABLE tokens ADD COLUMN last_access TEXT DEFAULT ''")
        if "access_count" not in cols:
            conn.execute("ALTER TABLE tokens ADD COLUMN access_count INTEGER DEFAULT 0")
        if "last_ip" not in cols:
            conn.execute("ALTER TABLE tokens ADD COLUMN last_ip TEXT DEFAULT ''")
        if "last_ua" not in cols:
            conn.execute("ALTER TABLE tokens ADD COLUMN last_ua TEXT DEFAULT ''")
        # nodes 表补 domain/real_ip 列
        ncols = {r["name"] for r in conn.execute("PRAGMA table_info(nodes)").fetchall()}
        if "domain" not in ncols:
            conn.execute("ALTER TABLE nodes ADD COLUMN domain TEXT DEFAULT ''")
        if "real_ip" not in ncols:
            conn.execute("ALTER TABLE nodes ADD COLUMN real_ip TEXT DEFAULT ''")
        if "isp" not in ncols:
            # 运营商短名(hgc/hkt/cmi...), 后端查 IP 归属得到, 用于命名 地区-运营商-协议
            conn.execute("ALTER TABLE nodes ADD COLUMN isp TEXT DEFAULT ''")

        conn.execute("CREATE INDEX IF NOT EXISTS idx_nodes_enabled_sort ON nodes(enabled, sort_order, id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_nodes_identity ON nodes(server, port, type)")


# ---------------- 节点操作 ----------------
def node_to_dict(row):
    d = dict(row)
    d["params"] = json.loads(d.get("params") or "{}")
    d["enabled"] = bool(d["enabled"])
    return d


def list_nodes(only_enabled=False):
    with get_db() as conn:
        sql = "SELECT * FROM nodes"
        if only_enabled:
            sql += " WHERE enabled = 1"
        sql += " ORDER BY sort_order ASC, id ASC"
        return [node_to_dict(r) for r in conn.execute(sql).fetchall()]


def get_node(node_id):
    with get_db() as conn:
        r = conn.execute("SELECT * FROM nodes WHERE id = ?", (node_id,)).fetchone()
        return node_to_dict(r) if r else None


def create_node(data):
    with get_db() as conn:
        cur = conn.execute(
            """INSERT INTO nodes (name, type, server, domain, real_ip, port, region, params, enabled, sort_order)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                data["name"], data["type"], data["server"],
                data.get("domain", ""), data.get("real_ip", ""),
                int(data["port"]),
                data.get("region", "other"),
                json.dumps(data.get("params", {}), ensure_ascii=False),
                1 if data.get("enabled", True) else 0,
                int(data.get("sort_order", 0)),
            ),
        )
        return cur.lastrowid


def update_node(node_id, data):
    with get_db() as conn:
        conn.execute(
            """UPDATE nodes SET name=?, type=?, server=?, domain=?, real_ip=?, port=?, region=?,
               params=?, enabled=?, sort_order=?, updated_at=CURRENT_TIMESTAMP
               WHERE id=?""",
            (
                data["name"], data["type"], data["server"],
                data.get("domain", ""), data.get("real_ip", ""),
                int(data["port"]),
                data.get("region", "other"),
                json.dumps(data.get("params", {}), ensure_ascii=False),
                1 if data.get("enabled", True) else 0,
                int(data.get("sort_order", 0)),
                node_id,
            ),
        )


def delete_node(node_id):
    with get_db() as conn:
        conn.execute("DELETE FROM nodes WHERE id = ?", (node_id,))


def list_nodes_by_ids(ids):
    clean_ids = [int(i) for i in ids]
    if not clean_ids:
        return []
    placeholders = ",".join("?" for _ in clean_ids)
    with get_db() as conn:
        rows = conn.execute(f"SELECT * FROM nodes WHERE id IN ({placeholders})", clean_ids).fetchall()
        return [node_to_dict(r) for r in rows]


def delete_nodes(ids):
    clean_ids = [int(i) for i in ids]
    if not clean_ids:
        return 0
    placeholders = ",".join("?" for _ in clean_ids)
    with get_db() as conn:
        cur = conn.execute(f"DELETE FROM nodes WHERE id IN ({placeholders})", clean_ids)
        return cur.rowcount


def bulk_update_nodes(ids, fields):
    """批量更新指定节点的字段(只允许 enabled/region, 防注入)。返回更新数。"""
    clean_ids = [int(i) for i in ids]
    allowed = {"enabled", "region"}
    sets, vals = [], []
    for k, v in fields.items():
        if k in allowed:
            sets.append(f"{k}=?")
            vals.append(v)
    if not clean_ids or not sets:
        return 0
    sets.append("updated_at=CURRENT_TIMESTAMP")
    placeholders = ",".join("?" for _ in clean_ids)
    with get_db() as conn:
        cur = conn.execute(
            f"UPDATE nodes SET {', '.join(sets)} WHERE id IN ({placeholders})",
            vals + clean_ids)
        return cur.rowcount


def delete_nodes_by_name_prefix(prefix):
    """按 name 前缀删除 (脚本重装清理同机器旧节点)。返回删除数。"""
    with get_db() as conn:
        # LIKE 'prefix%', 转义 LIKE 特殊字符 % _
        esc = prefix.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
        cur = conn.execute(
            "DELETE FROM nodes WHERE name LIKE ? ESCAPE '\\'", (esc + "%",))
        return cur.rowcount


def upsert_node_by_identity(data):
    """部署脚本推送用: 按 (server, port, type) 唯一性 upsert, 避免重复部署产生重复节点"""
    with get_db() as conn:
        r = conn.execute(
            "SELECT id FROM nodes WHERE server=? AND port=? AND type=?",
            (data["server"], int(data["port"]), data["type"]),
        ).fetchone()
        if r:
            node_id = r["id"]
            conn.execute(
                """UPDATE nodes SET name=?, domain=?, real_ip=?, region=?, params=?, isp=?, enabled=1,
                   updated_at=CURRENT_TIMESTAMP WHERE id=?""",
                (data["name"], data.get("domain", ""), data.get("real_ip", ""),
                 data.get("region", "other"),
                 json.dumps(data.get("params", {}), ensure_ascii=False),
                 data.get("isp", ""), node_id),
            )
            return node_id, False
        else:
            cur = conn.execute(
                """INSERT INTO nodes (name, type, server, domain, real_ip, port, region, params, isp, enabled)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)""",
                (data["name"], data["type"], data["server"],
                 data.get("domain", ""), data.get("real_ip", ""),
                 int(data["port"]), data.get("region", "other"),
                 json.dumps(data.get("params", {}), ensure_ascii=False),
                 data.get("isp", "")),
            )
            return cur.lastrowid, True


# ---------------- Token 操作 ----------------
def token_to_dict(row):
    d = dict(row)
    d["node_filter"] = json.loads(d.get("node_filter") or "[]")
    d["region_filter"] = json.loads(d.get("region_filter") or "[]")
    d["enabled"] = bool(d["enabled"])
    d["ip_limit"] = d.get("ip_limit") or 0
    return d


def list_tokens():
    with get_db() as conn:
        toks = [token_to_dict(r) for r in
                conn.execute("SELECT * FROM tokens ORDER BY id ASC").fetchall()]
        # 批量算每个 token 的不同 IP 数 (避免 N+1)
        ipc = {r["token_id"]: r["c"] for r in
               conn.execute("SELECT token_id, COUNT(*) c FROM token_ips GROUP BY token_id").fetchall()}
    now = datetime.now()
    for t in toks:
        t["ip_count"] = ipc.get(t["id"], 0)
        # 到期信息: days_left (None=永不), expiring(7天内), expired
        t["days_left"] = None
        t["expiring"] = False
        t["expired"] = False
        if t.get("expire_at"):
            try:
                exp = datetime.fromisoformat(t["expire_at"])
                delta = (exp - now).total_seconds() / 86400
                t["days_left"] = round(delta, 1)
                if delta < 0:
                    t["expired"] = True
                elif delta <= 7:
                    t["expiring"] = True
            except Exception:
                pass
        # IP 超限标记 (ip_limit>0 且 ip_count 超过)
        t["ip_over"] = bool(t.get("ip_limit") and t["ip_count"] > t["ip_limit"])
    return toks


def get_token(token_str):
    with get_db() as conn:
        r = conn.execute("SELECT * FROM tokens WHERE token = ?", (token_str,)).fetchone()
        return token_to_dict(r) if r else None


def create_token(label="", node_filter=None, region_filter=None, expire_at=None,
                 include_regex="", exclude_regex="", traffic_limit_gb=0, ip_limit=0):
    token_str = secrets.token_urlsafe(24)  # 32 字符的强随机 token
    with get_db() as conn:
        conn.execute(
            """INSERT INTO tokens (token, label, node_filter, region_filter, expire_at,
                                   include_regex, exclude_regex, traffic_limit_gb, ip_limit)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (token_str, label,
             json.dumps(node_filter or []),
             json.dumps(region_filter or []),
             expire_at, include_regex or "", exclude_regex or "",
             float(traffic_limit_gb or 0), int(ip_limit or 0)),
        )
    return token_str


def set_token_enabled(token_id, enabled):
    with get_db() as conn:
        conn.execute("UPDATE tokens SET enabled=? WHERE id=?",
                     (1 if enabled else 0, token_id))


def update_token(token_id, label=None, node_filter=None, region_filter=None, expire_at=None,
                 include_regex=None, exclude_regex=None, traffic_limit_gb=None, ip_limit=None):
    with get_db() as conn:
        sets, vals = [], []
        if label is not None:
            sets.append("label=?"); vals.append(label)
        if node_filter is not None:
            sets.append("node_filter=?"); vals.append(json.dumps(node_filter))
        if region_filter is not None:
            sets.append("region_filter=?"); vals.append(json.dumps(region_filter))
        if expire_at is not None:
            sets.append("expire_at=?"); vals.append(expire_at or None)
        if include_regex is not None:
            sets.append("include_regex=?"); vals.append(include_regex)
        if exclude_regex is not None:
            sets.append("exclude_regex=?"); vals.append(exclude_regex)
        if traffic_limit_gb is not None:
            sets.append("traffic_limit_gb=?"); vals.append(float(traffic_limit_gb or 0))
        if ip_limit is not None:
            sets.append("ip_limit=?"); vals.append(int(ip_limit or 0))
        if not sets:
            return
        vals.append(token_id)
        conn.execute(f"UPDATE tokens SET {', '.join(sets)} WHERE id=?", vals)


def delete_token(token_id):
    with get_db() as conn:
        conn.execute("DELETE FROM tokens WHERE id=?", (token_id,))


def touch_token(token_str, ip="", ua=""):
    with get_db() as conn:
        conn.execute(
            """UPDATE tokens SET last_access=CURRENT_TIMESTAMP, access_count=access_count+1,
               last_ip=?, last_ua=? WHERE token=?""",
            ((ip or "")[:120], (ua or "")[:300], token_str),
        )
        # 记录访问 IP 明细 (用于 IP 数限制/异常检测)
        if ip:
            row = conn.execute("SELECT id FROM tokens WHERE token=?", (token_str,)).fetchone()
            if row:
                conn.execute(
                    """INSERT INTO token_ips (token_id, ip, first_seen, last_seen, hits)
                       VALUES (?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 1)
                       ON CONFLICT(token_id, ip) DO UPDATE SET
                         last_seen=CURRENT_TIMESTAMP, hits=hits+1""",
                    (row["id"], ip[:120]),
                )


def token_ip_count(token_id):
    """该 token 访问过的不同 IP 数"""
    with get_db() as conn:
        r = conn.execute("SELECT COUNT(*) c FROM token_ips WHERE token_id=?", (token_id,)).fetchone()
        return r["c"] if r else 0


def token_ips(token_id):
    """该 token 的 IP 明细列表"""
    with get_db() as conn:
        rows = conn.execute(
            "SELECT ip, first_seen, last_seen, hits FROM token_ips WHERE token_id=? ORDER BY last_seen DESC",
            (token_id,)).fetchall()
        return [dict(r) for r in rows]


def token_valid(tok):
    """检查 token 是否可用 (启用 + 未过期)。兼容旧调用。"""
    return token_status(tok) == "ok"


def token_status(tok):
    """
    返回 token 状态字符串:
      'notfound' - token 不存在
      'disabled' - 被禁用 (吊销)
      'expired'  - 已过期
      'ok'       - 可用
    """
    if not tok:
        return "notfound"
    if not tok["enabled"]:
        return "disabled"
    if tok["expire_at"]:
        try:
            if datetime.fromisoformat(tok["expire_at"]) < datetime.now():
                return "expired"
        except ValueError:
            pass
    return "ok"


# ---------------- Settings ----------------
def get_setting(key, default=None):
    with get_db() as conn:
        r = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return r["value"] if r else default


def set_setting(key, value):
    with get_db() as conn:
        conn.execute(
            "INSERT INTO settings (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )


# ---------------- 模板 (存在 settings 里, key 形如 template:loon) ----------------
_template_cache = {}


def get_template(target):
    if target in _template_cache:
        return _template_cache[target]
    value = get_setting(f"template:{target}")
    _template_cache[target] = value
    return value


def set_template(target, content):
    _template_cache.pop(target, None)
    set_setting(f"template:{target}", content)


def init_templates(defaults: dict):
    """首次启动灌入默认模板 (不覆盖已存在的)"""
    for target, content in defaults.items():
        if get_template(target) is None:
            set_template(target, content)


# ---------------- Clash 规则映射 (存 settings:clash_rules, JSON) ----------------
# 每条: {"rule": "netflix", "target": "流媒体"}  rule是GEOSITE类别, target是分组名或地区码
DEFAULT_CLASH_RULES = [
    {"rule": "netflix", "target": "流媒体"},
    {"rule": "disney", "target": "流媒体"},
    {"rule": "hbo", "target": "流媒体"},
    {"rule": "youtube", "target": "流媒体"},
    {"rule": "spotify", "target": "流媒体"},
    {"rule": "bahamut", "target": "港台流媒体"},
    {"rule": "paypal", "target": "us"},
    {"rule": "google", "target": "兜底"},
    {"rule": "telegram", "target": "兜底"},
    {"rule": "github", "target": "兜底"},
    {"rule": "openai", "target": "兜底"},
]


def get_clash_rules():
    raw = get_setting("clash_rules")
    if raw is None:
        return list(DEFAULT_CLASH_RULES)
    try:
        return json.loads(raw)
    except (ValueError, TypeError):
        return list(DEFAULT_CLASH_RULES)


def set_clash_rules(rules):
    set_setting("clash_rules", json.dumps(rules, ensure_ascii=False))


def init_clash_rules():
    if get_setting("clash_rules") is None:
        set_clash_rules(DEFAULT_CLASH_RULES)
