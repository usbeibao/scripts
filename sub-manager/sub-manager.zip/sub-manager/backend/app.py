"""
Flask 主入口
"""
import os
import secrets
from datetime import timedelta
from flask import Flask, request, jsonify, session, send_from_directory
from werkzeug.middleware.proxy_fix import ProxyFix
from flask_cors import CORS

import models
import auth
from api.nodes import bp as nodes_bp
from api.tokens import bp as tokens_bp
from api.sub import bp as sub_bp
from api.templates import bp as templates_bp
from api.backup import bp as backup_bp
import api.templates as templates_mod


def _load_default_templates():
    """从 templates_default/ 读取用户的真实配置作默认模板"""
    base = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates_default")
    mapping = {"loon": "loon.lcf", "quanx": "quantumult.conf", "clash": "clash.yaml",
               "shadowrocket": "shadowrocket.conf"}
    defaults = {}
    for target, fname in mapping.items():
        path = os.path.join(base, fname)
        if os.path.isfile(path):
            with open(path, encoding="utf-8") as f:
                defaults[target] = f.read()
    return defaults


def _migrate_loon_mitm_clean():
    """清理 DB 里 loon 模板中 ca-p12/ca-passphrase 的证书内容 (保留字段但置空)"""
    import re
    content = models.get_template("loon")
    if not content:
        return
    # 匹配 ca-p12 = <非空内容> 或 ca-passphrase = <非空内容>
    changed = False
    for field in ("ca-p12", "ca-passphrase"):
        new_content, n = re.subn(
            rf'^({re.escape(field)}\s*=\s*)\S.*$',
            rf'\g<1>',
            content,
            flags=re.MULTILINE,
        )
        if n:
            content = new_content
            changed = True
    if changed:
        models.set_template("loon", content)


def create_app():
    # 静态目录: 优先 /app/static (容器内), 否则用脚本同级 static (本地/其它部署)
    static_dir = "/app/static"
    if not os.path.isdir(static_dir):
        static_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
    app = Flask(__name__, static_folder=static_dir, static_url_path="")

    # 可信反代后可开启，用于正确识别 X-Forwarded-Proto/For。
    # 不在反代后部署时不要开启，避免伪造来源 IP。
    if os.environ.get("TRUST_PROXY", "0") == "1":
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)

    # session 密钥: 持久化到 settings, 重启不掉登录
    models.init_db()
    secret = models.get_setting("flask_secret")
    if not secret:
        secret = secrets.token_hex(32)
        models.set_setting("flask_secret", secret)
    app.secret_key = secret
    app.permanent_session_lifetime = timedelta(days=7)
    app.config.update(
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        # 默认兼容 HTTP/内网部署；生产 HTTPS/CF 后建议 COOKIE_SECURE=1。
        SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "0") == "1",
        MAX_CONTENT_LENGTH=int(os.environ.get("MAX_CONTENT_LENGTH", str(1024 * 1024))),
    )

    # 前端同源时不需要 CORS; 若前端独立部署, 用环境变量放开
    origins = os.environ.get("CORS_ORIGINS", "")
    if origins:
        CORS(app, origins=origins.split(","), supports_credentials=True)

    auth.init_admin()
    auth.get_push_token()  # 确保生成

    # 加载并初始化默认模板 (用户真实配置)
    defaults = _load_default_templates()
    templates_mod.DEFAULTS = defaults
    models.init_templates(defaults)
    models.init_clash_rules()

    # 迁移: 清除已存储 loon 模板里的 ca-p12/ca-passphrase 证书内容
    # (旧版模板可能包含用户证书私钥, 确保存储里的模板是干净的)
    _migrate_loon_mitm_clean()

    # ---- 管理员登录 ----
    @app.post("/api/login")
    def login():
        retry_after = auth.check_login_rate_limit()
        if retry_after:
            return jsonify({"error": f"登录失败次数过多，请 {retry_after} 秒后再试"}), 429

        data = request.get_json(force=True) or {}
        if auth.verify_admin_password(data.get("password", "")):
            auth.clear_login_failure()
            auth.login_admin()
            return jsonify({"ok": True})
        auth.record_login_failure()
        return jsonify({"error": "密码错误"}), 401

    @app.post("/api/logout")
    def logout():
        auth.logout_admin()
        return jsonify({"ok": True})

    @app.get("/api/me")
    def me():
        return jsonify({"is_admin": bool(session.get("is_admin"))})

    @app.post("/api/change-password")
    @auth.admin_required
    def change_pw():
        data = request.get_json(force=True) or {}
        new = data.get("new_password", "")
        if len(new) < 8:
            return jsonify({"error": "密码至少 8 位"}), 400
        auth.change_admin_password(new)
        return jsonify({"ok": True})

    @app.get("/api/push-token")
    @auth.admin_required
    def push_token():
        return jsonify({"push_token": auth.get_push_token()})

    # ---- 业务蓝图 ----
    app.register_blueprint(nodes_bp)
    app.register_blueprint(tokens_bp)
    app.register_blueprint(sub_bp)
    app.register_blueprint(templates_bp)
    app.register_blueprint(backup_bp)

    # ---- 前端静态文件 (Vue 打包后放 /app/static) ----
    @app.get("/")
    def index():
        return send_from_directory(app.static_folder, "index.html")

    @app.errorhandler(413)
    def request_entity_too_large(e):
        return jsonify({"error": "请求内容过大，最大 1MB"}), 413

    @app.errorhandler(404)
    def spa_fallback(e):
        # 非 API/sub 路径回退到前端 (Vue history 路由)
        if request.path.startswith("/api") or request.path.startswith("/sub"):
            return jsonify({"error": "not found"}), 404
        try:
            return send_from_directory(app.static_folder, "index.html")
        except Exception:
            return jsonify({"error": "not found"}), 404

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8000)), debug=False)
