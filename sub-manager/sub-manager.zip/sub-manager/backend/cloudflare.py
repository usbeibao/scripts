"""
Cloudflare DNS API
管理节点域名的 A 记录 (灰云 DNS only, REALITY 不能套橙云)。
凭据从环境变量读: CF_API_TOKEN (必需), CF_ZONE_ID (可选, 没有则用域名自动查)。
Token 建议 Scoped: Zone.DNS.Edit, 限定对应 zone。
"""
import os
import requests

CF_API = "https://api.cloudflare.com/client/v4"
TIMEOUT = 10


class CFError(Exception):
    pass


def _token():
    tok = os.environ.get("CF_API_TOKEN", "").strip()
    if not tok:
        raise CFError("未配置 CF_API_TOKEN")
    return tok


def _headers():
    return {"Authorization": f"Bearer {_token()}", "Content-Type": "application/json"}


def enabled():
    """是否配置了 CF (没配则 DNS 自动化不可用)"""
    return bool(os.environ.get("CF_API_TOKEN", "").strip())


def _zone_id_for(domain):
    """取 zone id: 优先环境变量, 否则用域名的根域查"""
    env_zone = os.environ.get("CF_ZONE_ID", "").strip()
    if env_zone:
        return env_zone
    # 从 domain 推根域 (取最后两段, 如 tokyo2.202205.xyz -> 202205.xyz)
    parts = domain.split(".")
    if len(parts) < 2:
        raise CFError(f"域名不合法: {domain}")
    root = ".".join(parts[-2:])
    r = requests.get(f"{CF_API}/zones", headers=_headers(),
                     params={"name": root}, timeout=TIMEOUT)
    data = r.json()
    if not data.get("success") or not data.get("result"):
        raise CFError(f"查不到 zone: {root} ({data.get('errors')})")
    return data["result"][0]["id"]


def _find_record(zone_id, name):
    """查 name 的 A 记录, 返回 record id 或 None"""
    r = requests.get(f"{CF_API}/zones/{zone_id}/dns_records", headers=_headers(),
                     params={"type": "A", "name": name}, timeout=TIMEOUT)
    data = r.json()
    if not data.get("success"):
        raise CFError(f"查记录失败: {data.get('errors')}")
    recs = data.get("result", [])
    return recs[0]["id"] if recs else None


def upsert_a_record(domain, ip):
    """
    建/更新 A 记录 domain -> ip (灰云 DNS only, proxied=False)。
    REALITY 必须 DNS only, 不能 proxied(否则CF终止TLS破坏握手)。
    返回 record id。失败抛 CFError。
    """
    zone_id = _zone_id_for(domain)
    rec_id = _find_record(zone_id, domain)
    payload = {"type": "A", "name": domain, "content": ip,
               "ttl": 60, "proxied": False}  # ttl60便于换IP快速生效; 灰云
    if rec_id:
        r = requests.put(f"{CF_API}/zones/{zone_id}/dns_records/{rec_id}",
                         headers=_headers(), json=payload, timeout=TIMEOUT)
    else:
        r = requests.post(f"{CF_API}/zones/{zone_id}/dns_records",
                          headers=_headers(), json=payload, timeout=TIMEOUT)
    data = r.json()
    if not data.get("success"):
        raise CFError(f"写 A 记录失败 {domain}->{ip}: {data.get('errors')}")
    return data["result"]["id"]


def delete_a_record(domain):
    """删除 domain 的 A 记录。不存在视为成功。失败抛 CFError。"""
    zone_id = _zone_id_for(domain)
    rec_id = _find_record(zone_id, domain)
    if not rec_id:
        return True  # 本就没有
    r = requests.delete(f"{CF_API}/zones/{zone_id}/dns_records/{rec_id}",
                        headers=_headers(), timeout=TIMEOUT)
    data = r.json()
    if not data.get("success"):
        raise CFError(f"删 A 记录失败 {domain}: {data.get('errors')}")
    return True


def verify_token():
    """校验 token 可用 (面板配置时用)"""
    try:
        r = requests.get(f"{CF_API}/user/tokens/verify", headers=_headers(), timeout=TIMEOUT)
        return r.json().get("success", False)
    except Exception:
        return False
