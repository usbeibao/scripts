"""
节点管理 API
  GET    /api/admin/nodes        列表
  POST   /api/admin/nodes        新增
  PUT    /api/admin/nodes/<id>   更新
  DELETE /api/admin/nodes/<id>   删除
  POST   /api/nodes/push         部署脚本推送 (push token 鉴权, upsert)
"""
from flask import Blueprint, request, jsonify
import json

import models
from auth import admin_required, push_token_required

bp = Blueprint("nodes", __name__)

VALID_TYPES = {"reality", "vless", "vmess", "shadowsocks", "ss", "trojan", "hysteria2", "hy2", "tuic"}


def _validate(data):
    for f in ("name", "type", "server", "port"):
        if not data.get(f) and data.get(f) != 0:
            return f"缺少字段: {f}"
    if data["type"] not in VALID_TYPES:
        return f"不支持的类型: {data['type']}"
    try:
        port = int(data["port"])
        if not (1 <= port <= 65535):
            return "端口超出范围"
    except (ValueError, TypeError):
        return "端口必须是数字"

    params = data.get("params", {})
    if params is None:
        data["params"] = {}
        params = data["params"]
    if not isinstance(params, dict):
        return "params 必须是对象"
    try:
        if len(json.dumps(params, ensure_ascii=False)) > 64 * 1024:
            return "params 字段过大，最大 64KB"
    except (TypeError, ValueError):
        return "params 不是合法 JSON"
    return None


@bp.get("/api/admin/nodes")
@admin_required
def list_nodes():
    return jsonify(models.list_nodes())


@bp.post("/api/admin/nodes")
@admin_required
def create_node():
    data = request.get_json(force=True)
    err = _validate(data)
    if err:
        return jsonify({"error": err}), 400
    node_id = models.create_node(data)
    return jsonify({"id": node_id}), 201


@bp.post("/api/admin/nodes/import")
@admin_required
def import_nodes():
    """粘贴导入: 解析链接文本(单条/多行/base64订阅), upsert 入库(同 server+port+type 判重更新)"""
    from generators import uri_parser
    data = request.get_json(force=True) or {}
    text = data.get("text", "")
    nodes, errors = uri_parser.parse_text(text)
    if not nodes and not errors:
        return jsonify({"error": "未识别到任何链接"}), 400

    created, updated, failed = 0, 0, []
    for n in nodes:
        # 节点名兜底: 解析不出名字用 地区-协议
        if not n.get("name"):
            n["name"] = f"{n.get('region','other')}-{n['type']}"
        item = {
            "name": n["name"], "type": n["type"], "server": n["server"],
            "port": int(n["port"]), "region": n.get("region", "other"),
            "params": n.get("params", {}),
        }
        err = _validate(item)
        if err:
            failed.append(f"{n.get('name','?')}: {err}")
            continue
        try:
            _id, was_created = models.upsert_node_by_identity(item)
            if was_created:
                created += 1
            else:
                updated += 1
        except Exception as e:
            failed.append(f"{n.get('name','?')}: {e}")

    return jsonify({
        "created": created, "updated": updated,
        "parse_failed": errors, "import_failed": failed,
        "total": created + updated,
    })


@bp.put("/api/admin/nodes/<int:node_id>")
@admin_required
def update_node(node_id):
    if not models.get_node(node_id):
        return jsonify({"error": "节点不存在"}), 404
    data = request.get_json(force=True)
    err = _validate(data)
    if err:
        return jsonify({"error": err}), 400
    models.update_node(node_id, data)
    return jsonify({"ok": True})


@bp.delete("/api/admin/nodes/<int:node_id>")
@admin_required
def delete_node(node_id):
    import cloudflare
    node = models.get_node(node_id)
    # 若节点有域名且配了CF, 同步删解析 (失败不阻断删节点, 只记警告)
    cf_warning = None
    if node and node.get("domain") and cloudflare.enabled():
        try:
            cloudflare.delete_a_record(node["domain"])
        except cloudflare.CFError as e:
            cf_warning = f"CF解析删除失败(节点已删,请手动清理DNS): {e}"
    models.delete_node(node_id)
    resp = {"ok": True}
    if cf_warning:
        resp["warning"] = cf_warning
    return jsonify(resp)


@bp.post("/api/nodes/cleanup")
@push_token_required
def cleanup_nodes():
    """按 name 前缀删除节点 (脚本重装时清理同机器旧节点, 避免端口变更后残留)。
    body: {"name_prefix": "dmit-tokyo-1-"}  删除 name 以此开头的所有节点。"""
    data = request.get_json(force=True) or {}
    prefix = (data.get("name_prefix") or "").strip()
    if not prefix or len(prefix) < 2:
        return jsonify({"error": "name_prefix 太短(至少2字符, 防误删)"}), 400
    deleted = models.delete_nodes_by_name_prefix(prefix)
    return jsonify({"deleted": deleted, "prefix": prefix})


@bp.post("/api/nodes/push")
@push_token_required
def push_node():
    """
    部署脚本调用。支持单个对象或数组批量。
    若 item 带 domain 字段, 会调 CF API 把 domain 解析到 ip(必须也带), server 存 domain。
    严格模式: CF 解析失败则该 item 推送失败, 不入库。
    body 示例:
    {
      "name": "DMIT-Tokyo", "type": "reality", "server": "1.2.3.4", "port": 443,
      "region": "jp", "domain": "tokyo2.202205.xyz", "ip": "1.2.3.4",
      "params": {...}
    }
    """
    import cloudflare
    from generators import isp_lookup
    data = request.get_json(force=True)
    items = data if isinstance(data, list) else [data]
    results = []
    isp_cache = {}  # 同 server 不重复查 IP 归属
    for item in items:
        err = _validate(item)
        if err:
            results.append({"error": err, "item": item.get("name", "?")})
            continue

        # 域名模式: 有 domain 则建 CF 解析, server 用域名
        domain = (item.get("domain") or "").strip()
        ip = (item.get("ip") or item.get("real_ip") or "").strip()
        if domain:
            if not ip:
                results.append({"error": "带 domain 必须同时带 ip", "item": item.get("name")})
                continue
            if not cloudflare.enabled():
                results.append({"error": "服务端未配置 CF_API_TOKEN, 无法用域名模式", "item": item.get("name")})
                continue
            try:
                cloudflare.upsert_a_record(domain, ip)
            except cloudflare.CFError as e:
                # 严格模式: 解析失败不入库
                results.append({"error": f"CF解析失败: {e}", "item": item.get("name")})
                continue
            item["server"] = domain      # 客户端连域名
            item["domain"] = domain
            item["real_ip"] = ip

        # 查运营商(用真实IP优先, 否则用server解析): 缓存避免重复查
        lookup_target = item.get("real_ip") or item.get("server", "")
        if lookup_target and not item.get("isp"):
            try:
                item["isp"] = isp_lookup.isp_short_cached(lookup_target, isp_cache)
            except Exception:
                item["isp"] = ""

        node_id, created = models.upsert_node_by_identity(item)
        results.append({"id": node_id, "created": created, "name": item.get("name"),
                        "server": item.get("server"), "isp": item.get("isp", "")})
    return jsonify({"results": results})


@bp.post("/api/admin/nodes/bulk-delete")
@admin_required
def bulk_delete_nodes():
    """批量删除节点"""
    import cloudflare
    data = request.get_json(force=True) or {}
    ids = data.get("ids", [])
    if not ids or not isinstance(ids, list):
        return jsonify({"error": "ids 必须是非空数组"}), 400

    warnings = []
    try:
        clean_ids = [int(i) for i in ids]
    except (TypeError, ValueError):
        return jsonify({"error": "ids 必须全部是数字"}), 400

    nodes = models.list_nodes_by_ids(clean_ids)
    for node in nodes:
        # 若节点有域名且配了CF, 同步删解析 (失败不阻断)
        if node.get("domain") and cloudflare.enabled():
            try:
                cloudflare.delete_a_record(node["domain"])
            except cloudflare.CFError as e:
                warnings.append(f"CF解析删除失败({node['domain']}): {e}")

    deleted = models.delete_nodes([n["id"] for n in nodes])

    resp = {"deleted": deleted, "total": len(ids)}
    if warnings:
        resp["warnings"] = warnings
    return jsonify(resp)


@bp.post("/api/admin/nodes/bulk-update")
@admin_required
def bulk_update_nodes():
    """批量更新节点的 enabled 或 region (其他字段不动)"""
    data = request.get_json(force=True) or {}
    ids = data.get("ids", [])
    if not ids or not isinstance(ids, list):
        return jsonify({"error": "ids 必须是非空数组"}), 400
    try:
        clean_ids = [int(i) for i in ids]
    except (TypeError, ValueError):
        return jsonify({"error": "ids 必须全部是数字"}), 400

    fields = {}
    if "enabled" in data:
        fields["enabled"] = 1 if data["enabled"] else 0
    if "region" in data and data["region"]:
        fields["region"] = str(data["region"])[:20]
    if not fields:
        return jsonify({"error": "无可更新字段 (enabled/region)"}), 400

    updated = models.bulk_update_nodes(clean_ids, fields)
    return jsonify({"updated": updated, "total": len(clean_ids), "fields": list(fields.keys())})


@bp.post("/api/admin/nodes/healthcheck")
@admin_required
def healthcheck_nodes():
    """对节点做 TCP 端口连通探测(发现宕机/端口变更/服务挂掉这类硬故障)。
    注意: 面板在墙外, 探的是墙外可达性; 不代表客户端从墙内能连。墙的因素需客户端实测。
    只返回结果, 不自动禁用节点。"""
    import socket
    from concurrent.futures import ThreadPoolExecutor

    data = request.get_json(silent=True) or {}
    ids = data.get("ids")  # 可选: 只测选中的; 不传则测全部
    nodes = models.list_nodes(only_enabled=False)
    if ids:
        idset = set(int(i) for i in ids)
        nodes = [n for n in nodes if n["id"] in idset]

    def probe(n):
        host = n.get("server") or n.get("real_ip") or ""
        port = int(n.get("port") or 0)
        alive = False
        latency_ms = None
        if host and port:
            import time
            t0 = time.time()
            try:
                with socket.create_connection((host, port), timeout=5):
                    alive = True
                    latency_ms = int((time.time() - t0) * 1000)
            except Exception:
                alive = False
        return {"id": n["id"], "name": n["name"], "alive": alive, "latency_ms": latency_ms}

    with ThreadPoolExecutor(max_workers=16) as ex:
        results = list(ex.map(probe, nodes))
    alive_count = sum(1 for r in results if r["alive"])
    return jsonify({"results": results, "total": len(results), "alive": alive_count})


@bp.get("/api/admin/validate")
@admin_required
def validate_config():
    """校验配置正确性: 节点参数完整性 + 生成的 Clash 配置结构。
    国外可做的有意义校验(抓配置错, 非网络可达)。"""
    from generators import node_validator, clash
    nodes = models.list_nodes(only_enabled=True)
    # 1. 节点参数完整性
    node_result = node_validator.check_nodes(nodes)
    # 2. 生成 Clash 配置做结构校验
    config_problems = []
    try:
        yaml_text = clash.generate(nodes, template=models.get_template("clash"))
        config_problems = node_validator.check_clash_config(yaml_text)
    except Exception as e:
        config_problems = [f"生成 Clash 配置时出错: {str(e)[:120]}"]
    return jsonify({
        "nodes": node_result,
        "config_problems": config_problems,
        "ok": node_result["bad_count"] == 0 and len(config_problems) == 0,
    })
