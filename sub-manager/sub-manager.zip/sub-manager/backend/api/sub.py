"""
订阅出口
  GET /sub/<token>?target=clash|v2ray|loon|quanx&include=正则&exclude=正则
  - 不带 target 时按 User-Agent 自动识别客户端
  - include/exclude: URL 参数临时覆盖 token 存的默认正则
  - 过滤顺序: token地区/节点 → include/exclude正则 → 客户端协议支持
"""
import os
from flask import Blueprint, request, Response, jsonify

import models
from generators import base64_uri, clash, loon, quanx, common, shadowrocket

bp = Blueprint("sub", __name__)

SUBCONVERTER_URL = os.environ.get("SUBCONVERTER_URL", "")


def detect_target(ua):
    ua = (ua or "").lower()
    if "clash" in ua or "mihomo" in ua or "meta" in ua:
        return "clash"
    if "loon" in ua:
        return "loon"
    if "quantumult" in ua:
        return "quanx"
    if "shadowrocket" in ua:
        return "shadowrocket"
    if "v2ray" in ua or "v2rayn" in ua:
        return "v2ray"
    return "v2ray"


VALID_TARGETS = ("clash", "clash-classic", "v2ray", "loon", "quanx",
                 "shadowrocket", "shadowrocket-conf", "stash",
                 "clash-nodes")


def normalize_target(t):
    t = (t or "").lower()
    return t if t in VALID_TARGETS else "v2ray"


def _render(nodes, target):
    """统一生成逻辑 (节点已过滤好)"""
    if target == "clash":
        return clash.generate(nodes, template=models.get_template("clash"))
    if target == "clash-classic":
        return clash.generate(nodes, template=models.get_template("clash"), classic=True)
    if target == "stash":
        # Stash 兼容 Clash Premium(非 meta), 不支持 include-all+filter, 用 classic 展开格式
        # 协议 reality/hy2/tuic Stash 都支持, 节点写法与 Clash 一致
        return clash.generate(nodes, template=models.get_template("clash"), classic=True)
    if target == "clash-nodes":
        return clash.generate_nodes(nodes)
    if target == "loon":
        return loon.generate(nodes, models.get_template("loon"))
    if target == "quanx":
        return quanx.generate(nodes, models.get_template("quanx"))
    if target == "shadowrocket-conf":
        return shadowrocket.generate_conf(nodes, models.get_template("shadowrocket"))
    if target == "shadowrocket":
        return shadowrocket.generate_nodes(nodes)
    return base64_uri.generate(nodes)


def build_subscription_raw(nodes, target):
    """不做空兜底的生成 (调用方已自备占位节点, 如过期提示)"""
    nodes = common.filter_nodes_for_client(nodes, target)
    if not nodes:
        nodes = [dict(common.PLACEHOLDER_NODE)]
    return _render(nodes, target)


def build_subscription(nodes, target):
    """核心: 给定已过滤节点和 target 生成订阅。预览与正式出口共用。"""
    nodes = common.filter_nodes_for_client(nodes, target)
    nodes = common.placeholder_if_empty(nodes)
    return _render(nodes, target)


def resolve_nodes(tok, include_override=None, exclude_override=None):
    """按 token + 正则筛选 (不含客户端协议过滤)"""
    nodes = models.list_nodes(only_enabled=True)
    nodes = common.filter_nodes_for_token(nodes, tok)
    include = include_override if include_override is not None else tok.get("include_regex", "")
    exclude = exclude_override if exclude_override is not None else tok.get("exclude_regex", "")
    nodes = common.filter_nodes_by_regex(nodes, include, exclude)
    return nodes


CONTENT_TYPE = "text/plain; charset=utf-8"


@bp.get("/sub/<token>")
def subscribe(token):
    tok = models.get_token(token)
    status = models.token_status(tok)
    if status == "expired":
        # 过期: 返回一个含提示的最小订阅 (而非404), 让朋友知道是过期需续期
        target = normalize_target(request.args.get("target") or detect_target(request.headers.get("User-Agent")))
        hint = [dict(common.PLACEHOLDER_NODE)]
        hint[0]["name"] = "订阅已过期-请联系管理员续期"
        body = build_subscription_raw(hint, target)
        return Response(body, content_type=CONTENT_TYPE)
    if status != "ok":
        # disabled / notfound: 一律 404, 不泄露 token 是否存在
        return Response("subscription not found", status=404)

    # 记录访问: 真实IP优先取 X-Forwarded-For(CF/nginx回源), 否则 remote_addr
    client_ip = (request.headers.get("X-Forwarded-For", "").split(",")[0].strip()
                 or request.remote_addr or "")
    models.touch_token(token, ip=client_ip, ua=request.headers.get("User-Agent", ""))
    target = normalize_target(request.args.get("target") or detect_target(request.headers.get("User-Agent")))
    inc = request.args.get("include") if "include" in request.args else None
    exc = request.args.get("exclude") if "exclude" in request.args else None
    nodes = resolve_nodes(tok, inc, exc)
    body = build_subscription(nodes, target)
    resp = Response(body, content_type=CONTENT_TYPE)
    # Subscription-Userinfo: 客户端显示流量额度/到期 (total/expire 来自 token)
    limit_gb = float(tok.get("traffic_limit_gb") or 0)
    total_bytes = int(limit_gb * 1024 * 1024 * 1024) if limit_gb > 0 else 0
    expire_ts = 0
    if tok.get("expire_at"):
        try:
            from datetime import datetime
            ea = tok["expire_at"].replace("Z", "").replace("T", " ").strip()
            for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
                try:
                    expire_ts = int(datetime.strptime(ea, fmt).timestamp()); break
                except ValueError:
                    continue
        except Exception:
            expire_ts = 0
    # download 暂记为0 (架构不支持真实统计; total>0 时客户端显示 "0/总额度")
    resp.headers["Subscription-Userinfo"] = (
        f"upload=0; download=0; total={total_bytes}; expire={expire_ts}"
    )
    resp.headers["Profile-Update-Interval"] = "12"
    from urllib.parse import quote as _q
    label = tok.get("label") or "sub"
    resp.headers["Content-Disposition"] = (
        f"attachment; filename=\"sub.{target}\"; filename*=UTF-8''{_q(label)}.{target}"
    )
    return resp


@bp.get("/sub/<token>/info")
def sub_info(token):
    tok = models.get_token(token)
    if not models.token_valid(tok):
        return jsonify({"error": "invalid token"}), 404
    nodes = resolve_nodes(tok)
    info = {}
    for t in ("clash", "clash-nodes", "v2ray", "loon", "quanx"):
        info[t] = len(common.filter_nodes_for_client(nodes, t))
    return jsonify({"label": tok.get("label"), "counts": info})


# ---- 管理员预览 (面板用, 不消耗 token 计数) ----
from auth import admin_required


@bp.post("/api/admin/preview")
@admin_required
def admin_preview():
    """
    body: {token?, target, include?, exclude?, region_filter?, node_filter?}
    token 给定则按该 token 范围; 否则按 region_filter/node_filter 临时范围(预览自己的)。
    返回生成的订阅内容 + 各格式节点数。
    """
    data = request.get_json(force=True) or {}
    target = normalize_target(data.get("target"))
    include = data.get("include", "")
    exclude = data.get("exclude", "")

    if data.get("token"):
        tok = models.get_token(data["token"])
        if not tok:
            return jsonify({"error": "token 不存在"}), 404
        nodes = resolve_nodes(tok, include or None, exclude or None)
    else:
        # 临时范围: 用传入的 filter 构造一个虚拟 token
        vtok = {
            "node_filter": data.get("node_filter", []),
            "region_filter": data.get("region_filter", []),
            "include_regex": "", "exclude_regex": "",
        }
        nodes = resolve_nodes(vtok, include or None, exclude or None)

    body = build_subscription(nodes, target)
    counts = {t: len(common.filter_nodes_for_client(nodes, t)) for t in ("clash", "clash-nodes", "v2ray", "loon", "quanx")}
    # 预览内容截断, 避免太大 (完整内容客户端拉订阅时拿)
    preview = body if len(body) < 20000 else body[:20000] + "\n...(预览截断, 完整内容见订阅URL)"
    return jsonify({"target": target, "content": preview, "counts": counts, "total": len(nodes)})
