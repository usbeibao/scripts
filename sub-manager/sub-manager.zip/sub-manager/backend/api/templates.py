"""
模板管理 API (管理员)
  GET /api/admin/templates/<target>   取模板内容
  PUT /api/admin/templates/<target>   保存模板
  POST /api/admin/templates/<target>/reset  恢复默认
target: loon / quanx (clash 用内置分组规则, 暂不模板化)
"""
from flask import Blueprint, request, jsonify

import models
from auth import admin_required

bp = Blueprint("templates", __name__)

PLACEHOLDER = "{{NODES}}"
DEFAULTS = {}  # 由 app.py 启动时填入


@bp.get("/api/admin/templates/<target>")
@admin_required
def get_template(target):
    content = models.get_template(target)
    return jsonify({"target": target, "content": content or "",
                    "has_placeholder": PLACEHOLDER in (content or "")})


@bp.put("/api/admin/templates/<target>")
@admin_required
def save_template(target):
    data = request.get_json(force=True) or {}
    content = data.get("content", "")
    # 占位符校验: clash 用 {{PROXIES}}, 其余用 {{NODES}}
    if target == "clash":
        if "{{PROXIES}}" not in content:
            return jsonify({"error": "Clash 模板必须包含占位符 {{PROXIES}}"}), 400
    else:
        if PLACEHOLDER not in content:
            return jsonify({"error": f"模板必须包含占位符 {PLACEHOLDER}"}), 400
    models.set_template(target, content)
    return jsonify({"ok": True})


@bp.post("/api/admin/templates/<target>/reset")
@admin_required
def reset_template(target):
    if target not in DEFAULTS:
        return jsonify({"error": "无默认模板"}), 404
    models.set_template(target, DEFAULTS[target])
    return jsonify({"ok": True})


# ---- Clash 规则映射 (服务→地区组) ----
@bp.get("/api/admin/clash-rules")
@admin_required
def get_clash_rules():
    return jsonify({"rules": models.get_clash_rules(),
                    "default": models.DEFAULT_CLASH_RULES})


@bp.put("/api/admin/clash-rules")
@admin_required
def save_clash_rules():
    data = request.get_json(force=True) or {}
    rules = data.get("rules", [])
    # 基本校验: 每条要有 rule 和 target
    clean = []
    for r in rules:
        if isinstance(r, dict) and r.get("rule") and r.get("target"):
            clean.append({"rule": str(r["rule"]).strip(), "target": str(r["target"]).strip()})
    models.set_clash_rules(clean)
    return jsonify({"ok": True, "count": len(clean)})


@bp.post("/api/admin/clash-rules/reset")
@admin_required
def reset_clash_rules():
    models.set_clash_rules(models.DEFAULT_CLASH_RULES)
    return jsonify({"ok": True})
