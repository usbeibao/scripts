"""
只读状态报告 API — 供 daily.py 等外部定时器拉取, 拼进 Telegram 日报
  GET /api/report   (report token 鉴权)
返回轻量数据(查库即得, 不含慢的TCP健康探测): token状态/节点数, 带一句话 summary。
"""
from flask import Blueprint, jsonify

import models
from auth import report_token_required

bp = Blueprint("report", __name__)


@bp.get("/api/report")
@report_token_required
def report():
    toks = models.list_tokens()
    nodes = models.list_nodes(only_enabled=False)

    expired, expiring, ip_over = [], [], []
    for t in toks:
        if t.get("expired"):
            d = t.get("days_left")
            expired.append({"label": t["label"] or "(无备注)",
                            "days_ago": abs(round(d)) if d is not None else None})
        elif t.get("expiring"):
            expiring.append({"label": t["label"] or "(无备注)",
                             "days_left": t.get("days_left")})
        if t.get("ip_over"):
            ip_over.append({"label": t["label"] or "(无备注)",
                            "ip_count": t.get("ip_count"), "ip_limit": t.get("ip_limit")})

    by_region = {}
    for n in nodes:
        r = n.get("region", "other")
        by_region[r] = by_region.get(r, 0) + 1

    # 一句话摘要(daily.py 直接用)
    warns = []
    if expired:   warns.append(f"{len(expired)}个已过期")
    if expiring:  warns.append(f"{len(expiring)}个即将到期")
    if ip_over:   warns.append(f"{len(ip_over)}个IP超限")
    if warns:
        summary = f"{len(toks)}个token, {len(nodes)}个节点; ⚠ " + ", ".join(warns)
    else:
        summary = f"{len(toks)}个token, {len(nodes)}个节点; 一切正常 ✓"

    return jsonify({
        "ok": True,
        "summary": summary,
        "tokens": {
            "total": len(toks),
            "expired": expired,
            "expiring": expiring,
            "ip_over": ip_over,
        },
        "nodes": {
            "total": len(nodes),
            "by_region": by_region,
        },
    })
