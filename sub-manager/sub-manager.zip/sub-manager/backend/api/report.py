"""
只读状态报告 API — 供 daily.py 等外部定时器拉取, 拼进 Telegram 日报
  GET /api/report   (report token 鉴权)
  GET /api/health   (不鉴权, 极轻量, 供外部监控探活)
返回轻量数据(查库即得, 不含慢的TCP健康探测): token状态/节点数, 带一句话 summary。
"""
import time
from flask import Blueprint, jsonify

import models
from auth import report_token_required

bp = Blueprint("report", __name__)

_START_TIME = time.time()


@bp.get("/api/health")
def health():
    """健康检查端点 — 不鉴权, 极轻量。供外部监控(daily.py)探测面板死活。
    顺便测 DB 可读 + 返回基本信息。面板半死状态也应能响应。"""
    db_ok = True
    node_count = token_count = None
    try:
        node_count = len(models.list_nodes(only_enabled=False))
        token_count = len(models.list_tokens())
    except Exception:
        db_ok = False
    uptime = int(time.time() - _START_TIME)
    status = "ok" if db_ok else "degraded"
    resp = {
        "status": status,
        "db": "ok" if db_ok else "error",
        "uptime_seconds": uptime,
        "nodes": node_count,
        "tokens": token_count,
    }
    return jsonify(resp), (200 if db_ok else 503)


@bp.get("/api/report")
@report_token_required
def report():
    toks = models.list_tokens()
    nodes = models.list_nodes(only_enabled=False)

    expired, expiring, ip_over = [], [], []
    for t in toks:
        if t.get("expired"):
            d = t.get("days_left")
            expired.append({"label": t["label"] or "(无备注)",
                            "days_ago": abs(round(d)) if d is not None else None})
        elif t.get("expiring"):
            expiring.append({"label": t["label"] or "(无备注)",
                             "days_left": t.get("days_left")})
        if t.get("ip_over"):
            ip_over.append({"label": t["label"] or "(无备注)",
                            "ip_count": t.get("ip_count"), "ip_limit": t.get("ip_limit")})

    by_region = {}
    for n in nodes:
        r = n.get("region", "other")
        by_region[r] = by_region.get(r, 0) + 1

    # 一句话摘要(daily.py 直接用)
    warns = []
    if expired:   warns.append(f"{len(expired)}个已过期")
    if expiring:  warns.append(f"{len(expiring)}个即将到期")
    if ip_over:   warns.append(f"{len(ip_over)}个IP超限")
    if warns:
        summary = f"{len(toks)}个token, {len(nodes)}个节点; ⚠ " + ", ".join(warns)
    else:
        summary = f"{len(toks)}个token, {len(nodes)}个节点; 一切正常 ✓"

    return jsonify({
        "ok": True,
        "summary": summary,
        "tokens": {
            "total": len(toks),
            "expired": expired,
            "expiring": expiring,
            "ip_over": ip_over,
        },
        "nodes": {
            "total": len(nodes),
            "by_region": by_region,
        },
    })
