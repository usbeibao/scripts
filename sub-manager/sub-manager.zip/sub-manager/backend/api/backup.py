"""
DB 备份: 导出整个 SQLite 数据库文件下载, 或上传 .db 恢复。
导出文件含节点 uuid/password、CF token 等敏感信息, 妥善保管。
"""
import os
import shutil
import sqlite3
import tempfile
from datetime import datetime

from flask import Blueprint, request, jsonify, send_file

import models
from auth import admin_required

bp = Blueprint("backup", __name__)


@bp.get("/api/admin/backup/export")
@admin_required
def export_db():
    """导出整库 (用 sqlite backup API 保证一致性, 避免读到写一半的状态)"""
    src = models.DB_PATH
    if not os.path.exists(src):
        return jsonify({"error": "数据库不存在"}), 404
    # 用 sqlite .backup 到临时文件 (一致性快照)
    tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
    tmp.close()
    try:
        src_conn = sqlite3.connect(src)
        dst_conn = sqlite3.connect(tmp.name)
        with dst_conn:
            src_conn.backup(dst_conn)
        src_conn.close()
        dst_conn.close()
    except Exception as e:
        os.unlink(tmp.name)
        return jsonify({"error": f"备份失败: {e}"}), 500
    fname = f"sub-manager-{datetime.now().strftime('%Y%m%d-%H%M%S')}.db"
    return send_file(tmp.name, as_attachment=True, download_name=fname,
                     mimetype="application/x-sqlite3")


@bp.post("/api/admin/backup/import")
@admin_required
def import_db():
    """上传 .db 恢复。先校验是合法 SQLite 且含 nodes/tokens 表, 再替换。原库自动备份。"""
    f = request.files.get("file")
    if not f:
        return jsonify({"error": "未上传文件"}), 400

    # 存到临时文件校验
    tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
    f.save(tmp.name)
    tmp.close()
    try:
        conn = sqlite3.connect(tmp.name)
        tables = {r[0] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        conn.close()
        if "nodes" not in tables or "tokens" not in tables:
            os.unlink(tmp.name)
            return jsonify({"error": "不是有效的 sub-manager 数据库(缺 nodes/tokens 表)"}), 400
    except Exception as e:
        os.unlink(tmp.name)
        return jsonify({"error": f"不是合法的 SQLite 文件: {e}"}), 400

    # 替换前先备份当前库
    dst = models.DB_PATH
    if os.path.exists(dst):
        bak = f"{dst}.bak-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
        try:
            shutil.copy2(dst, bak)
        except Exception:
            pass
    try:
        shutil.move(tmp.name, dst)
    except Exception as e:
        return jsonify({"error": f"恢复失败: {e}"}), 500
    return jsonify({"ok": True, "msg": "已恢复, 建议重启容器以确保连接刷新"})
