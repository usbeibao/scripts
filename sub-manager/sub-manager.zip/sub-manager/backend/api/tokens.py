"""
Token (订阅令牌) 管理 API — 全部需管理员
  GET    /api/admin/tokens            列表
  POST   /api/admin/tokens            新建 (返回 token 串)
  PUT    /api/admin/tokens/<id>       编辑 (label/filter/expire)
  POST   /api/admin/tokens/<id>/toggle 启用/禁用 (吊销)
  DELETE /api/admin/tokens/<id>       删除
"""
from flask import Blueprint, request, jsonify

import models
from auth import admin_required

bp = Blueprint("tokens", __name__)


@bp.get("/api/admin/tokens")
@admin_required
def list_tokens():
    toks = models.list_tokens()
    # 不在列表里暴露完整 token? 这里管理员可见, 返回完整, 前端可点击复制
    return jsonify(toks)


@bp.post("/api/admin/tokens")
@admin_required
def create_token():
    data = request.get_json(force=True) or {}
    token_str = models.create_token(
        label=data.get("label", ""),
        node_filter=data.get("node_filter"),
        region_filter=data.get("region_filter"),
        expire_at=data.get("expire_at"),
        include_regex=data.get("include_regex", ""),
        exclude_regex=data.get("exclude_regex", ""),
        traffic_limit_gb=data.get("traffic_limit_gb", 0),
        ip_limit=data.get("ip_limit", 0),
    )
    return jsonify({"token": token_str}), 201


@bp.put("/api/admin/tokens/<int:token_id>")
@admin_required
def update_token(token_id):
    data = request.get_json(force=True) or {}
    models.update_token(
        token_id,
        label=data.get("label"),
        node_filter=data.get("node_filter"),
        region_filter=data.get("region_filter"),
        expire_at=data.get("expire_at"),
        include_regex=data.get("include_regex"),
        exclude_regex=data.get("exclude_regex"),
        traffic_limit_gb=data.get("traffic_limit_gb"),
        ip_limit=data.get("ip_limit"),
    )
    return jsonify({"ok": True})


@bp.get("/api/admin/tokens/<int:token_id>/ips")
@admin_required
def token_ips(token_id):
    """该 token 访问过的 IP 明细 (首次/最后/次数)"""
    return jsonify({"ips": models.token_ips(token_id)})


@bp.post("/api/admin/tokens/<int:token_id>/toggle")
@admin_required
def toggle_token(token_id):
    data = request.get_json(force=True) or {}
    models.set_token_enabled(token_id, bool(data.get("enabled", True)))
    return jsonify({"ok": True})


@bp.delete("/api/admin/tokens/<int:token_id>")
@admin_required
def delete_token(token_id):
    models.delete_token(token_id)
    return jsonify({"ok": True})
