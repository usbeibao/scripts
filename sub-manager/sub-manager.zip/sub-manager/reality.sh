#!/usr/bin/env bash
# =============================================================================
#  reality.sh (sing-box 版) —— 多协议节点一键部署
#  内核: sing-box (单核同时跑全部协议, 省内存, Hy2/TUIC 原生稳定)
#  协议: VLESS-REALITY-Vision (TCP) + Hysteria2 (UDP) + TUIC (UDP) + Shadowsocks
#  证书: Hy2/TUIC 用真证书, 经 acme.sh + Cloudflare DNS-01 申请
#        (不依赖域名先解析、不占80端口; 需 CF_API_TOKEN + NODE_DOMAIN)
#        REALITY 不需证书。无 NODE_DOMAIN 时 Hy2/TUIC 降级自签+insecure。
#  末尾自动推送到订阅系统 (pushToSub)
#  适用: Debian / Ubuntu
# =============================================================================
export LANG=en_US.UTF-8
RED="\033[31m"; GREEN="\033[32m"; YELLOW="\033[33m"; BLUE="\033[36m"; PLAIN='\033[0m'
SB_DIR="/etc/sing-box"
SB_CONF="${SB_DIR}/config.json"
SB_BIN="/usr/local/bin/sing-box"
CERT_DIR="${SB_DIR}/cert"
coloredEcho() { echo -e "${1}${@:2}${PLAIN}"; }

# 公共函数库 (地区探测 / 时区映射)
_libdir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
[[ -f "${_libdir}/common_lib.sh" ]] && source "${_libdir}/common_lib.sh"

checkRoot() { [[ "$(id -u)" != "0" ]] && { coloredEcho $YELLOW " 请以root身份执行"; exit 1; }; }

checkSystem() {
  if grep -qi "debian" /etc/os-release 2>/dev/null; then release="debian"
  elif grep -qi "ubuntu" /etc/os-release 2>/dev/null; then release="ubuntu"
  else coloredEcho $RED "\n仅支持 Debian / Ubuntu\n"; exit 1; fi
  coloredEcho $GREEN " 系统: ${release}"
}

sbArch(){
  case "$(uname -m)" in
    x86_64|amd64) echo 'amd64' ;;
    armv8|aarch64) echo 'arm64' ;;
    armv7|armv7l) echo 'armv7' ;;
    *) coloredEcho $RED " 不支持的架构: $(uname -m)"; exit 1 ;;
  esac
}

installDeps() {
  coloredEcho $BLUE "\n========== 安装依赖 ==========\n"
  apt update -y >/dev/null 2>&1
  # 核心依赖(脚本真正用到的): 一次装, 这些包名在 Debian 12/13 都稳定
  apt -y install curl wget unzip tar openssl jq ca-certificates chrony socat cron qrencode >/dev/null 2>&1
  # dig/nslookup: Debian 13 把 dnsutils 改名 bind9-dnsutils, 两个名都试(装上一个即可)
  apt -y install bind9-dnsutils >/dev/null 2>&1 || apt -y install dnsutils >/dev/null 2>&1
  # net-tools(netstat): 仅自检备选(主用 ss, iproute2 默认有), 装不上也无妨
  apt -y install net-tools >/dev/null 2>&1 || true
  # iproute2(ss/ip): 脚本主力工具, Debian 默认装, 保险起见确认
  command -v ss >/dev/null 2>&1 || apt -y install iproute2 >/dev/null 2>&1
  # 校验关键工具是否就绪
  local miss=""
  for t in curl wget jq openssl; do command -v "$t" >/dev/null 2>&1 || miss+=" $t"; done
  if [[ -n "$miss" ]]; then
    coloredEcho $RED " 关键依赖缺失:$miss (apt 源可能有问题, 请检查)"; exit 1
  fi
  coloredEcho $GREEN " 依赖完成 (Debian 12/13 兼容)"
}

syncTime() {
  coloredEcho $BLUE "\n========== 时间同步 + 时区 ==========\n"
  systemctl enable --now chrony >/dev/null 2>&1 || systemctl enable --now chronyd >/dev/null 2>&1
  chronyc -a makestep >/dev/null 2>&1

  # 时区: TZ 环境变量 > NODE_REGION > 自动探测地区。24h 是 Linux 默认。
  if declare -F set_timezone_by_region >/dev/null; then
    local region="${NODE_REGION:-}"
    [[ -z "$region" ]] && declare -F detect_region >/dev/null && region=$(detect_region)
    local tz; tz=$(TZ="${TZ:-}" set_timezone_by_region "$region")
    if [[ -n "$tz" ]]; then
      coloredEcho $GREEN " 时区: $tz"
    else
      coloredEcho $YELLOW " 时区: 未识别地区(${region:-?}), 保持系统默认"
    fi
  fi
  coloredEcho $GREEN " UTC: $(date -u '+%Y-%m-%d %H:%M:%S')  本地: $(date '+%Y-%m-%d %H:%M:%S %Z')"
}

getInput() {
  # 无人值守模式: 设了 NONINTERACTIVE=1, 或传了 PUSH_TOKEN(说明是自动化开荒) 则不交互
  local auto=0
  [[ "${NONINTERACTIVE:-}" == "1" || -n "${PUSH_TOKEN:-}" ]] && auto=1

  # SS 密码: 环境变量 > 交互 > 随机
  if [[ -z "$SS_PASSWORD" ]]; then
    if [[ "$auto" == "1" ]]; then
      SS_PASSWORD=$(openssl rand -base64 16)
    else
      read -p " SS连接密码(转发用), 回车随机:" SS_PASSWORD
      [[ -z "$SS_PASSWORD" ]] && SS_PASSWORD=$(openssl rand -base64 16)
    fi
  fi
  coloredEcho $BLUE " SS密码: $SS_PASSWORD"

  # reality 端口: 环境变量 > 交互 > 默认443
  if [[ -z "${REALITY_PORT}" ]]; then
    if [[ "$auto" == "1" ]]; then
      REALITY_PORT=443
    else
      read -p " reality端口, 回车默认443:" REALITY_PORT
      [[ -z "${REALITY_PORT}" ]] && REALITY_PORT=443
    fi
  fi

  SS_PORT="${SS_PORT:-$((RANDOM % 10000 + 20000))}"
  HY2_PORT="${HY2_PORT:-$((RANDOM % 10000 + 30000))}"
  TUIC_PORT="${TUIC_PORT:-$((RANDOM % 10000 + 40000))}"
  UUID="${UUID:-$(cat /proc/sys/kernel/random/uuid)}"
  TUIC_UUID="${TUIC_UUID:-$(cat /proc/sys/kernel/random/uuid)}"
  TUIC_PASSWORD="${TUIC_PASSWORD:-$(openssl rand -base64 12)}"
  HY2_PASSWORD="${HY2_PASSWORD:-$(openssl rand -base64 12)}"
  coloredEcho $BLUE " 端口: reality=$REALITY_PORT SS=$SS_PORT Hy2=$HY2_PORT TUIC=$TUIC_PORT"
  coloredEcho $BLUE " UUID: $UUID"
  [[ "$auto" == "1" ]] && coloredEcho $GREEN " (无人值守模式: 参数自动生成)"
}

installSingBox() {
  coloredEcho $BLUE "\n========== 安装 sing-box (arch $(sbArch)) ==========\n"
  mkdir -p "$SB_DIR" "${SB_DIR}/conf" "$CERT_DIR"
  local ver; ver=$(curl -s https://api.github.com/repos/SagerNet/sing-box/releases/latest | jq -r .tag_name)
  [[ -z "$ver" || "$ver" == "null" ]] && ver="v1.10.7"
  local v="${ver#v}"
  local pkg="sing-box-${v}-linux-$(sbArch)"
  coloredEcho $GREEN " 版本: ${ver}"
  rm -rf /tmp/sb && mkdir -p /tmp/sb
  wget -q -O /tmp/sb/sb.tar.gz "https://github.com/SagerNet/sing-box/releases/download/${ver}/${pkg}.tar.gz"
  [[ $? != 0 ]] && { coloredEcho $RED " 下载sing-box失败"; exit 1; }
  tar xzf /tmp/sb/sb.tar.gz -C /tmp/sb
  cp "/tmp/sb/${pkg}/sing-box" "$SB_BIN" && chmod +x "$SB_BIN"
  [[ ! -x "$SB_BIN" ]] && { coloredEcho $RED " sing-box安装失败"; exit 1; }
  coloredEcho $GREEN " $($SB_BIN version | head -1)"
  cat >/etc/systemd/system/sing-box.service<<EOF
[Unit]
Description=sing-box service
After=network.target nss-lookup.target
[Service]
User=root
ExecStart=${SB_BIN} run -c ${SB_CONF}
Restart=on-failure
RestartSec=10
LimitNOFILE=infinity
[Install]
WantedBy=multi-user.target
EOF
}

initRealityKey() {
  coloredEcho $BLUE "\n========== 生成 REALITY 密钥 ==========\n"
  if [[ -z "${realityPrivateKey}" ]]; then
    local kp; kp=$($SB_BIN generate reality-keypair)
    realityPrivateKey=$(echo "$kp" | grep -i "PrivateKey" | awk '{print $NF}')
    realityPublicKey=$(echo "$kp" | grep -i "PublicKey" | awk '{print $NF}')
  fi
  realityShortId="${realityShortId:-$(openssl rand -hex 8)}"
  coloredEcho $GREEN " privateKey: ${realityPrivateKey}"
  coloredEcho $GREEN " publicKey:  ${realityPublicKey}"
  coloredEcho $GREEN " shortId:    ${realityShortId}"
}

initRealityDest() {
  coloredEcho $BLUE "\n========== 选择 REALITY 回落域名(dest) ==========\n"
  if [[ -n "${REALITY_DEST}" ]]; then
    realityDestDomain="${REALITY_DEST}"
  else
    local pool="www.lovelive-anime.jp,time.is,www.tohovillage.com,dev.mysql.com,academy.nvidia.com,www.j-platpat.inpit.go.jp,www.gco.gov.sg,www.swift.com"
    coloredEcho $YELLOW " 候选: ${pool}"
    local auto=0
    [[ "${NONINTERACTIVE:-}" == "1" || -n "${PUSH_TOKEN:-}" ]] && auto=1
    if [[ "$auto" == "1" ]]; then
      realityDestDomain=""   # 自动模式直接随机选
    else
      read -r -p " 回落域名[回车随机]:" realityDestDomain
    fi
    if [[ -z "${realityDestDomain}" ]]; then
      local total; total=$(echo "$pool" | awk -F',' '{print NF}')
      local n=$((RANDOM % total + 1))
      realityDestDomain=$(echo "$pool" | awk -F',' -v n="$n" '{print $n}')
    fi
  fi
  if echo | timeout 8 openssl s_client -connect "${realityDestDomain}:443" -tls1_3 -servername "${realityDestDomain}" 2>/dev/null | grep -q "TLSv1.3"; then
    coloredEcho $GREEN " ${realityDestDomain} 支持 TLS1.3 ✓"
  else
    coloredEcho $YELLOW " 警告: 无法确认 ${realityDestDomain} 的 TLS1.3"
  fi
}

# 用 acme.sh + Cloudflare DNS-01 申请真证书 (Hy2/TUIC用)
issueCert() {
  USE_REAL_CERT=0
  if [[ -z "${NODE_DOMAIN}" || -z "${CF_API_TOKEN}" ]]; then
    coloredEcho $YELLOW "\n 未提供 NODE_DOMAIN + CF_API_TOKEN, Hy2/TUIC 用自签证书(客户端insecure)"
    genSelfCert
    return 0
  fi
  coloredEcho $BLUE "\n========== 申请证书 (acme.sh + CF DNS-01) ==========\n"

  # token 类型预检: acme.sh dns_cf 需要 User API Token(cfut_/普通Token, 含 Zone:DNS:Edit)
  # cfat_ 开头是 Account-level Token, dns_cf 不认, 提前提示避免无效重试
  if [[ "${CF_API_TOKEN}" == cfat_* ]]; then
    coloredEcho $YELLOW " ⚠ CF_API_TOKEN 是账户级令牌(cfat_), acme.sh 的 dns_cf 不支持"
    coloredEcho $YELLOW "   需用「用户 API 令牌」(cfut_ 或经典 Token), 权限含 Zone:DNS:Edit + Zone:Read"
    coloredEcho $YELLOW "   降级自签证书。要真证书请用正确 token 重跑。"
    genSelfCert
    return 0
  fi

  local acme="${HOME}/.acme.sh/acme.sh"
  local certHome="${HOME}/.acme.sh/${NODE_DOMAIN}_ecc"

  # 修复1: 先查本地是否已有有效证书, 有则直接装 (幂等+复用, 避免重复申请)
  if [[ -f "${certHome}/fullchain.cer" && -f "${certHome}/${NODE_DOMAIN}.key" ]]; then
    # 检查证书是否仍有效(剩余>7天)
    if openssl x509 -in "${certHome}/fullchain.cer" -checkend 604800 >/dev/null 2>&1; then
      coloredEcho $GREEN " 检测到已有有效证书, 直接复用"
      installCertFiles && { USE_REAL_CERT=1; CERT_DOMAIN="${NODE_DOMAIN}"; return 0; }
    fi
  fi

  # 修复2: acme.sh 安装与申请分离, 确保装好就绪再申请
  if [[ ! -f "${acme}" ]]; then
    coloredEcho $BLUE " 安装 acme.sh..."
    curl -s https://get.acme.sh | sh -s email="admin@${NODE_DOMAIN#*.}" >/dev/null 2>&1
    # 等待安装完成, 确认可执行
    local i=0
    while [[ ! -f "${acme}" && $i -lt 10 ]]; do sleep 1; i=$((i+1)); done
    [[ ! -f "${acme}" ]] && { coloredEcho $RED " acme.sh 安装失败"; genSelfCert; return 0; }
  fi

  # 不再 export, 改用 env 内联传递(学 mack-a, 确保子进程拿到 token), 记录日志便于排查
  local cf_acct=""
  [[ -n "${CF_ACCOUNT_ID}" ]] && cf_acct="CF_Account_ID=${CF_ACCOUNT_ID}"

  "${acme}" --set-default-ca --server letsencrypt >/dev/null 2>&1

  coloredEcho $BLUE " 申请证书 ${NODE_DOMAIN} (DNS-01)..."
  local acmelog="/tmp/acme_issue.log"
  local issued=0 attempt=1
  while [[ $attempt -le 3 ]]; do
    # env 内联传 CF_Token (关键: 保证 acme.sh 子进程一定拿到 token, 不依赖export)
    if env CF_Token="${CF_API_TOKEN}" ${cf_acct} "${acme}" --issue --dns dns_cf \
         -d "${NODE_DOMAIN}" --keylength ec-256 --server letsencrypt \
         >"${acmelog}" 2>&1; then
      issued=1; break
    fi
    if [[ -f "${HOME}/.acme.sh/${NODE_DOMAIN}_ecc/fullchain.cer" ]]; then
      issued=1; break
    fi
    # 识别 Let's Encrypt 频率限制(429), 这种重试无用, 直接停
    if grep -q "rateLimited\|too many certificates" "${acmelog}"; then
      coloredEcho $RED " Let's Encrypt 频率限制! 同一域名7天内最多5张证书。"
      coloredEcho $YELLOW " $(grep -oE 'retry after [0-9: -]+UTC' "${acmelog}" | head -1)"
      coloredEcho $YELLOW " 建议: 换个子域名(如 tokyo2b.202205.xyz), 或等限制解除, 或先用自签"
      break  # 限额重试无用
    fi
    coloredEcho $YELLOW " 第${attempt}次申请未成, 关键错误:"
    grep -iE "error|invalid|forbidden|denied|unable|not found|authentication" "${acmelog}" | tail -3
    sleep "${attempt}0"
    attempt=$((attempt+1))
  done

  if [[ $issued == 1 ]]; then
    installCertFiles
    USE_REAL_CERT=1
    CERT_DOMAIN="${NODE_DOMAIN}"
    coloredEcho $GREEN " 证书申请成功 (${NODE_DOMAIN})"
  else
    coloredEcho $YELLOW " 证书申请失败(已重试3次), 降级自签证书(insecure)"
    coloredEcho $YELLOW " (可手动排查: ${acme} --issue --dns dns_cf -d ${NODE_DOMAIN} --keylength ec-256 --debug)"
    genSelfCert
  fi
}

installCertFiles() {
  ~/.acme.sh/acme.sh --install-cert -d "${NODE_DOMAIN}" --ecc \
    --fullchain-file "${CERT_DIR}/cert.pem" \
    --key-file "${CERT_DIR}/key.pem" \
    --reloadcmd "systemctl restart sing-box" >/dev/null 2>&1
}

genSelfCert() {
  CERT_DOMAIN="${TLS_SNI:-www.bing.com}"
  openssl ecparam -genkey -name prime256v1 -out "${CERT_DIR}/key.pem" 2>/dev/null
  openssl req -new -x509 -days 3650 -key "${CERT_DIR}/key.pem" -out "${CERT_DIR}/cert.pem" -subj "/CN=${CERT_DOMAIN}" 2>/dev/null
  USE_REAL_CERT=0
  coloredEcho $GREEN " 自签证书完成 (CN=${CERT_DOMAIN})"
}

configSingBox() {
  coloredEcho $BLUE "\n========== 写入 sing-box 配置 ==========\n"
  local insecure_flag="false"
  [[ "${USE_REAL_CERT}" == "0" ]] && insecure_flag="true"
  cat > "$SB_CONF"<<EOF
{
  "log": { "level": "warn", "timestamp": true },
  "inbounds": [
    {
      "type": "vless",
      "tag": "reality-vision",
      "listen": "::",
      "listen_port": ${REALITY_PORT},
      "users": [ { "uuid": "${UUID}", "flow": "xtls-rprx-vision" } ],
      "tls": {
        "enabled": true,
        "server_name": "${realityDestDomain}",
        "reality": {
          "enabled": true,
          "handshake": { "server": "${realityDestDomain}", "server_port": 443 },
          "private_key": "${realityPrivateKey}",
          "short_id": [ "${realityShortId}" ]
        }
      }
    },
    {
      "type": "hysteria2",
      "tag": "hy2",
      "listen": "::",
      "listen_port": ${HY2_PORT},
      "users": [ { "password": "${HY2_PASSWORD}" } ],
      "tls": {
        "enabled": true,
        "alpn": ["h3"],
        "certificate_path": "${CERT_DIR}/cert.pem",
        "key_path": "${CERT_DIR}/key.pem"
      }
    },
    {
      "type": "tuic",
      "tag": "tuic",
      "listen": "::",
      "listen_port": ${TUIC_PORT},
      "users": [ { "uuid": "${TUIC_UUID}", "password": "${TUIC_PASSWORD}" } ],
      "congestion_control": "bbr",
      "tls": {
        "enabled": true,
        "alpn": ["h3"],
        "certificate_path": "${CERT_DIR}/cert.pem",
        "key_path": "${CERT_DIR}/key.pem"
      }
    },
    {
      "type": "shadowsocks",
      "tag": "ss",
      "listen": "::",
      "listen_port": ${SS_PORT},
      "method": "chacha20-ietf-poly1305",
      "password": "${SS_PASSWORD}"
    }
  ],
  "outbounds": [
    { "type": "direct", "tag": "direct" },
    { "type": "block", "tag": "block" }
  ]
}
EOF
  if $SB_BIN check -c "$SB_CONF" >/dev/null 2>&1; then
    coloredEcho $GREEN " sing-box 配置校验通过 ✓"
  else
    coloredEcho $RED " sing-box 配置校验失败:"
    $SB_BIN check -c "$SB_CONF"
    exit 1
  fi
}

configFirewall() {
  iptables -I INPUT -p tcp --dport ${REALITY_PORT} -j ACCEPT 2>/dev/null
  iptables -I INPUT -p tcp --dport ${SS_PORT} -j ACCEPT 2>/dev/null
  iptables -I INPUT -p udp --dport ${SS_PORT} -j ACCEPT 2>/dev/null
  iptables -I INPUT -p udp --dport ${HY2_PORT} -j ACCEPT 2>/dev/null
  iptables -I INPUT -p udp --dport ${TUIC_PORT} -j ACCEPT 2>/dev/null
  coloredEcho $YELLOW " 云控制台放行: TCP ${REALITY_PORT}, TCP/UDP ${SS_PORT}, UDP ${HY2_PORT}, UDP ${TUIC_PORT}"
}

tuneKernel() {
  cat > /etc/sysctl.d/99-proxy.conf <<EOF
net.core.default_qdisc=fq
net.ipv4.tcp_congestion_control=bbr
net.core.rmem_max=26214400
net.core.wmem_max=26214400
fs.file-max=1000000
EOF
  sysctl --system >/dev/null 2>&1
  coloredEcho $GREEN " BBR: $(sysctl -n net.ipv4.tcp_congestion_control)"
}

startSingBox() {
  systemctl daemon-reload
  systemctl enable sing-box >/dev/null 2>&1
  systemctl restart sing-box
  sleep 2
  if systemctl is-active --quiet sing-box; then
    coloredEcho $GREEN " sing-box 已启动 ✓"
  else
    coloredEcho $RED " sing-box 启动失败:"; journalctl -u sing-box -n 20 --no-pager; exit 1
  fi
}

outputInfo() {
  local ip; ip=$(curl -s --max-time 5 https://api.ipify.org 2>/dev/null)
  [[ -z "$ip" ]] && ip="<IP>"
  local hy2sni="${CERT_DOMAIN}"
  coloredEcho $GREEN "\n================== 节点信息 ==================\n"
  echo "[REALITY] vless://${UUID}@${ip}:${REALITY_PORT}?encryption=none&flow=xtls-rprx-vision&security=reality&sni=${realityDestDomain}&fp=chrome&pbk=${realityPublicKey}&sid=${realityShortId}&type=tcp#${ip}-Vision"
  echo ""
  echo "[Hysteria2] hy2://${HY2_PASSWORD}@${ip}:${HY2_PORT}?sni=${hy2sni}&insecure=$([ "$USE_REAL_CERT" == "0" ] && echo 1 || echo 0)#${ip}-Hy2"
  echo ""
  echo "[TUIC] tuic://${TUIC_UUID}:${TUIC_PASSWORD}@${ip}:${TUIC_PORT}?sni=${hy2sni}&congestion_control=bbr&alpn=h3#${ip}-TUIC"
  echo ""
  echo "[SS](转发用) ${ip}:${SS_PORT} chacha20-ietf-poly1305 ${SS_PASSWORD}"
  echo ""
  coloredEcho $GREEN " REALITY私钥(勿外泄): ${realityPrivateKey}"
}

pushToSub() {
  if [[ -z "${SUB_API}" || -z "${PUSH_TOKEN}" ]]; then
    coloredEcho $YELLOW " 未配置 SUB_API/PUSH_TOKEN, 跳过推送"
    return 0
  fi
  local ip; ip=$(curl -s --max-time 5 https://api.ipify.org 2>/dev/null)
  export SERVER_IP="${ip}" NODE_NAME="${NODE_NAME:-$(hostname)}" REGION="${NODE_REGION:-other}"
  export NODE_DOMAIN="${NODE_DOMAIN:-}"
  export REALITY_PORT UUID realityPublicKey realityShortId realityDestDomain
  export HY2_PORT HY2_PASSWORD TUIC_PORT TUIC_UUID TUIC_PASSWORD SS_PORT SS_PASSWORD
  export CERT_DOMAIN USE_REAL_CERT
  local d; d="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  if [[ -f "${d}/push_to_sub.sh" ]]; then
    coloredEcho $BLUE " 推送节点到订阅系统..."
    bash "${d}/push_to_sub.sh"
  else
    coloredEcho $YELLOW " 同目录无 push_to_sub.sh, 跳过推送"
  fi
}

install() {
  checkRoot; checkSystem; installDeps; syncTime; getInput
  installSingBox; initRealityKey; initRealityDest
  issueCert; configSingBox; configFirewall; tuneKernel; startSingBox
  outputInfo; pushToSub
  selfCheck
  coloredEcho $BLUE "\n 安装完成"
}

# 安装后自检: 进程 / 端口监听 / 本地协议握手, 失败给明确诊断
selfCheck() {
  coloredEcho $BLUE "\n========== 安装后自检 ==========\n"
  local fail=0

  # 1. 进程
  if systemctl is-active --quiet sing-box; then
    coloredEcho $GREEN " [✓] sing-box 进程运行中"
  else
    coloredEcho $RED " [✗] sing-box 未运行"; fail=1
  fi

  # 2. 端口监听 (reality/hy2/tuic/ss)
  local ss_out; ss_out=$(ss -tunlp 2>/dev/null || netstat -tunlp 2>/dev/null)
  check_port() {
    local port="$1" proto="$2" label="$3"
    if echo "$ss_out" | grep -qE "[:.]${port}\b"; then
      coloredEcho $GREEN " [✓] ${label} 端口 ${port}/${proto} 监听中"
    else
      coloredEcho $RED " [✗] ${label} 端口 ${port}/${proto} 未监听"; fail=1
    fi
  }
  check_port "$REALITY_PORT" tcp "REALITY"
  check_port "$HY2_PORT" udp "Hysteria2"
  check_port "$TUIC_PORT" udp "TUIC"
  check_port "$SS_PORT" tcp "Shadowsocks"

  # 3. 配置合法性 (sing-box check)
  if "$SB_BIN" check -c "$SB_CONF" >/dev/null 2>&1; then
    coloredEcho $GREEN " [✓] sing-box 配置校验通过"
  else
    coloredEcho $RED " [✗] sing-box 配置校验失败:"; "$SB_BIN" check -c "$SB_CONF" 2>&1 | head -5; fail=1
  fi

  # 4. 证书状态 (Hy2/TUIC 用)
  if [[ "${USE_REAL_CERT:-0}" == "1" ]]; then
    coloredEcho $GREEN " [✓] Hy2/TUIC 使用真证书 (${CERT_DOMAIN})"
  else
    coloredEcho $YELLOW " [!] Hy2/TUIC 用自签证书 (客户端需 insecure)"
  fi

  echo ""
  if [[ "$fail" == "0" ]]; then
    coloredEcho $GREEN " 自检全部通过 — 节点本地正常 (国内可达性需客户端实测)"
  else
    coloredEcho $RED " 自检发现问题 — 请检查上面 [✗] 项"
    coloredEcho $YELLOW " 诊断: journalctl -u sing-box -n 30 --no-pager"
  fi
}

install "$@"
