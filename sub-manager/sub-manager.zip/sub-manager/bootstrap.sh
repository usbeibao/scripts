#!/usr/bin/env bash
# =============================================================================
#  bootstrap.sh —— 新服务器开荒主脚本 (DD 完成后运行)
# -----------------------------------------------------------------------------
#  串接流程 (一段跑完, 不中途重启):
#    1. dpkg 修复 + apt 装基础工具
#    2. 在线拉 init.sh (你的GitHub), 去掉末尾 reboot/重启询问, 执行
#       (系统初始化: 换源/fail2ban/SSH加固改端口38658禁root/smartdns/besttrace)
#    3. 跑同目录的 reality.sh (我们改的带推送版, 保留交互填域名/端口, 末尾自动推送)
#    4. 提示: 验证新SSH能登录后再手动重启
#
#  时区/时间同步: 不单独跑 timezone.sh。时间同步由 reality.sh 的 syncTime
#    (chrony + makestep) 处理 —— 这才是 REALITY 需要的; 时区对节点无所谓。
#
#  前置:
#    - 已 DD 完系统 (Debian 12), 能 root SSH 进来
#    - 本脚本同目录放: reality.sh, push_to_sub.sh (一起传上来)
#
#  用法:
#    把 bootstrap.sh reality.sh push_to_sub.sh 传到新服务器同目录, 然后:
#
#    SUB_API="https://sub-manager.202205.xyz" \
#    PUSH_TOKEN="面板的部署token" \
#    NODE_REGION="jp" \
#    NODE_NAME="dmit-tokyo-1" \
#    bash bootstrap.sh
#
#  (SUB_API/PUSH_TOKEN 不传则跳过推送, 只装节点; reality.sh 仍会让你交互填参数)
# =============================================================================

set -o pipefail

RED="\033[31m"; GREEN="\033[32m"; YELLOW="\033[33m"; BLUE="\033[36m"; PLAIN='\033[0m'
say(){ echo -e "${1}${@:2}${PLAIN}"; }
info(){ say "$BLUE" "\n=== $* ==="; }
ok(){ say "$GREEN" " $*"; }
warn(){ say "$YELLOW" " $*"; }
err(){ say "$RED" " $*"; }

# init.sh 的参数 (github取key的用户 / 要创建的新用户)
INIT_GH_USER="${INIT_GH_USER:-usbeibao}"
INIT_NEW_USER="${INIT_NEW_USER:-frank.chen}"
INIT_URL="https://raw.githubusercontent.com/usbeibao/scripts/main/init.sh"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

checkRoot(){
  [[ "$(id -u)" != "0" ]] && { err "请以 root 运行 (DD完成后首次登录是 root)"; exit 1; }
}

step_base(){
  info "步骤1: 修复 dpkg + 装基础工具"
  dpkg --configure -a
  apt-get update -y
  apt -y install curl wget git less screen xz-utils bind9-dnsutils plocate net-tools mtr unzip iperf3 jq nethogs iftop lsof sudo certbot python3-certbot-nginx 
  ok "基础工具装好"
}

step_init(){
  info "步骤2: 系统初始化 (init.sh, 已去除重启)"
  warn "注意: 这步会加固 SSH (禁root登录/改端口38658/强制key), 并装 smartdns/fail2ban"
  warn "GitHub用户(取key): ${INIT_GH_USER}  新用户: ${INIT_NEW_USER}"

  local tmp="/tmp/init_noreboot.sh"
  if ! curl -fsSL "${INIT_URL}" -o "${tmp}"; then
    err "拉取 init.sh 失败, 检查网络/GitHub 可达性"
    exit 1
  fi
  # 去掉末尾的重启询问交互块 (从 read -p "...是否现在重启" 到文件结尾)
  # 用 sed 删除含"是否现在重启"的行及其后续 reboot 逻辑
  sed -i '/read -p "系统初始化完成/,$d' "${tmp}"
  # 兜底: 删除任何残留的裸 reboot 行
  sed -i '/^[[:space:]]*reboot[[:space:]]*$/d' "${tmp}"

  ok "已生成去重启版 init.sh, 开始执行"
  bash "${tmp}" "${INIT_GH_USER}" "${INIT_NEW_USER}"

  # 防锁死校验: init.sh 禁了 root+密码登录, 若 key 拉取失败=空, 重启就锁死
  local keyfile="/home/${INIT_NEW_USER}/.ssh/authorized_keys"
  if [[ ! -s "${keyfile}" ]]; then
    err "!!! 危险: ${keyfile} 为空或不存在 !!!"
    err "init.sh 已禁用 root 和密码登录, 若现在重启将彻底锁死无法登录!"
    err "可能原因: 从 github.com/${INIT_GH_USER}.keys 拉公钥失败"
    warn "请立即手动修复 (在当前会话, 不要断开!):"
    echo "    curl https://github.com/${INIT_GH_USER}.keys > ${keyfile}"
    echo "    chmod 400 ${keyfile} && chown ${INIT_NEW_USER}:${INIT_NEW_USER} ${keyfile}"
    warn "或临时恢复 root 登录: sed -i 's/PermitRootLogin no/PermitRootLogin yes/' /etc/ssh/sshd_config && systemctl restart sshd"
    err "修复并验证能登录前, 切勿重启! 已暂停后续步骤。"
    exit 1
  fi
  local keycount; keycount=$(grep -c "ssh-\|ecdsa-" "${keyfile}" 2>/dev/null || echo 0)
  ok "系统初始化完成 (未重启); 已确认 ${INIT_NEW_USER} 的 SSH key 存在 (${keycount} 个)"
}

step_reality(){
  info "步骤3: 安装代理 (reality.sh, 交互填域名/端口, 末尾自动推送)"
  if [[ ! -f "${SCRIPT_DIR}/reality.sh" ]]; then
    err "同目录找不到 reality.sh, 请把 reality.sh 和 push_to_sub.sh 和本脚本放一起"
    exit 1
  fi
  if [[ ! -f "${SCRIPT_DIR}/push_to_sub.sh" ]] && [[ -n "${SUB_API}" ]]; then
    warn "同目录无 push_to_sub.sh, 推送会被跳过 (节点仍会装好)"
  fi
  # reality.sh 会读 SUB_API/PUSH_TOKEN/NODE_REGION/NODE_NAME 环境变量做推送
  bash "${SCRIPT_DIR}/reality.sh"
}

final_notice(){
  info "开荒完成"
  warn "================== 重要: 重启前必读 =================="
  warn "init.sh 已加固 SSH: 禁用 root 登录 / 端口改为 38658 / 仅 key 登录"
  warn "现在【不要】关闭当前这个 root 会话!"
  warn "请【另开一个终端】验证新登录方式能用:"
  echo "    ssh -p 38658 ${INIT_NEW_USER}@<本机IP>"
  warn "确认能用 key 以 ${INIT_NEW_USER} 登录后, 再回来手动重启:"
  echo "    reboot"
  warn "若新登录方式不通, 不要重启! 在当前会话排查 (检查 /home/${INIT_NEW_USER}/.ssh/authorized_keys)"
  warn "===================================================="
  echo ""
  ok "节点应已推送到订阅系统, 去面板确认。别忘了在云控制台放行端口!"
}

main(){
  checkRoot
  step_base
  step_init
  step_reality
  final_notice
}

main "$@"
