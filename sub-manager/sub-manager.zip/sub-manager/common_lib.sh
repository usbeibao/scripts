#!/usr/bin/env bash
# common_lib.sh —— 推送脚本公共函数 (地区探测等)
# 被 push_to_sub.sh / xray_to_sub.sh source

# 国家码(ISO) -> sub-manager region 码
# 查 ip-api.com 拿 countryCode, 映射到我们的 region。映射不到 -> other
_cc_to_region() {
  case "$1" in
    JP) echo jp ;;
    HK) echo hk ;;
    US) echo us ;;
    SG) echo sg ;;
    KR) echo kr ;;
    AU) echo au ;;
    NZ) echo nz ;;
    TW) echo tw ;;
    GB|UK) echo uk ;;
    DE) echo de ;;
    *) echo other ;;
  esac
}

# region 码 -> IANA 时区 (运维时本地时间更直观)
_region_to_tz() {
  case "$1" in
    jp) echo "Asia/Tokyo" ;;
    hk) echo "Asia/Hong_Kong" ;;
    tw) echo "Asia/Taipei" ;;
    sg) echo "Asia/Singapore" ;;
    kr) echo "Asia/Seoul" ;;
    us) echo "America/Los_Angeles" ;;
    au) echo "Australia/Sydney" ;;
    nz) echo "Pacific/Auckland" ;;
    uk) echo "Europe/London" ;;
    de) echo "Europe/Berlin" ;;
    *) echo "" ;;   # 未知地区不强设, 保持系统默认
  esac
}

# 按地区设时区 (24h 是 Linux 默认, 无需额外设置)
# 用法: set_timezone_by_region "$REGION"  或  TZ=Asia/Tokyo set_timezone_by_region
set_timezone_by_region() {
  local region="${1:-}"
  local tz="${TZ:-}"
  [[ -z "$tz" && -n "$region" ]] && tz=$(_region_to_tz "$region")
  if [[ -n "$tz" ]] && command -v timedatectl >/dev/null 2>&1; then
    timedatectl set-timezone "$tz" 2>/dev/null && echo "$tz" && return 0
  fi
  echo ""
}

# 探测本机地区: 查公网IP的国家码 -> region。失败返回 other。
# 用法: REGION=$(detect_region)  或  REGION=$(detect_region "$SERVER_IP")
detect_region() {
  local ip="${1:-}"
  local url="http://ip-api.com/json/${ip}?fields=status,countryCode"
  local resp cc
  resp=$(curl -s --max-time 6 "$url" 2>/dev/null)
  if echo "$resp" | grep -q '"status":"success"'; then
    cc=$(echo "$resp" | grep -oE '"countryCode":"[A-Z]+"' | grep -oE '[A-Z]+')
    _cc_to_region "$cc"
  else
    echo other
  fi
}

# 探测公网 IP (多源兜底)
detect_public_ip() {
  local ip=""
  for svc in "https://api.ipify.org" "https://ifconfig.me/ip" "https://ipinfo.io/ip"; do
    ip=$(curl -fsS --max-time 5 "$svc" 2>/dev/null | tr -d '[:space:]')
    [[ -n "$ip" ]] && { echo "$ip"; return 0; }
  done
  return 1
}
