# 自建订阅管理系统

为 REALITY / Hysteria2 / TUIC / VMess / SS / Trojan 节点提供多客户端订阅分发，
带 Web 管理面板、per-user token（可独立吊销）、部署脚本自动推送。

## 协议 × 客户端支持矩阵

| 客户端 | 订阅 target | REALITY | Hysteria2 | TUIC |
|---|---|---|---|---|
| Clash Verge | `clash` | ✓ | ✓ | ✓ |
| v2rayN / 小火箭 | `v2ray` | ✓ | ✓ | ✓ |
| Loon | `loon` | ✓ | ✓ | ✗(自动过滤) |
| 圈X | `quanx` | ✓ | ✗(自动过滤) | ✗(自动过滤) |

不带 `?target=` 时按 User-Agent 自动识别。

## 部署 (Oracle Osaka)

```bash
# 1. 解压到目录
cd /opt && unzip sub-manager.zip && cd sub-manager

# 2. 首次设管理员密码 (之后可在面板改)
export ADMIN_PASSWORD='你的强密码'

# 3. 构建启动
docker compose up -d --build

# 4. 看部署推送 token (或登录面板右上角"部署Token")
docker compose logs | grep "推送 token"
```

容器只监听 `127.0.0.1:8000`，**不直接暴露公网**。

## 接入 Cloudflare

两种方式任选：

**A. Nginx 反代 + CF 橙云**（你熟悉的方式）
```nginx
server {
    listen 443 ssl http2;
    server_name sub.202205.xyz;
    # ... 你的证书 ...
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```
然后域名在 CF 开橙云代理。

**B. Cloudflare Tunnel**（无需暴露端口）
```bash
cloudflared tunnel --url http://127.0.0.1:8000
# 或配置 named tunnel 指向 sub.202205.xyz
```

## 数据持久化

SQLite 在 `./data/sub.db`，记得纳入你的 OCI snapshot / 备份。

## 节点录入两种方式

**方式1 — 部署脚本自动推送**：在 reality.sh 末尾 source 后调用 `push_to_sub.sh`：
```bash
SUB_API="https://sub.202205.xyz" PUSH_TOKEN="xxx" REGION="jp" bash push_to_sub.sh
```
按 (server,port,type) upsert，重复部署不会产生重复节点。

**方式2 — 面板手填**：登录 → 新增节点 → 选类型自动带出参数模板。

## 节点 params 字段速查

```
reality   : {uuid, flow:"xtls-rprx-vision", pbk, sid, sni, fp:"chrome", network:"tcp"|"grpc", serviceName}
hysteria2 : {password, sni, insecure:true, obfs?, obfs_pass?}
tuic      : {uuid, password, sni, alpn:"h3", congestion:"bbr", insecure:true}
vmess     : {uuid, alterId:0, network:"ws", path, host, tls:true, sni}
shadowsocks: {method, password}
trojan    : {password, sni, network, path?, host?}
```

## Token 管理

- 新建令牌 → 复制订阅链接（四种格式）发给对应客户端
- 给朋友单独建一个令牌，备注"朋友A"，被泄露或不想给了就**禁用/删除**，不影响自己的
- 可按地区限制某令牌可见节点（如朋友只给日本节点）
- 可设到期时间

## 流媒体分流

Clash YAML 内置分组（节点选择/自动选择/地区组/流媒体/港台流媒体）和规则
(Netflix/Disney/TVB 等走对应组)。要让 TVB 走香港落地、Netflix 走美国落地，
只需把对应落地节点按 region 加进来，在客户端把"港台流媒体""流媒体"组手动指到对应地区即可。

## 安全提醒

- 管理面板务必改强密码；订阅 token 是长随机串，泄露=该订阅所有节点泄露
- 全程走 HTTPS（CF）；SQLite 文件权限锁死
- 订阅服务部署在 Osaka 而非 DMIT：节点挂了订阅还能切，订阅挂了不影响节点

## 订阅模板 (Loon / 圈X)

Loon 和圈X 用「模板 + 占位符」模式：你现有的 Loon.lcf / Quantumult.conf 已内置为默认模板，
节点会自动填入 `{{NODES}}` 占位符，你调好的策略组(时延优选/url-latency-benchmark)、
规则集(kelee.one/blackmatrix7)、地区正则分组全部原样保留。

- 节点命名：地区中文名+序号(日本1/日本2/香港1...)，配合模板里的 server-tag-regex 自动分组
- 字段已对齐你的真实配置：Loon 用 `flow/public-key="..."/udp=true/block-quic=true`；
  圈X 用 `method=none/reality-base64-pubkey/reality-hex-shortid/vless-flow`
- 面板「模板」按钮可在线编辑，保存即生效；改坏了点「恢复默认」
- 模板必须保留 `{{NODES}}` 占位符，否则保存被拒(防止节点丢失)

Clash 用内置分组规则(节点选择/自动选择/地区组/流媒体)，不走模板。

## 节点过滤 (Include/Exclude)

类似 subconverter 的进阶模式, 支持按节点名称正则筛选:
- **token 存默认**: 给朋友的 token 设 include_regex="日本|香港", 他只看到这些节点
- **URL 参数临时覆盖**: `?target=clash&include=日本&exclude=test` 即时生效, 不改 token
- 正则匹配 "节点原始名 + 地区中文名", 如 "日本" 可匹配 region=jp 或名称含日本的节点
- 过滤顺序: token地区/节点 → include → exclude → 客户端协议支持

## 订阅预览 (面板)

面板「订阅预览」按钮 = subconverter 进阶模式的自建版:
- 选客户端类型 (Clash/Base64/Loon/圈X)
- 选基于哪个令牌, 或预览全部节点
- 临时填 include/exclude 正则, 实时看生成结果 + 各格式节点数
- 一键复制带参数的最终订阅 URL
- 预览不消耗 token 访问计数

## 客户端类型如何确定

两种方式 (比 subconverter 网页下拉更灵活):
1. **URL 参数**: `?target=clash|v2ray|loon|quanx` 显式指定
2. **UA 自动识别**: 不带 target 时, 按客户端 User-Agent 自动判断
   (clash→clash, loon→loon, quantumult→quanx, shadowrocket/v2ray→v2ray)
给朋友一个不带 target 的链接, 他用什么客户端打开就自动给对应格式。

## 过滤优先级与边界行为 (重要)

**过滤层叠加 (全是 AND, 层层收窄):**
```
全部启用节点
 → token.node_filter  (指定节点)
 → token.region_filter (地区)
 → include 正则 (URL参数 > token默认)
 → exclude 正则 (URL参数 > token默认)
 → 客户端协议支持 (loon剔tuic, 圈X剔hy2/tuic)
```
注意: region_filter=[us,au] 又设 include=日本 → 美澳里没日本 → 空。这是预期行为(每个限制都生效)。

**target 优先级:** URL `?target=` 参数 > UA 自动识别 > 默认 v2ray。
(人主动写的参数压过系统猜测; 朋友复制链接时别带错 target)

**include/exclude 冲突:** 同时匹配时 exclude 赢 (exclude = 无论如何都不要)。

**空订阅兜底:** 节点被过滤光时, 自动塞一个占位节点"无可用节点-请联系管理员",
保证配置合法 + 用户能看到提示, 而非空配置导致客户端报错。

**token 状态区分:**
- 过期: 返回含"订阅已过期-请联系管理员续期"提示的订阅 (非404), 让朋友知道要续期
- 禁用(吊销)/不存在: 一律 404 (不泄露 token 是否存在)
- 节点 enabled=false: 全局禁用(所有token都看不到); token过滤是单token维度(别人仍可见)

## Clash 分流策略 (路径A: 客户端规则分流)

Clash 用固定分组 (按节点 region 字段自动归地区组), 流媒体走全地区兜底, 对齐 Loon 现状:
- **🚀 节点选择**: 主入口, 含自动选择/兜底后备/各地区组/各节点
- **♻️ 自动选择**: 全部节点延迟最低 (url-test)
- **🔄 兜底后备**: 各地区组 fallback (对齐 Loon 的"兜底后备")
- **<地区>节点**: 按 region 自动归类 (日本节点/香港节点/美国节点...)
- **流媒体**: Netflix/Disney/HBO/YouTube/Spotify 默认走兜底后备
- **港台流媒体**: 巴哈姆特等, 候选=香港+台湾节点
- PayPal 走美国节点 (无美国节点时自动回退兜底)
- 规则用 Mihomo 内置 GEOSITE, 无需外部规则集

**健壮性**: 朋友 token 限定地区导致缺某地区时, 指向该地区的规则自动回退兜底,
不会让 Clash 因"规则指向不存在的组"而报错。

## 路径B: 服务端中转 (特定场景, 不在订阅系统内)

少数场景 (某地区只有 Oracle 没 DMIT / 落地 IP 太脏不想直接暴露入站) 可用服务端中转:
入口节点 xray 内部把特定流量转发到落地机。这部分用 setup_relay.sh 在节点上单独配置,
与订阅系统解耦 (订阅只下发"连哪个入口", 入口内部转发它不感知)。

## Clash 规则映射 (面板可编辑)

Clash 的"服务→分流目标"规则现在面板可编辑 (面板「模板」→「Clash规则」):
- 每条规则 = GEOSITE类别 + 目标
- 目标可填: 地区码(jp/hk/us/sg/kr/au/nz/tw) 或 特殊组(兜底/节点选择/流媒体/港台流媒体/直连)
- 例: google→hk 让谷歌走香港, paypal→us 让PayPal走美国
- 指向不存在的地区时自动回退兜底, 不会让 Clash 报错
- 这是路径A(客户端分流)的细分规则; Loon/圈X 的同类规则在各自模板里调

注: Loon/圈X 已通过模板支持服务→地区的细分(你的真实配置里 PayPal→美国时延优选 等),
Clash 现在也对齐了这个能力, 三端可保持一致的分流策略。

## relay-tool/ (服务端转发, 独立工具)

见 relay-tool/README.md。这是路径B(服务端中转)的工具, 在入口节点上运行,
把手动改 config 转发到落地机的过程做成声明式 YAML + 生成器。与订阅系统解耦。

## 新服务器开荒 (bootstrap.sh)

DD 完系统后, 从裸机到节点入库的一键流程 (DD 本身保持手动)。

**串接**: dpkg/apt基础工具 → init.sh(系统初始化, 已自动去除reboot) → reality.sh(交互填域名/端口, 末尾自动推送)。
时间同步由 reality.sh 的 syncTime(chrony) 处理, 不单独跑 timezone.sh。

**用法**: 把 bootstrap.sh + reality.sh + push_to_sub.sh 三个文件传到新服务器同目录:
```bash
SUB_API="https://sub-manager.202205.xyz" \
PUSH_TOKEN="面板的部署token" \
NODE_REGION="jp" NODE_NAME="dmit-tokyo-1" \
bash bootstrap.sh
```

**安全保护**:
- init.sh 会加固 SSH(禁root/改端口38658/仅key登录)。bootstrap 跑完会校验新用户的
  authorized_keys 非空 —— 若 GitHub 拉公钥失败导致 key 为空, 会中止并警告, 防止重启后锁死。
- **务必**: 跑完后另开终端验证 `ssh -p 38658 frank.chen@IP` 能用 key 登录, 确认后再手动 reboot。
- init.sh 参数默认 INIT_GH_USER=usbeibao INIT_NEW_USER=frank.chen, 可用环境变量覆盖。

## 域名模式 + Cloudflare DNS 自动化

节点可用域名而非IP (换IP不用改客户端订阅)。部署时 sub-manager 自动调 CF API 建解析。

**配置** (.env):
```
CF_API_TOKEN=<Scoped Token, 权限 Zone.DNS.Edit, 限定你的zone>
CF_ZONE_ID=<可选, 不填则用域名自动查>
```

**部署时启用域名模式**: 传 NODE_DOMAIN
```bash
SUB_API="https://sub-manager.202205.xyz" PUSH_TOKEN="xxx" \
NODE_REGION="jp" NODE_NAME="dmit-tokyo-2" \
NODE_DOMAIN="tokyo2.202205.xyz" \
bash bootstrap.sh   # 或 reality.sh
```

**流程**:
1. push_to_sub.sh 推 {domain, ip, 参数}
2. sub-manager 调 CF 建/更新 A记录 domain→ip (灰云 DNS only)
3. 节点 server 存域名, 订阅里就是域名
4. 换IP: 重新推送同 domain → 更新A记录的IP, 订阅不变
5. 删节点: 面板删 → 同步删 CF 解析

**严格模式**: CF 解析失败则该节点推送失败不入库 (保证域名一定可用)。
不传 NODE_DOMAIN = IP 模式 (不碰 CF, server 用 IP)。

**重要**: 节点域名必须灰云直连(代码已强制 proxied=False)。
REALITY 不能套 CF 橙云(CF会终止TLS破坏握手)。域名只为"换IP不改客户端", 不隐藏真实IP。

## 内核改为 sing-box (重要变更)

reality.sh 从 Xray 改为 sing-box 单核, 原因: Xray 的 Hysteria2 支持不成熟(连接超时),
且不支持 TUIC。sing-box 单核原生稳定支持全部协议, 省内存。

**协议**: VLESS-REALITY-Vision(TCP) + Hysteria2(UDP) + TUIC(UDP) + Shadowsocks
**证书**: Hy2/TUIC 用真证书, 经 acme.sh + Cloudflare DNS-01 申请
  - 需要 NODE_DOMAIN + CF_API_TOKEN (复用 sub-manager 同一个 CF token)
  - DNS-01 不依赖域名先解析、不占80端口
  - 无 NODE_DOMAIN/CF_API_TOKEN 时降级自签证书(客户端 insecure)

**部署 (域名模式+真证书)**:
```bash
SUB_API="https://sub-manager.202205.xyz" \
PUSH_TOKEN="部署token" \
CF_API_TOKEN="你的CF_token" \
NODE_REGION="jp" NODE_NAME="dmit-tokyo-2" \
NODE_DOMAIN="tokyo2.202205.xyz" \
bash bootstrap.sh
```
(CF_API_TOKEN 会被 bootstrap 透传给 reality.sh 做 DNS-01 证书申请)

**客户端协议覆盖** (订阅系统自动过滤):
- Clash/v2rayN/小火箭: 全部4种
- Loon: REALITY+Hy2+SS (无TUIC)
- 圈X: REALITY+SS (无Hy2/TUIC)

订阅系统 (sub-manager) 无需改动, 已支持全部4种协议节点。
