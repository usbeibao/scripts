#!/usr/bin/env bash
# =============================================================================
#  restore.sh —— sub-manager 面板机一键恢复 (新机器/灾难重建)
# -----------------------------------------------------------------------------
#  场景: oracle-osaka-1 挂了/换机, 在新机器上重建 sub-manager 面板。
#
#  前置:
#    1. 新机器已装 docker + docker compose
#    2. sub-manager.zip 已传到当前目录 (或 /opt/sub-manager.zip)
#    3. 有 DB 备份 (本地 backups/ 或 GDrive), 用于恢复节点/token 数据
#
#  用法:
#    bash restore.sh                          # 交互式, 一步步确认
#    RESTORE_DB=/path/to/sub-manager-xxx.db.gz bash restore.sh   # 指定备份恢复
#
#  恢复后还需手动: nginx 反代、CF DNS、cron 备份、daily.py 告警配置 (见 RESTORE.md)
# =============================================================================
set -uo pipefail

RED="\033[31m"; GREEN="\033[32m"; YELLOW="\033[33m"; BLUE="\033[36m"; PLAIN='\033[0m'
say(){ echo -e "${1}${@:2}${PLAIN}"; }
info(){ say "$BLUE" "\n=== $* ==="; }
ok(){ say "$GREEN" " ✓ $*"; }
warn(){ say "$YELLOW" " ⚠ $*"; }
err(){ say "$RED" " ✗ $*"; }

OPT_DIR="${OPT_DIR:-/opt}"
APP_DIR="$OPT_DIR/sub-manager"
ZIP="${ZIP:-}"
GDRIVE_DIR="${GDRIVE_DIR:-/opt/siftminsk_gdrive}"
GDRIVE_SUBDIR="${GDRIVE_SUBDIR:-sub-manager-backups}"

[[ "$(id -u)" != "0" ]] && { err "请以 root 运行"; exit 1; }

# ---------- 1. 检查 docker ----------
info "步骤1: 检查 docker"
if ! command -v docker >/dev/null 2>&1; then
  err "未装 docker。先装: curl -fsSL https://get.docker.com | sh"
  exit 1
fi
docker compose version >/dev/null 2>&1 || { err "docker compose 不可用"; exit 1; }
ok "docker / compose 就绪"

# ---------- 2. 找到 sub-manager.zip 并解压 ----------
info "步骤2: 部署代码"
if [[ -z "$ZIP" ]]; then
  for cand in "./sub-manager.zip" "$OPT_DIR/sub-manager.zip" "$HOME/sub-manager.zip"; do
    [[ -f "$cand" ]] && { ZIP="$cand"; break; }
  done
fi
[[ -z "$ZIP" || ! -f "$ZIP" ]] && { err "找不到 sub-manager.zip (放当前目录或 /opt/, 或用 ZIP=路径 指定)"; exit 1; }
ok "找到 $ZIP"
cd "$OPT_DIR"
unzip -o "$ZIP" >/dev/null
ok "已解压到 $APP_DIR"

# ---------- 3. 恢复 .env ----------
info "步骤3: 配置 .env"
cd "$APP_DIR"
if [[ -f .env ]]; then
  ok ".env 已存在 (沿用现有)"
else
  cp .env.example .env
  warn "已从 .env.example 创建 .env, 请填入凭据!"
  echo "    需填: ADMIN_PASSWORD / PUSH_TOKEN / REPORT_TOKEN / CF_API_TOKEN(cfut_)"
  read -rp "    现在用编辑器打开 .env 填写? [Y/n]: " ed
  [[ "${ed:-Y}" == [Yy] ]] && "${EDITOR:-vi}" .env
fi
# 确保 docker-compose.yml 透传 REPORT_TOKEN (历史坑)
if ! grep -q "REPORT_TOKEN" docker-compose.yml; then
  warn "docker-compose.yml 缺 REPORT_TOKEN 透传, 请手动在 environment 段加:"
  echo '      REPORT_TOKEN: "${REPORT_TOKEN:-}"'
fi

# ---------- 4. 恢复数据库 (节点/token 数据) ----------
info "步骤4: 恢复数据库"
mkdir -p data
DB_BAK="${RESTORE_DB:-}"
if [[ -z "$DB_BAK" ]]; then
  # 自动找最新备份: 优先 GDrive, 其次本地 backups/
  for dir in "$GDRIVE_DIR/$GDRIVE_SUBDIR" "$APP_DIR/backups"; do
    if [[ -d "$dir" ]]; then
      latest=$(ls -1t "$dir"/sub-manager-*.db.gz 2>/dev/null | head -1)
      [[ -n "$latest" ]] && { DB_BAK="$latest"; break; }
    fi
  done
fi
if [[ -n "$DB_BAK" && -f "$DB_BAK" ]]; then
  ok "用备份恢复: $DB_BAK"
  if [[ -f data/sub.db ]]; then
    warn "data/sub.db 已存在, 备份为 sub.db.before-restore"
    mv data/sub.db "data/sub.db.before-restore.$(date +%s)"
  fi
  gunzip -c "$DB_BAK" > data/sub.db
  ok "数据库已恢复到 data/sub.db"
else
  warn "未找到 DB 备份, 将以空库启动 (节点/token 需重新推送/创建)"
fi

# ---------- 5. 起容器 ----------
info "步骤5: 构建启动容器"
docker compose up -d --build
sleep 5

# ---------- 6. 健康检查 ----------
info "步骤6: 验证"
PORT=$(grep -oE '127.0.0.1:[0-9]+->' docker-compose.yml | grep -oE '[0-9]+' | head -1)
PORT="${PORT:-8090}"
HEALTH=$(curl -s "http://127.0.0.1:${PORT}/api/health" 2>/dev/null || echo "")
if echo "$HEALTH" | grep -q '"status"'; then
  ok "面板已起: $HEALTH"
else
  warn "健康检查未通过, 看日志: docker compose logs --tail 30"
fi

cat <<EOF

$(say "$GREEN" "===== 面板恢复完成 =====")
还需手动恢复外围 (见 RESTORE.md):
  1. nginx 反代到 127.0.0.1:${PORT} + CF 域名解析
  2. cron 备份: 0 3 * * * $APP_DIR/backup_db.sh >> /var/log/sub-manager-backup.log 2>&1
  3. daily.py 告警 (另一容器, 配 SUBMGR_API/SUBMGR_REPORT_TOKEN)
  4. 浏览器访问确认节点/token 都在
EOF
