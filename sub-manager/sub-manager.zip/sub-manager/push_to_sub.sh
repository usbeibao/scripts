#!/usr/bin/env bash
# push_to_sub.sh —— 把本机节点推送到订阅管理系统 (sing-box版)
# 推送: REALITY-Vision + Hysteria2 + TUIC + Shadowsocks
# 域名模式: 设了 NODE_DOMAIN 则推送域名+IP, sub-manager 建CF解析, server用域名
SUB_API="${SUB_API:?需要 SUB_API}"
PUSH_TOKEN="${PUSH_TOKEN:?需要 PUSH_TOKEN}"
SERVER_IP="${SERVER_IP:-$(curl -s --max-time 5 https://api.ipify.org)}"
# 地区: 未传或 other 时自动探测 IP 归属
_libdir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
[[ -f "${_libdir}/common_lib.sh" ]] && source "${_libdir}/common_lib.sh"
REGION="${REGION:-}"
if [[ -z "$REGION" || "$REGION" == "other" ]] && declare -F detect_region >/dev/null; then
  _detected=$(detect_region "$SERVER_IP")
  REGION="$_detected"
  echo " 地区自动探测: ${REGION}"
fi
REGION="${REGION:-other}"
NODE_NAME="${NODE_NAME:-$(hostname)}"
NODE_DOMAIN="${NODE_DOMAIN:-}"
CERT_DOMAIN="${CERT_DOMAIN:-www.bing.com}"
USE_REAL_CERT="${USE_REAL_CERT:-0}"
# insecure: 真证书=false, 自签=true
INSECURE=$([ "${USE_REAL_CERT}" == "1" ] && echo "false" || echo "true")

check_params() {
  local missing=""
  [[ -z "${UUID}" ]] && missing+=" UUID"
  [[ -z "${realityPublicKey}" ]] && missing+=" realityPublicKey"
  [[ -z "${SERVER_IP}" ]] && missing+=" SERVER_IP"
  [[ -n "${missing}" ]] && { echo " [警告] 缺少:${missing}"; return 1; }
  return 0
}

build_json() {
  local dom_field=""
  if [[ -n "${NODE_DOMAIN}" ]]; then
    dom_field="\"domain\": \"${NODE_DOMAIN}\", \"ip\": \"${SERVER_IP}\","
  fi
  cat <<JSON
[
  {
    "name": "${NODE_NAME}-Reality",
    "type": "reality",
    "server": "${SERVER_IP}",
    ${dom_field}
    "port": ${REALITY_PORT:-443},
    "region": "${REGION}",
    "params": {
      "uuid": "${UUID}",
      "flow": "xtls-rprx-vision",
      "pbk": "${realityPublicKey}",
      "sid": "${realityShortId}",
      "sni": "${realityDestDomain}",
      "fp": "chrome",
      "network": "tcp"
    }
  },
  {
    "name": "${NODE_NAME}-Hy2",
    "type": "hysteria2",
    "server": "${SERVER_IP}",
    ${dom_field}
    "port": ${HY2_PORT},
    "region": "${REGION}",
    "params": {
      "password": "${HY2_PASSWORD}",
      "sni": "${CERT_DOMAIN}",
      "insecure": ${INSECURE}
    }
  },
  {
    "name": "${NODE_NAME}-TUIC",
    "type": "tuic",
    "server": "${SERVER_IP}",
    ${dom_field}
    "port": ${TUIC_PORT},
    "region": "${REGION}",
    "params": {
      "uuid": "${TUIC_UUID}",
      "password": "${TUIC_PASSWORD}",
      "sni": "${CERT_DOMAIN}",
      "alpn": "h3",
      "congestion": "bbr",
      "insecure": ${INSECURE}
    }
  },
  {
    "name": "${NODE_NAME}-SS",
    "type": "shadowsocks",
    "server": "${SERVER_IP}",
    ${dom_field}
    "port": ${SS_PORT},
    "region": "${REGION}",
    "params": {
      "method": "chacha20-ietf-poly1305",
      "password": "${SS_PASSWORD}"
    }
  }
]
JSON
}

push_nodes() {
  check_params || echo " (仍尝试推送)"
  # 幂等: 推送前清理同机器(NODE_NAME前缀)的旧节点, 避免端口变更后残留
  if [[ "${CLEANUP_OLD:-1}" == "1" ]]; then
    local cl; cl=$(curl -s --max-time 10 -X POST "${SUB_API}/api/nodes/cleanup" \
      -H "Content-Type: application/json" -H "Authorization: Bearer ${PUSH_TOKEN}" \
      -d "{\"name_prefix\": \"${NODE_NAME}-\"}" 2>/dev/null)
    echo " 清理旧节点: ${cl}"
  fi
  local payload; payload=$(build_json)
  echo " 推送节点到 ${SUB_API} ..."
  local resp; resp=$(curl -s --max-time 15 -X POST "${SUB_API}/api/nodes/push" \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer ${PUSH_TOKEN}" \
    -d "${payload}")
  echo " 响应: ${resp}"
}

push_nodes
