#!/usr/bin/env bash
#
# backup_db.sh — sub-manager 数据库定时备份
#
# 用法 (在宿主机, 不在容器内):
#   bash backup_db.sh
# 配合 cron (每天凌晨3点备份, 保留最近14份):
#   0 3 * * * /opt/sub-manager/backup_db.sh >> /var/log/sub-manager-backup.log 2>&1
#
set -euo pipefail

# 数据库位置: docker compose 的 volume 挂载点 (按实际改)
# 默认假设 compose 把 /data 映射到 ./data
DB_PATH="${DB_PATH:-/opt/sub-manager/data/sub.db}"
BACKUP_DIR="${BACKUP_DIR:-/opt/sub-manager/backups}"
KEEP="${KEEP:-14}"   # 保留最近几份

mkdir -p "$BACKUP_DIR"

if [[ ! -f "$DB_PATH" ]]; then
  echo "[$(date '+%F %T')] 数据库不存在: $DB_PATH" >&2
  exit 1
fi

TS=$(date '+%Y%m%d-%H%M%S')
DEST="$BACKUP_DIR/sub-manager-$TS.db"

# 用 sqlite3 .backup 保证一致性(优于直接 cp, 避免写一半)
if command -v sqlite3 >/dev/null 2>&1; then
  sqlite3 "$DB_PATH" ".backup '$DEST'"
else
  # 无 sqlite3 则退化为 cp (sub-manager 写入少, 风险低)
  cp "$DB_PATH" "$DEST"
fi

# gzip 压缩
gzip -f "$DEST"
echo "[$(date '+%F %T')] 已备份: ${DEST}.gz"

# ---------- 异地备份: cp 到 Google Drive 挂载点 ----------
# GDRIVE_DIR 是 rclone mount 的挂载点; 关键: 先确认挂载正常再 cp(否则白备份到本地空目录)
GDRIVE_DIR="${GDRIVE_DIR:-/opt/siftminsk_gdrive}"
GDRIVE_SUBDIR="${GDRIVE_SUBDIR:-sub-manager-backups}"   # GDrive 下的子目录
GDRIVE_KEEP="${GDRIVE_KEEP:-14}"

backup_to_gdrive() {
  local dest_dir="$GDRIVE_DIR/$GDRIVE_SUBDIR"
  # 1) 检查挂载点存在
  if [[ ! -d "$GDRIVE_DIR" ]]; then
    echo "[$(date '+%F %T')] ⚠ GDrive 目录不存在: $GDRIVE_DIR, 跳过异地备份" >&2
    return 1
  fi
  # 2) 检查真的挂载了(不是本地空目录)。mountpoint 命令最准, 没有则用 findmnt
  if command -v mountpoint >/dev/null 2>&1; then
    if ! mountpoint -q "$GDRIVE_DIR"; then
      echo "[$(date '+%F %T')] ⚠ $GDRIVE_DIR 未挂载(rclone mount 可能掉了), 跳过异地备份" >&2
      return 1
    fi
  elif command -v findmnt >/dev/null 2>&1; then
    if ! findmnt "$GDRIVE_DIR" >/dev/null 2>&1; then
      echo "[$(date '+%F %T')] ⚠ $GDRIVE_DIR 未挂载, 跳过异地备份" >&2
      return 1
    fi
  fi
  # 3) cp 到 GDrive
  mkdir -p "$dest_dir"
  if cp "${DEST}.gz" "$dest_dir/"; then
    echo "[$(date '+%F %T')] ✓ 已异地备份到 GDrive: $dest_dir/$(basename "${DEST}.gz")"
  else
    echo "[$(date '+%F %T')] ⚠ GDrive cp 失败" >&2
    return 1
  fi
  # 4) 清理 GDrive 旧备份(保留 GDRIVE_KEEP 份)
  ls -1t "$dest_dir"/sub-manager-*.db.gz 2>/dev/null | tail -n +$((GDRIVE_KEEP+1)) | while read -r old; do
    rm -f "$old" && echo "[$(date '+%F %T')] 清理 GDrive 旧备份: $(basename "$old")"
  done
}

# 执行异地备份(失败不影响本地备份已完成, 仅警告)
backup_to_gdrive || echo "[$(date '+%F %T')] 异地备份未完成, 本地备份仍有效"

# 清理旧备份(保留最近 KEEP 份)
ls -1t "$BACKUP_DIR"/sub-manager-*.db.gz 2>/dev/null | tail -n +$((KEEP+1)) | while read -r old; do
  rm -f "$old"
  echo "[$(date '+%F %T')] 清理旧备份: $old"
done
