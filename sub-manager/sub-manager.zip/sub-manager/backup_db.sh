#!/usr/bin/env bash
#
# backup_db.sh — sub-manager 数据库定时备份
#
# 用法 (在宿主机, 不在容器内):
#   bash backup_db.sh
# 配合 cron (每天凌晨3点备份, 保留最近14份):
#   0 3 * * * /opt/sub-manager/backup_db.sh >> /var/log/sub-manager-backup.log 2>&1
#
set -euo pipefail

# 数据库位置: docker compose 的 volume 挂载点 (按实际改)
# 默认假设 compose 把 /data 映射到 ./data
DB_PATH="${DB_PATH:-/opt/sub-manager/data/sub.db}"
BACKUP_DIR="${BACKUP_DIR:-/opt/sub-manager/backups}"
KEEP="${KEEP:-14}"   # 保留最近几份

mkdir -p "$BACKUP_DIR"

if [[ ! -f "$DB_PATH" ]]; then
  echo "[$(date '+%F %T')] 数据库不存在: $DB_PATH" >&2
  exit 1
fi

TS=$(date '+%Y%m%d-%H%M%S')
DEST="$BACKUP_DIR/sub-manager-$TS.db"

# 用 sqlite3 .backup 保证一致性(优于直接 cp, 避免写一半)
if command -v sqlite3 >/dev/null 2>&1; then
  sqlite3 "$DB_PATH" ".backup '$DEST'"
else
  # 无 sqlite3 则退化为 cp (sub-manager 写入少, 风险低)
  cp "$DB_PATH" "$DEST"
fi

# gzip 压缩
gzip -f "$DEST"
echo "[$(date '+%F %T')] 已备份: ${DEST}.gz"

# 清理旧备份(保留最近 KEEP 份)
ls -1t "$BACKUP_DIR"/sub-manager-*.db.gz 2>/dev/null | tail -n +$((KEEP+1)) | while read -r old; do
  rm -f "$old"
  echo "[$(date '+%F %T')] 清理旧备份: $old"
done
